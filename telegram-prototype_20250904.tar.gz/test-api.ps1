# Test script for the fail-fast API

Write-Host "🧪 Testing Fail-Fast API Implementation" -ForegroundColor Cyan
Write-Host ""

# 1. Test with no DATABASE_URL (should fail to start)
Write-Host "1️⃣  Testing startup without DATABASE_URL (should fail)" -ForegroundColor Yellow
Remove-Item Env:DATABASE_URL -ErrorAction SilentlyContinue
try {
    $env:NODE_ENV = "production"
    $process = Start-Process -FilePath "npm" -ArgumentList "-w @apps/hr-api run start" -PassThru -NoNewWindow
    Start-Sleep -Seconds 3
    if ($process.HasExited) {
        Write-Host "   ✅ API correctly failed to start without DATABASE_URL" -ForegroundColor Green
    } else {
        $process.Kill()
        Write-Host "   ❌ API should not start without DATABASE_URL" -ForegroundColor Red
    }
} catch {
    Write-Host "   ✅ API correctly failed to start: $($_.Exception.Message)" -ForegroundColor Green
}

Write-Host ""

# 2. Test with invalid DATABASE_URL (should fail to start)  
Write-Host "2️⃣  Testing startup with invalid DATABASE_URL (should fail)" -ForegroundColor Yellow
$env:DATABASE_URL = "postgresql://invalid:invalid@invalid.host:5432/invalid"
try {
    $process = Start-Process -FilePath "npm" -ArgumentList "-w @apps/hr-api run start" -PassThru -NoNewWindow
    Start-Sleep -Seconds 5
    if ($process.HasExited) {
        Write-Host "   ✅ API correctly failed to start with invalid DATABASE_URL" -ForegroundColor Green
    } else {
        $process.Kill()
        Write-Host "   ❌ API should not start with invalid DATABASE_URL" -ForegroundColor Red
    }
} catch {
    Write-Host "   ✅ API correctly failed to start: $($_.Exception.Message)" -ForegroundColor Green
}

Write-Host ""
Write-Host "🏁 Test Complete - Fail-fast behavior verified" -ForegroundColor Green
Write-Host ""
Write-Host "To test with a working database:" -ForegroundColor Cyan
Write-Host "1. Set DATABASE_URL to a valid PostgreSQL connection" -ForegroundColor Gray  
Write-Host "2. Run: npm -w @apps/hr-api run start" -ForegroundColor Gray
Write-Host "3. Test: curl http://localhost:3000/api/health" -ForegroundColor Gray
Write-Host "4. Test: curl http://localhost:3000/api/ready" -ForegroundColor Gray
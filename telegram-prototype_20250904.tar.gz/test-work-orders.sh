#!/bin/bash

# Work Orders State Machine Testing Script
# This script demonstrates all implemented functionality

echo "=== Work Orders State Machine Test Suite ==="
echo ""

# Configuration
API_BASE="http://localhost:3009/api"
TOKEN="Bearer dev-token"
ORG_ID="00000000-0000-4000-8000-000000000001"

echo "1. Testing work orders list endpoint..."
curl -s -X GET "${API_BASE}/work-orders" \
  -H "Authorization: ${TOKEN}" \
  -H "x-org-id: ${ORG_ID}" | jq '.'

echo ""
echo "2. Creating a new work order..."
NEW_WO=$(curl -s -X POST "${API_BASE}/work-orders" \
  -H "Authorization: ${TOKEN}" \
  -H "x-org-id: ${ORG_ID}" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Plumbing Issue",
    "description": "Kitchen sink is leaking",
    "priority": "high",
    "tenant_name": "Jane Smith",
    "tenant_phone": "555-0123"
  }')

WO_ID=$(echo ${NEW_WO} | jq -r '.id')
echo "Created work order: ${WO_ID}"
echo ${NEW_WO} | jq '.'

echo ""
echo "3. Testing invalid state transition (should fail)..."
curl -s -X PATCH "${API_BASE}/work-orders/${WO_ID}/status" \
  -H "Authorization: ${TOKEN}" \
  -H "x-org-id: ${ORG_ID}" \
  -H "Content-Type: application/json" \
  -d '{"status": "completed"}' | jq '.'

echo ""
echo "4. Testing valid state transition (assign work order)..."
curl -s -X PATCH "${API_BASE}/work-orders/${WO_ID}/status" \
  -H "Authorization: ${TOKEN}" \
  -H "x-org-id: ${ORG_ID}" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "assigned",
    "reason": "Assigned to plumber",
    "assignee": {
      "assignee_id": "plumber-001",
      "assignee_name": "Mike Wilson",
      "assignee_email": "mike@plumbing.com"
    }
  }' | jq '.'

echo ""
echo "5. Testing transition to in_progress..."
curl -s -X PATCH "${API_BASE}/work-orders/${WO_ID}/status" \
  -H "Authorization: ${TOKEN}" \
  -H "x-org-id: ${ORG_ID}" \
  -H "Content-Type: application/json" \
  -d '{"status": "in_progress", "reason": "Started repairs"}' | jq '.'

echo ""
echo "6. Getting transition history..."
curl -s -X GET "${API_BASE}/work-orders/${WO_ID}/transitions" \
  -H "Authorization: ${TOKEN}" \
  -H "x-org-id: ${ORG_ID}" | jq '.'

echo ""
echo "7. Getting available transitions..."
curl -s -X GET "${API_BASE}/work-orders/${WO_ID}/available-transitions" \
  -H "Authorization: ${TOKEN}" \
  -H "x-org-id: ${ORG_ID}" | jq '.'

echo ""
echo "8. Testing bulk assignment..."
# Create another work order first
WO2=$(curl -s -X POST "${API_BASE}/work-orders" \
  -H "Authorization: ${TOKEN}" \
  -H "x-org-id: ${ORG_ID}" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Electrical Issue",
    "description": "Light fixture not working",
    "priority": "normal",
    "tenant_name": "Bob Johnson",
    "tenant_phone": "555-0456"
  }')
WO2_ID=$(echo ${WO2} | jq -r '.id')

curl -s -X POST "${API_BASE}/work-orders/bulk-assign" \
  -H "Authorization: ${TOKEN}" \
  -H "x-org-id: ${ORG_ID}" \
  -H "Content-Type: application/json" \
  -d '{
    "work_order_ids": ["'${WO2_ID}'"],
    "assignee": {
      "assignee_id": "electrician-001",
      "assignee_name": "Sarah Davis",
      "assignee_email": "sarah@electric.com"
    }
  }' | jq '.'

echo ""
echo "=== Test Suite Complete ==="
# RLS Diagnostic Scan Report
**Phase 1: Read-Only Analysis**  
Generated: 2025-08-28T01:41:13-645Z  
Scan ID: RLS-SCAN-001  
Status: ✅ COMPLETE

## Executive Summary

Multi-tenant RLS implementation analysis reveals **critical session variable inconsistencies** requiring immediate attention. While RLS policies are active and functional, mixed usage of session variables creates potential security vulnerabilities and operational complexity.

**Risk Level**: 🟡 MEDIUM - Inconsistent session variables across policies  
**Tables Affected**: 11 tables with RLS enabled  
**Critical Findings**: 2 high-priority items requiring Phase 2 repair  

---

## Critical Findings

### RLS-001: Session Variable Inconsistency (HIGH)
**Affected**: hr.properties, hr.work_orders vs. 9 other hr.* tables  
**Issue**: Mixed usage of session variables across RLS policies  
- **Pattern A** (2 tables): `app.org_id`
- **Pattern B** (9 tables): `app.current_organization`

**Risk**: Database service layer confusion, potential data leakage, operational complexity

**Evidence**:
```sql
-- hr.properties policy (Pattern A)
organization_id = (current_setting('app.org_id'::text, true))::uuid

-- hr.events policy (Pattern B)  
organization_id = (current_setting('app.current_organization'::text, true))::uuid
```

### RLS-002: Webhook Table Security Gap (MEDIUM)
**Affected**: hr.webhook_events  
**Issue**: Policy allows NULL organization_id access  
**Condition**: `((organization_id IS NULL) OR (organization_id = current_setting(...)))`  
**Risk**: Cross-tenant webhook event visibility

---

## Database Service Layer Analysis

### RLS-003: Dual Service Architecture (MEDIUM)
**Components**:
1. **PgService** (`pg.service.ts`) - Sets `app.org_id` session variable
2. **DatabaseService** (`database.service.ts`) - Sets `app.current_organization` variable

**Alignment Issues**:
- PgService uses `app.org_id` matching hr.properties/work_orders policies
- DatabaseService uses `app.current_organization` matching 9 other table policies
- Work-orders module uses DatabaseService but relies on `app.org_id` policies

**File References**:
- `apps/hr-api/src/db/pg.service.ts:88` - Sets app.org_id
- `apps/hr-api/src/common/database.service.ts:73` - Sets app.current_organization

### RLS-004: API Endpoint Security Validation (LOW)
**Status**: ✅ PROPERLY IMPLEMENTED  
**Evidence**:
- All critical endpoints validate `x-org-id` header
- UUID format validation present
- Composite authorization guard enforces org context
- Work-orders controller uses proper user.organizationId pattern

**Coverage**:
- ✅ `/api/properties` - Header validation required
- ✅ `/api/work-orders/*` - Context from authenticated user
- ❌ `/api/test` - No org context (acceptable for test endpoint)
- ❌ `/api/payments/webhook` - Webhook endpoint bypasses org validation (expected)

---

## Session Context Flow Analysis

### RLS-005: Request Context Middleware (GOOD)
**Status**: ✅ PROPERLY CONFIGURED  
**Implementation**: AsyncLocalStorage-based context propagation  
**File**: `apps/hr-api/src/common/request-context.middleware.ts`

**Context Flow**:
1. Request → RequestContextMiddleware (initializes empty context)
2. CompositeAuthzGuard → Validates x-org-id + populates context
3. Controller → Retrieves organizationId from user context
4. Service → Database operation with org context

### RLS-006: Test Controller Security Gap (LOW)
**File**: `apps/hr-api/src/test.controller.ts`  
**Issue**: Direct database connection without RLS context  
**Risk Level**: LOW (test endpoint only)  
**Evidence**: Creates raw pg.Client without session variable setup

---

## Database Schema Analysis

### Live RLS Status
**Enabled Tables**: 11 total
```
✅ hr.events, hr.legal_notices, hr.notice_templates, hr.payment_disputes
✅ hr.properties, hr.service_attempts, hr.sms_messages, hr.webhook_events  
✅ hr.work_order_transitions, hr.work_orders, hr.test_rls
```

### Policy Distribution
- **app.current_organization**: 9 tables (standard pattern)
- **app.org_id**: 2 tables (hr.properties, hr.work_orders)
- **Special conditions**: 1 table (hr.webhook_events allows NULL)

---

## BYPASSRLS Risk Assessment

### RLS-007: Production Security Risk (CRITICAL IN PRODUCTION)
**Current Status**: Development/Admin connection detected  
**User**: postgres (BYPASSRLS: true)  
**Risk**: All RLS policies bypassed in current connection  

**Recommendation**: Ensure production uses dedicated application user without BYPASSRLS privilege

**Privileged Users Detected**:
- `postgres` - Bypass RLS: true
- `service_role` - Bypass RLS: true  
- `supabase_admin` - Superuser + Bypass RLS
- `supabase_read_only_user` - Bypass RLS: true

---

## Migration vs. Live Policy Comparison

### RLS-008: Migration-Policy Alignment (MEDIUM)
**Source**: `packages/db/migrations/020_platform_identity.sql:114`  
**Migration defines**: `app.org_id` session variable for properties/work_orders  
**Live policies match**: ✅ Correctly applied

**Discrepancy**: Migration uses `app.org_id` but most application code expects `app.current_organization`

---

## Query Pattern Analysis

### Database Access Patterns
1. **Correct Pattern** (DatabaseService): `executeWithOrgContext()` → sets `app.current_organization`
2. **Alternative Pattern** (PgService): `withTransaction(orgContext)` → sets `app.org_id`  
3. **Direct Pattern** (Raw queries): No RLS context (risk)

### Code Usage Statistics
- **Work-orders module**: Uses DatabaseService (app.current_organization) but policies expect app.org_id ⚠️
- **Properties module**: Uses PgService (app.org_id) matching policies ✅
- **Identity module**: Uses PgService with platform.* tables (no RLS)

---

## Recommendations for Phase 2

### Priority 1: Session Variable Standardization
- **Action**: Align all policies to use single session variable  
- **Options**: 
  - A) Update 2 policies to use `app.current_organization`
  - B) Update 9 policies to use `app.org_id`
- **Recommended**: Option A (minimal disruption)

### Priority 2: Service Layer Consolidation  
- **Action**: Standardize on single database service pattern
- **Recommended**: Extend DatabaseService to handle both patterns during transition

### Priority 3: Webhook Security Review
- **Action**: Review webhook_events NULL organization_id policy
- **Evaluate**: Whether cross-tenant webhook access is intended

---

## Technical Appendix

### Session Variable Commands Used
```sql
-- Pattern A (PgService)
SELECT set_config('app.org_id', $1, true)

-- Pattern B (DatabaseService)  
SELECT set_config('app.current_organization', $1, false)
```

### Policy Examples
```sql
-- Standard policy (9 tables)
FOR ALL USING (organization_id = (current_setting('app.current_organization'::text, true))::uuid)

-- Properties/work_orders policy (2 tables)
FOR ALL USING (organization_id = (current_setting('app.org_id'::text, true))::uuid)

-- Webhook policy (special case)
FOR ALL USING ((organization_id IS NULL) OR (organization_id = (current_setting('app.current_organization'::text, true))::uuid))
```

---

**Scan Status**: ✅ Phase 1 Complete  
**Next Step**: Phase 2 targeted repairs based on sequential finding IDs  
**Report Format**: docs/verification/rls-scan.md + rls-scan.json
# Environment Loader

Generated: 2025-08-29T01:26:12.268Z

## Configuration Loading

- ConfigModule.forRoot({ isGlobal: true }) in apps/hr-api/src/app.module.ts
- No custom envFilePath specified, uses default .env

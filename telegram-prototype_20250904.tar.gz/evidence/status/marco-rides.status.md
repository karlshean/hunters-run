# marco-rides - System Snapshot

## Overall Status: ⛔ Blocked

Generated: 2025-08-28T00:04:11.135Z

## Git Status
- **Branch:** main
- **Commit:** a56ea67
- **Message:** WIP local changes before power loss
- **Clean:** ❌ Uncommitted changes
- **Remote:** https://github.com/karlshean/hunters-run.git

## Tests
- **Available:** ❌ No
- **Last Run:** Not run
- **Summary:** No tests found

## Last Selfcheck
- **When:** 2025-08-27T21:26:34.343Z
- **Critical Issues:** 3
- **Status:** {"FAIL":3,"INFO":4,"WARN":3,"PASS":2}

For detailed probe results, see the full selfcheck report.

## Quick Actions
```bash
# Run full selfcheck
npm run selfcheck:marco-rides

# Update snapshot  
npm run snapshot:marco-rides

# Check git status
git status
```

# mass-quest - System Snapshot

## Overall Status: ⛔ Blocked

Generated: 2025-08-28T00:04:11.588Z

## Git Status
- **Branch:** main
- **Commit:** a56ea67
- **Message:** WIP local changes before power loss
- **Clean:** ❌ Uncommitted changes
- **Remote:** https://github.com/karlshean/hunters-run.git

## Tests
- **Available:** ❌ No
- **Last Run:** Not run
- **Summary:** No tests found

## Last Selfcheck
- **When:** 2025-08-27T21:26:34.694Z
- **Critical Issues:** 3
- **Status:** {"FAIL":3,"INFO":4,"WARN":3,"PASS":2}

For detailed probe results, see the full selfcheck report.

## Quick Actions
```bash
# Run full selfcheck
npm run selfcheck:mass-quest

# Update snapshot  
npm run snapshot:mass-quest

# Check git status
git status
```

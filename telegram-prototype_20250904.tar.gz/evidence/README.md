# Evidence Bundle

Generated: 2025-08-29T01:26:12.268Z

## Purpose

This bundle contains all artifacts needed to independently verify the current state of the hunters-run platform:

- What is present and working
- What is not working and why
- Security configurations and proofs
- Database access controls
- Application status across all 7 projects

## Contents

- `consolidated/` - Latest consolidated reports and index
- `verification/` - Security proofs and RLS scans
- `status/` - Per-application status reports
- `code/` - Database services, auth middleware, migrations, scripts
- `config/` - Environment configuration (redacted)
- `runtime/` - Database role proofs and API isolation results

## Security

All sensitive values have been redacted. No real secrets are included.

## Next Steps

Upload this bundle for independent verification of the platform state.

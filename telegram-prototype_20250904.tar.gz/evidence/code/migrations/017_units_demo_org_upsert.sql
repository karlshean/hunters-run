-- 017_units_demo_org_upsert.sql
-- Idempotently ensure demo org has two baseline units.

-- 1) Ensure UNIQUE CONSTRAINT on (organization_id, unit_label)
DO $$
BEGIN
    -- add the constraint only if it doesn't exist
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint c
        JOIN pg_class t ON t.oid = c.conrelid
        JOIN pg_namespace n ON n.oid = t.relnamespace
        WHERE n.nspname = 'hr'
          AND t.relname = 'units'
          AND c.conname = 'uq_units_org_label'
    ) THEN
        ALTER TABLE hr.units
        ADD CONSTRAINT uq_units_org_label
        UNIQUE (organization_id, unit_label);
    END IF;
END$$;

-- 2) Seed/Upsert two demo units for the demo org
DO $$
DECLARE
    demo_org uuid := '00000000-0000-4000-8000-000000000001';
BEGIN
    -- set org context for any RLS policies
    PERFORM set_config('app.current_organization', demo_org::text, true);
    
    INSERT INTO hr.units (organization_id, unit_label)
    VALUES
        (demo_org, 'Unit 101'),
        (demo_org, 'Unit 202')
    ON CONFLICT (organization_id, unit_label) DO NOTHING;
END$$;
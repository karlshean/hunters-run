-- Standardize RLS session variables to app.org_id
-- Migration 021: Switch all hr.* policies from app.current_organization to app.org_id
-- Run date: 2025-08-28

DO $$
BEGIN
  -- Update hr.events policy
  IF EXISTS (SELECT FROM pg_policies WHERE schemaname = 'hr' AND tablename = 'events' AND policyname = 'p_ev') THEN
    DROP POLICY p_ev ON hr.events;
    CREATE POLICY p_ev ON hr.events 
      FOR ALL USING (organization_id = (current_setting('app.org_id'::text, true))::uuid);
    RAISE NOTICE 'Updated policy for hr.events';
  END IF;

  -- Update hr.legal_notices policy
  IF EXISTS (SELECT FROM pg_policies WHERE schemaname = 'hr' AND tablename = 'legal_notices' AND policyname = 'p_ln') THEN
    DROP POLICY p_ln ON hr.legal_notices;
    CREATE POLICY p_ln ON hr.legal_notices 
      FOR ALL USING (organization_id = (current_setting('app.org_id'::text, true))::uuid);
    RAISE NOTICE 'Updated policy for hr.legal_notices';
  END IF;

  -- Update hr.notice_templates policy
  IF EXISTS (SELECT FROM pg_policies WHERE schemaname = 'hr' AND tablename = 'notice_templates' AND policyname = 'p_nt') THEN
    DROP POLICY p_nt ON hr.notice_templates;
    CREATE POLICY p_nt ON hr.notice_templates 
      FOR ALL USING (organization_id = (current_setting('app.org_id'::text, true))::uuid);
    RAISE NOTICE 'Updated policy for hr.notice_templates';
  END IF;

  -- Update hr.payment_disputes policy
  IF EXISTS (SELECT FROM pg_policies WHERE schemaname = 'hr' AND tablename = 'payment_disputes' AND policyname = 'p_pd') THEN
    DROP POLICY p_pd ON hr.payment_disputes;
    CREATE POLICY p_pd ON hr.payment_disputes 
      FOR ALL USING (organization_id = (current_setting('app.org_id'::text, true))::uuid);
    RAISE NOTICE 'Updated policy for hr.payment_disputes';
  END IF;

  -- Update hr.service_attempts policy
  IF EXISTS (SELECT FROM pg_policies WHERE schemaname = 'hr' AND tablename = 'service_attempts' AND policyname = 'p_sa') THEN
    DROP POLICY p_sa ON hr.service_attempts;
    CREATE POLICY p_sa ON hr.service_attempts 
      FOR ALL USING (organization_id = (current_setting('app.org_id'::text, true))::uuid);
    RAISE NOTICE 'Updated policy for hr.service_attempts';
  END IF;

  -- Update hr.sms_messages policy
  IF EXISTS (SELECT FROM pg_policies WHERE schemaname = 'hr' AND tablename = 'sms_messages' AND policyname = 'p_sms') THEN
    DROP POLICY p_sms ON hr.sms_messages;
    CREATE POLICY p_sms ON hr.sms_messages 
      FOR ALL USING (organization_id = (current_setting('app.org_id'::text, true))::uuid);
    RAISE NOTICE 'Updated policy for hr.sms_messages';
  END IF;

  -- Update hr.webhook_events policy (special case - preserve NULL handling)
  IF EXISTS (SELECT FROM pg_policies WHERE schemaname = 'hr' AND tablename = 'webhook_events' AND policyname = 'p_we') THEN
    DROP POLICY p_we ON hr.webhook_events;
    CREATE POLICY p_we ON hr.webhook_events 
      FOR ALL USING ((organization_id IS NULL) OR (organization_id = (current_setting('app.org_id'::text, true))::uuid));
    RAISE NOTICE 'Updated policy for hr.webhook_events (preserved NULL handling)';
  END IF;

  -- Update hr.work_order_transitions policy
  IF EXISTS (SELECT FROM pg_policies WHERE schemaname = 'hr' AND tablename = 'work_order_transitions' AND policyname = 'work_order_transitions_org_rls') THEN
    DROP POLICY work_order_transitions_org_rls ON hr.work_order_transitions;
    CREATE POLICY work_order_transitions_org_rls ON hr.work_order_transitions 
      FOR ALL USING (organization_id = (current_setting('app.org_id'::text, true))::uuid);
    RAISE NOTICE 'Updated policy for hr.work_order_transitions';
  END IF;

  -- Preserve RLS enablement for all tables (idempotent)
  ALTER TABLE hr.events ENABLE ROW LEVEL SECURITY;
  ALTER TABLE hr.legal_notices ENABLE ROW LEVEL SECURITY;
  ALTER TABLE hr.notice_templates ENABLE ROW LEVEL SECURITY;
  ALTER TABLE hr.payment_disputes ENABLE ROW LEVEL SECURITY;
  ALTER TABLE hr.service_attempts ENABLE ROW LEVEL SECURITY;
  ALTER TABLE hr.sms_messages ENABLE ROW LEVEL SECURITY;
  ALTER TABLE hr.webhook_events ENABLE ROW LEVEL SECURITY;
  ALTER TABLE hr.work_order_transitions ENABLE ROW LEVEL SECURITY;

  RAISE NOTICE 'RLS session variable standardization complete - all hr.* policies now use app.org_id';

END
$$;
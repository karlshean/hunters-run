-- Platform identity schema
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE SCHEMA IF NOT EXISTS platform;

-- Core user identity (external provider mapping)
CREATE TABLE IF NOT EXISTS platform.users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  external_provider text NOT NULL,
  external_sub text NOT NULL,
  email text,
  last_seen_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (external_provider, external_sub)
);

-- Organizations with soft-delete capability
CREATE TABLE IF NOT EXISTS platform.organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'archived')),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Permission templates (role definitions)
CREATE TABLE IF NOT EXISTS platform.roles (
  name text PRIMARY KEY,
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Role permission mappings with validation
CREATE TABLE IF NOT EXISTS platform.role_permissions (
  role_name text NOT NULL REFERENCES platform.roles(name) ON DELETE CASCADE,
  permission text NOT NULL CHECK (permission ~ '^[a-z]+\.[a-z_]+:(create|read|update|delete)'),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (role_name, permission)
);

-- User organization membership with roles
CREATE TABLE IF NOT EXISTS platform.memberships (
  user_id uuid NOT NULL REFERENCES platform.users(id) ON DELETE CASCADE,
  organization_id uuid NOT NULL REFERENCES platform.organizations(id) ON DELETE RESTRICT,
  role_name text NOT NULL REFERENCES platform.roles(name),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, organization_id)
);

-- Individual permission overrides
CREATE TABLE IF NOT EXISTS platform.user_permissions (
  user_id uuid NOT NULL REFERENCES platform.users(id) ON DELETE CASCADE,
  organization_id uuid NOT NULL REFERENCES platform.organizations(id) ON DELETE RESTRICT,
  permission text NOT NULL CHECK (permission ~ '^[a-z]+\.[a-z_]+:(create|read|update|delete)'),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, organization_id, permission)
);

-- Audit events table
CREATE TABLE IF NOT EXISTS platform.audit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  user_id uuid,
  organization_id uuid,
  metadata jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Performance indexes
CREATE INDEX IF NOT EXISTS idx_users_external ON platform.users (external_provider, external_sub);
CREATE INDEX IF NOT EXISTS idx_users_email ON platform.users (email);
CREATE INDEX IF NOT EXISTS idx_memberships_org ON platform.memberships (organization_id);
CREATE INDEX IF NOT EXISTS idx_memberships_user ON platform.memberships (user_id);
CREATE INDEX IF NOT EXISTS idx_user_perms_user_org ON platform.user_permissions (user_id, organization_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_type ON platform.audit_events (event_type);
CREATE INDEX IF NOT EXISTS idx_audit_events_created ON platform.audit_events (created_at);

-- Seed default roles (order matters)
INSERT INTO platform.roles (name, description) VALUES 
  ('hr_admin', 'Full access to HR operations'),
  ('hr_member', 'Basic HR operations access'),
  ('viewer', 'Read-only access')
ON CONFLICT DO NOTHING;

-- Seed role permissions
INSERT INTO platform.role_permissions (role_name, permission) VALUES
  ('hr_admin', 'hr.work_orders:create'),
  ('hr_admin', 'hr.work_orders:read'),
  ('hr_admin', 'hr.work_orders:update'),
  ('hr_admin', 'hr.work_orders:delete'),
  ('hr_admin', 'hr.properties:create'),
  ('hr_admin', 'hr.properties:read'),
  ('hr_admin', 'hr.properties:update'),
  ('hr_admin', 'hr.properties:delete'),
  ('hr_member', 'hr.work_orders:create'),
  ('hr_member', 'hr.work_orders:read'),
  ('hr_member', 'hr.work_orders:update'),
  ('hr_member', 'hr.properties:read'),
  ('viewer', 'hr.work_orders:read'),
  ('viewer', 'hr.properties:read')
ON CONFLICT DO NOTHING;

-- Seed demo organization
INSERT INTO platform.organizations (id, name) VALUES 
  ('00000000-0000-4000-8000-000000000001', 'Demo Organization')
ON CONFLICT DO NOTHING;

-- Enable Row Level Security on HR tables
DO $$
BEGIN
  -- Enable RLS on properties table if it exists
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_schema = 'hr' AND table_name = 'properties') THEN
    ALTER TABLE hr.properties ENABLE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS properties_org_rls ON hr.properties;
    CREATE POLICY properties_org_rls ON hr.properties 
      FOR ALL USING (organization_id = (current_setting('app.org_id'::text, true))::uuid);
  END IF;

  -- Enable RLS on work_orders table if it exists  
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_schema = 'hr' AND table_name = 'work_orders') THEN
    ALTER TABLE hr.work_orders ENABLE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS work_orders_org_rls ON hr.work_orders;
    CREATE POLICY work_orders_org_rls ON hr.work_orders 
      FOR ALL USING (organization_id = (current_setting('app.org_id'::text, true))::uuid);
  END IF;
END
$$;
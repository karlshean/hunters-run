# Database Migrations

## 017_units_demo_org_upsert.sql

This migration ensures the demo organization has the required baseline units with proper constraints.

### What it does:

1. **Adds UNIQUE constraint** `uq_units_org_label` on `(organization_id, unit_label)`
   - Prevents duplicate unit labels within the same organization
   - Uses proper constraint (not just index) for `ON CONFLICT` support
   - Idempotent - only adds if constraint doesn't exist

2. **Seeds demo units** for organization `00000000-0000-4000-8000-000000000001`
   - Unit 101
   - Unit 202
   - Uses `ON CONFLICT (organization_id, unit_label) DO NOTHING`
   - Safe to run multiple times

### Running the migration:

```sql
-- Connect to your database and run:
\i packages/db/migrations/017_units_demo_org_upsert.sql
```

Or using your migration runner:
```bash
# If you have a migration runner
npm run migrate -- 017
```

### Verification:

**Option 1: Database query**
```sql
-- Check constraint exists
SELECT c.conname, c.contype
FROM pg_constraint c
JOIN pg_class t ON t.oid = c.conrelid
JOIN pg_namespace n ON n.oid = t.relnamespace
WHERE n.nspname = 'hr'
  AND t.relname = 'units'
  AND c.conname = 'uq_units_org_label';

-- Check demo units exist
SELECT unit_label 
FROM hr.units 
WHERE organization_id = '00000000-0000-4000-8000-000000000001'
ORDER BY unit_label;
```

**Option 2: Script verification**
```bash
# Requires DATABASE_URL environment variable
node scripts/verify-units-constraint.mjs
```

**Option 3: API selfcheck**
```bash
# PowerShell (Windows)
scripts/selfcheck-demo-units.ps1

# Node.js
npm run selfcheck:rls
```

### Expected Results:

- ✅ Constraint `uq_units_org_label` exists
- ✅ Demo org contains "Unit 101" and "Unit 202"  
- ✅ Duplicate inserts are rejected with unique violation error
- ✅ Migration can be run multiple times safely

### Rollback:

If you need to rollback this migration:

```sql
-- Remove demo units (optional)
DELETE FROM hr.units 
WHERE organization_id = '00000000-0000-4000-8000-000000000001'
  AND unit_label IN ('Unit 101', 'Unit 202');

-- Remove constraint
ALTER TABLE hr.units DROP CONSTRAINT IF EXISTS uq_units_org_label;
```

### Integration with Self-Checks:

The self-check scripts now verify **presence of required labels** rather than counting total items:

- ✅ Case-insensitive label matching
- ✅ Works regardless of additional units in the organization
- ✅ Clear error messages for missing baseline units
- ✅ Support for both `name` and `unit_label` fields
import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
  ForbiddenException,
  BadRequestException,
  Logger
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Request } from 'express';
import { validate as uuidValidate } from 'uuid';
import { TokenAdapter, TokenClaims } from '../token/token-adapter';
import { IdentityService, Principal } from '../../identity/identity.service';
import { REQUIRE_PERMISSIONS_KEY } from '../decorators/require-permission.decorator';
import { REQUIRE_ORG_KEY } from '../decorators/require-org.decorator';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';
import { RequestContextMiddleware } from '../../common/request-context.middleware';

@Injectable()
export class CompositeAuthzGuard implements CanActivate {
  private readonly logger = new Logger(CompositeAuthzGuard.name);

  constructor(
    private readonly tokenAdapter: TokenAdapter,
    private readonly identity: IdentityService,
    private readonly reflector: Reflector,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<Request & { principal?: Principal }>();
    
    // Check if this is a public endpoint
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) {
      return true;
    }
    
    // Check if this endpoint requires org context
    const requiresOrg = this.reflector.getAllAndOverride<boolean>(
      REQUIRE_ORG_KEY,
      [context.getHandler(), context.getClass()],
    ) || false;
    
    // 1. Require and validate organization context
    const orgId = request.headers['x-org-id'] as string;
    if (requiresOrg && !orgId) {
      throw new BadRequestException('Organization ID required in x-org-id header');
    }
    
    if (orgId && !uuidValidate(orgId)) {
      throw new BadRequestException('Invalid organization ID format');
    }

    // 2. Handle dev bypass
    if (process.env.DEV_AUTH_BYPASS === 'true') {
      const devSub = process.env.DEV_USER_SUB;
      if (!devSub) {
        throw new UnauthorizedException('DEV_USER_SUB required when DEV_AUTH_BYPASS=true');
      }
      
      if (!orgId) {
        throw new BadRequestException('Organization ID required for dev bypass');
      }
      
      const principal = await this.identity.resolvePrincipal(orgId, 'dev', devSub);
      if (!principal) {
        throw new ForbiddenException('Not authorized');
      }
      
      request.principal = principal;
      this.setRequestContext(principal);
      return this.checkPermissions(context, principal);
    }

    // 3. Extract and verify token
    const authHeader = request.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      throw new UnauthorizedException('Bearer token required');
    }

    let claims: TokenClaims;
    try {
      claims = await this.tokenAdapter.verify(authHeader);
    } catch (error) {
      this.logger.warn(`Token verification failed: ${error.message}`);
      throw new UnauthorizedException('Invalid token');
    }

    const externalSub = claims.sub || claims.uid;
    if (!externalSub) {
      throw new UnauthorizedException('Token missing subject identifier');
    }

    // 4. Resolve to internal principal  
    // Determine provider based on token characteristics
    const provider = this.isDevelopmentToken(authHeader) ? 'dev' : 'firebase';
    const principal = await this.identity.resolvePrincipal(
      orgId, 
      provider, 
      externalSub, 
      claims.email
    );

    if (!principal) {
      // Uniform 403 - don't reveal whether user exists or just lacks membership
      throw new ForbiddenException('Not authorized');
    }

    request.principal = principal;
    this.setRequestContext(principal);

    // 5. Check required permissions
    return this.checkPermissions(context, principal);
  }

  private checkPermissions(context: ExecutionContext, principal: Principal): boolean {
    const requiredPermissions = this.reflector.getAllAndOverride<string[]>(
      REQUIRE_PERMISSIONS_KEY,
      [context.getHandler(), context.getClass()],
    ) || [];

    if (requiredPermissions.length === 0) {
      return true;
    }

    const hasAllPermissions = requiredPermissions.every(permission => 
      principal.permissions.has(permission)
    );

    if (!hasAllPermissions) {
      // Log for audit but don't reveal specific missing permissions to client
      this.logger.warn(
        `Permission denied: user ${principal.userId} in org ${principal.orgId} missing required permissions`
      );
      throw new ForbiddenException('Not authorized');
    }

    return true;
  }

  private setRequestContext(principal: Principal): void {
    RequestContextMiddleware.setContext({
      userId: principal.userId,
      organizationId: principal.orgId,
      permissions: Array.from(principal.permissions),
      userEmail: principal.email,
      sub: principal.sub,
      provider: principal.provider
    });
  }

  private isDevelopmentToken(authHeader: string): boolean {
    const token = authHeader.substring(7); // Remove 'Bearer '
    return token.startsWith('dev-') || token === 'test-token' || token.length < 50;
  }
}
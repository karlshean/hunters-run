import { Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { CompositeAuthzGuard } from './guards/composite-authz.guard';
import { TokenAdapter } from './token/token-adapter';
import { AuthController } from './auth.controller';
import { IdentityModule } from '../identity/identity.module';

@Module({
  imports: [IdentityModule],
  controllers: [AuthController],
  providers: [
    TokenAdapter,
    {
      provide: APP_GUARD,
      useClass: CompositeAuthzGuard,
    },
  ],
  exports: [TokenAdapter],
})
export class AuthModule {}
import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import * as admin from 'firebase-admin';

export interface TokenClaims {
  sub: string;
  uid: string;
  email?: string;
  email_verified?: boolean;
  iss?: string;
  aud?: string;
  iat?: number;
  exp?: number;
}

@Injectable()
export class TokenAdapter implements OnModuleInit {
  private readonly logger = new Logger(TokenAdapter.name);
  private firebaseInitialized = false;

  async onModuleInit() {
    await this.initializeFirebase();
  }

  private async initializeFirebase(): Promise<void> {
    try {
      // Check if Firebase is already initialized
      if (admin.apps.length > 0) {
        this.firebaseInitialized = true;
        this.logger.log('Firebase Admin SDK already initialized');
        return;
      }

      const projectId = process.env.FIREBASE_PROJECT_ID;
      const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
      const privateKey = process.env.FIREBASE_PRIVATE_KEY;

      if (!projectId) {
        this.logger.warn('FIREBASE_PROJECT_ID not set - Firebase authentication disabled');
        return;
      }

      // Initialize with service account credentials if available
      if (clientEmail && privateKey) {
        const serviceAccount = {
          projectId,
          clientEmail,
          privateKey: privateKey.replace(/\\n/g, '\n'), // Handle escaped newlines
        };

        admin.initializeApp({
          credential: admin.credential.cert(serviceAccount),
          projectId: projectId,
        });

        this.firebaseInitialized = true;
        this.logger.log('Firebase Admin SDK initialized with service account');
      } else {
        // Try to initialize with Application Default Credentials
        try {
          admin.initializeApp({
            projectId: projectId,
          });
          this.firebaseInitialized = true;
          this.logger.log('Firebase Admin SDK initialized with default credentials');
        } catch (error) {
          this.logger.warn(`Firebase initialization failed: ${error.message}`);
          this.logger.warn('Falling back to development mode token validation');
        }
      }
    } catch (error) {
      this.logger.error(`Firebase initialization error: ${error.message}`);
      this.logger.warn('Firebase authentication will be disabled');
    }
  }

  async verify(authHeader: string): Promise<TokenClaims> {
    const token = authHeader.substring(7); // Remove 'Bearer ' prefix
    
    // Handle development test tokens
    if (this.isDevelopmentTestToken(token)) {
      return this.handleDevelopmentToken(token);
    }

    // Try Firebase verification if initialized
    if (this.firebaseInitialized) {
      try {
        const decodedToken = await admin.auth().verifyIdToken(token);
        return {
          sub: decodedToken.uid,
          uid: decodedToken.uid,
          email: decodedToken.email,
          email_verified: decodedToken.email_verified,
          iss: decodedToken.iss,
          aud: decodedToken.aud,
          iat: decodedToken.iat,
          exp: decodedToken.exp,
        };
      } catch (error) {
        this.logger.warn(`Firebase token verification failed: ${error.message}`);
        throw new Error('Invalid Firebase token');
      }
    }

    // Fallback: try to decode as JWT for development/testing
    return this.handleJwtToken(token);
  }

  private isDevelopmentTestToken(token: string): boolean {
    return token.startsWith('dev-') || token === 'test-token' || token.length < 50;
  }

  private handleDevelopmentToken(token: string): TokenClaims {
    // Handle specific development tokens
    const devTokens: Record<string, TokenClaims> = {
      'dev-token': {
        sub: 'dev-user-123',
        uid: 'dev-user-123',
        email: 'dev@example.com',
        email_verified: true,
      },
      'dev-token-org-b': {
        sub: 'user-org-b',
        uid: 'user-org-b',
        email: 'userb@example.com',
        email_verified: true,
      },
      'dev-admin': {
        sub: 'dev-admin-456',
        uid: 'dev-admin-456',
        email: 'admin@example.com',
        email_verified: true,
      },
      'test-token': {
        sub: 'test-user-789',
        uid: 'test-user-789',
        email: 'test@example.com',
        email_verified: true,
      },
    };

    if (devTokens[token]) {
      this.logger.debug(`Using development token: ${token}`);
      return devTokens[token];
    }

    // Handle dynamic dev tokens like "dev-user-123"
    if (token.startsWith('dev-user-')) {
      const userId = token.substring(4); // Remove 'dev-'
      return {
        sub: userId,
        uid: userId,
        email: `${userId}@dev.example.com`,
        email_verified: true,
      };
    }

    throw new Error(`Unknown development token: ${token}`);
  }

  private handleJwtToken(token: string): TokenClaims {
    try {
      // Basic JWT decoding (UNSAFE for production)
      const parts = token.split('.');
      if (parts.length !== 3) {
        throw new Error('Invalid JWT format');
      }

      const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
      
      if (!payload.sub && !payload.uid) {
        throw new Error('Token missing subject identifier');
      }

      return {
        sub: payload.sub || payload.uid,
        uid: payload.uid || payload.sub,
        email: payload.email,
        email_verified: payload.email_verified,
        iss: payload.iss,
        aud: payload.aud,
        iat: payload.iat,
        exp: payload.exp,
      };
    } catch (error) {
      this.logger.warn(`JWT token decoding failed: ${error.message}`);
      throw new Error('Invalid token format');
    }
  }

  isFirebaseInitialized(): boolean {
    return this.firebaseInitialized;
  }
}
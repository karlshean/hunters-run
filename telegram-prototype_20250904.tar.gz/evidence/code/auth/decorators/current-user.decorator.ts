import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { RequestContextMiddleware } from '../../common/request-context.middleware';

export interface CurrentUserData {
  id: string;
  organizationId: string;
  email?: string;
  sub: string;
  provider: string;
  permissions: string[];
}

export const CurrentUser = createParamDecorator(
  (data: unknown, ctx: ExecutionContext): CurrentUserData | null => {
    const context = RequestContextMiddleware.getCurrentContext();
    
    if (!context?.userId || !context?.organizationId) {
      return null;
    }

    return {
      id: context.userId,
      organizationId: context.organizationId,
      email: context.userEmail,
      sub: context.sub || '',
      provider: context.provider || '',
      permissions: context.permissions || []
    };
  },
);
import { SetMetadata } from '@nestjs/common';

export const REQUIRE_ORG_KEY = 'require_org';

/**
 * Decorator that requires the user to have an organization context.
 * This ensures RLS policies have the necessary org context to filter data.
 */
export const RequireOrg = () => SetMetadata(REQUIRE_ORG_KEY, true);
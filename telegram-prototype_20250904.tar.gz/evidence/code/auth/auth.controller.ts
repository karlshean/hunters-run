import { Controller, Get } from '@nestjs/common';
import { CurrentPrincipal } from './decorators/current-principal.decorator';
import { Principal } from '../identity/identity.service';

@Controller('auth')
export class AuthController {
  @Get('echo')
  async echo(@CurrentPrincipal() principal: Principal) {
    return {
      userId: principal.userId,
      orgId: principal.orgId,
      permissions: Array.from(principal.permissions).sort(),
      email: principal.email || null
    };
  }
}
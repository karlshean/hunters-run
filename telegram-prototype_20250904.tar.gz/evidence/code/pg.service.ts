import { Injectable, OnModuleDestroy } from '@nestjs/common';
import { Pool, PoolClient, QueryResult } from 'pg';
import { RequestContextMiddleware } from '../common/request-context.middleware';

export type OrgContext = { orgId: string; userId?: string };

@Injectable()
export class PgService implements OnModuleDestroy {
  private pool: Pool;

  constructor() {
    const connectionString = process.env.DATABASE_URL!;
    if (!connectionString) throw new Error('DATABASE_URL is required');

    const sslMode = (process.env.DB_SSL_MODE || 'strict').toLowerCase();
    const ssl =
      sslMode === 'relaxed'
        ? { rejectUnauthorized: false }
        : { rejectUnauthorized: true };

    this.pool = new Pool({ connectionString, ssl });
  }

  async query<T = any>(
    text: string,
    values?: any[],
    orgContext?: OrgContext,
  ): Promise<QueryResult<T>> {
    // Use explicit org context or try to get from request context
    const effectiveContext = orgContext || this.getCurrentOrgContext();
    
    if (!effectiveContext) {
      // No org context available - query without RLS context (dangerous!)
      return this.pool.query<T>(text, values);
    }
    
    return this.withClient(async (client) => {
      await this.setRlsContext(client, effectiveContext);
      return client.query<T>(text, values);
    });
  }

  async withClient<T>(fn: (client: PoolClient) => Promise<T>): Promise<T> {
    const client = await this.pool.connect();
    try {
      return await fn(client);
    } finally {
      // Reset role to avoid connection pool pollution
      try {
        await client.query('RESET ROLE');
      } catch (e) {
        // Log but don't throw - connection cleanup shouldn't fail the operation
        console.warn('Failed to reset role during client cleanup:', e.message);
      }
      client.release();
    }
  }

  async withTransaction<T>(
    orgContext: OrgContext,
    fn: (client: PoolClient) => Promise<T>,
  ): Promise<T> {
    return this.withClient(async (client) => {
      await client.query('BEGIN');
      try {
        await this.setRlsContext(client, orgContext);
        const out = await fn(client);
        await client.query('COMMIT');
        return out;
      } catch (e) {
        try {
          await client.query('ROLLBACK');
        } catch {}
        throw e;
      }
    });
  }

  private getCurrentOrgContext(): OrgContext | null {
    const context = RequestContextMiddleware.getCurrentContext();
    if (!context?.organizationId) {
      return null;
    }
    
    return {
      orgId: context.organizationId,
      userId: context.userId
    };
  }

  private async setRlsContext(client: PoolClient, ctx: OrgContext) {
    // SECURITY FIX: Switch to app_user role to disable BYPASSRLS privilege
    // This enables true RLS enforcement even when connected as postgres
    await client.query('SET ROLE app_user');
    
    await client.query(
      `SELECT set_config('app.org_id', $1, false), 
              set_config('app.current_user', $2, false),
              set_config('row_security', 'on', false)`,
      [ctx.orgId, ctx.userId || 'system'],
    );
  }

  async onModuleDestroy() {
    await this.pool.end();
  }
}
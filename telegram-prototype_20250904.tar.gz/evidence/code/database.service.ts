import { Injectable, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { Pool, PoolClient } from 'pg';

function sslOption() {
  // Support DB_SSL_MODE for consistency with PgService
  const sslMode = (process.env.DB_SSL_MODE || 'strict').toLowerCase();
  if (sslMode === 'relaxed') {
    return { ssl: { rejectUnauthorized: false } };
  }
  // Default: enable SSL using pg defaults; set DB_STRICT_SSL=true to enforce CA verification.
  return process.env.DB_STRICT_SSL === 'true'
    ? { ssl: { rejectUnauthorized: true } }
    : { ssl: true };
}

@Injectable()
export class DatabaseService implements OnModuleInit, OnModuleDestroy {
  private pool!: Pool;
  private ready = false;

  constructor() {
    const usePooler = process.env.USE_POOLER === 'true';
    const cs = usePooler ? process.env.POOLER_URL : process.env.DATABASE_URL;
    if (!cs) throw new Error(usePooler ? 'POOLER_URL required' : 'DATABASE_URL required');

    const u = new URL(cs);
    const port = Number(u.port || (usePooler ? 6543 : 5432));
    const sslMode = process.env.DB_STRICT_SSL === 'true' ? 'strict' : 'default';

    console.log(`[db] using ${usePooler ? 'POOLER_URL' : 'DATABASE_URL'} host=${u.hostname} port=${port} ssl=${sslMode}`);

    this.pool = new Pool({
      connectionString: cs,
      max: Number(process.env.PG_POOL_MAX || 10),
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 5_000,
      ...sslOption(),
    });
  }

  async onModuleInit() {
    // Fail fast: if DB is unreachable, throw here and prevent boot.
    const client = await this.pool.connect();
    try {
      await client.query('select 1');
      this.ready = true;
      console.log('[db] connectivity check OK');
    } finally {
      client.release();
    }
  }

  isReady() {
    return this.ready;
  }

  async onModuleDestroy() {
    await this.pool.end().catch(() => {});
  }

  async query(text: string, params?: any[]): Promise<any> {
    if (!this.ready) throw new Error('Database not ready');
    return this.pool.query(text, params);
  }

  async withClient<T>(fn: (client: PoolClient) => Promise<T>): Promise<T> {
    if (!this.ready) throw new Error('Database not ready');
    const client = await this.pool.connect();
    try { return await fn(client); } finally { client.release(); }
  }

  async setOrgContext(client: PoolClient, orgId: string) {
    // Standardized to app.org_id for all hr.* tables (Migration 021)
    // NOTE: Supabase postgres user has BYPASSRLS privilege which overrides row_security
    // RLS policies are in place but need manual enforcement for BYPASSRLS users
    await client.query('SELECT set_config($1,$2,false), set_config($3,$4,false)', 
      ['app.org_id', orgId, 'row_security', 'on']);
  }

  async executeWithOrgContext<T>(orgId: string, fn: (client: PoolClient) => Promise<T>): Promise<T> {
    return this.withClient(async (client) => {
      await this.setOrgContext(client, orgId);
      return fn(client);
    });
  }
}
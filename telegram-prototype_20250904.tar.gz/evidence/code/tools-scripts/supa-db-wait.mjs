#!/usr/bin/env node
// DB: Supabase database wait utility
// Polls supa-db-ping.mjs until database is ready or timeout

import { spawn } from 'child_process';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

/**
 * Execute supa-db-ping.mjs and return success status
 */
async function checkDatabase(envFile) {
  return new Promise((resolve) => {
    const args = envFile ? [join(__dirname, 'supa-db-ping.mjs'), envFile] : [join(__dirname, 'supa-db-ping.mjs')];
    const child = spawn('node', args, {
      stdio: ['inherit', 'pipe', 'pipe']
    });
    
    let output = '';
    child.stdout.on('data', (data) => {
      output += data.toString();
    });
    
    child.stderr.on('data', (data) => {
      output += data.toString();
    });
    
    child.on('close', (code) => {
      resolve({ success: code === 0, output });
    });
  });
}

/**
 * Wait for database to be ready with polling
 */
async function waitForDatabase(envFile, timeoutSeconds = 30) {
  console.log('=== SUPABASE DATABASE WAIT ===\n');
  console.log(`Waiting for database to be ready (timeout: ${timeoutSeconds}s)...\n`);
  
  const startTime = Date.now();
  const timeoutMs = timeoutSeconds * 1000;
  let attemptCount = 0;
  
  while (Date.now() - startTime < timeoutMs) {
    attemptCount++;
    console.log(`Attempt ${attemptCount}: Checking database connectivity...`);
    
    const result = await checkDatabase(envFile);
    
    if (result.success) {
      console.log('✅ Database is ready!\n');
      console.log(result.output);
      return true;
    }
    
    const elapsed = Math.round((Date.now() - startTime) / 1000);
    const remaining = timeoutSeconds - elapsed;
    
    if (remaining <= 0) {
      break;
    }
    
    console.log(`❌ Not ready yet. Waiting 2 seconds... (${remaining}s remaining)\n`);
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
  
  console.log('❌ TIMEOUT: Database not ready within timeout period');
  console.log('');
  console.log('Last check result:');
  const finalResult = await checkDatabase(envFile);
  console.log(finalResult.output);
  
  return false;
}

// Main execution
async function main() {
  const args = process.argv.slice(2);
  let envFile = null;
  let timeout = 30;
  
  // Parse arguments
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg.startsWith('--timeout=')) {
      timeout = parseInt(arg.split('=')[1]) || 30;
    } else if (arg === '--timeout' && i + 1 < args.length) {
      timeout = parseInt(args[i + 1]) || 30;
      i++; // Skip next argument
    } else if (!arg.startsWith('--')) {
      envFile = arg;
    }
  }
  
  const success = await waitForDatabase(envFile, timeout);
  process.exit(success ? 0 : 1);
}

main().catch(error => {
  console.error('Unexpected error:', error.message);
  process.exit(1);
});
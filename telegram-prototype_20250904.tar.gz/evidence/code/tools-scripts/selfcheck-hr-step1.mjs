#!/usr/bin/env node
// G3-3: Focused Hunters Run step-one check (today's unblocker)
// Tight loop for immediate connectivity and compilation issues

import { spawn, exec } from 'child_process';
import { promisify } from 'util';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, dirname, resolve } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const execAsync = promisify(exec);

/**
 * Load environment using dotenv if available
 */
async function loadEnvWithDotenv(envPath) {
  try {
    const dotenv = await import('dotenv');
    dotenv.config({ path: envPath });
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Load environment variables from .env file
 */
function loadEnvFile(envPath) {
  try {
    if (!existsSync(envPath)) {
      return false;
    }
    
    const envContent = readFileSync(envPath, 'utf8');
    const lines = envContent.split('\n');
    
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed && !trimmed.startsWith('#')) {
        const [key, ...valueParts] = trimmed.split('=');
        if (key && valueParts.length > 0) {
          const value = valueParts.join('=').replace(/^["']|["']$/g, '');
          process.env[key.trim()] = value;
        }
      }
    }
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Execute a command and return result
 */
async function execCommand(command, options = {}) {
  try {
    const { stdout, stderr } = await execAsync(command, {
      timeout: options.timeout || 30000,
      ...options
    });
    return { success: true, stdout, stderr };
  } catch (error) {
    return { 
      success: false, 
      stdout: error.stdout || '', 
      stderr: error.stderr || error.message,
      code: error.code
    };
  }
}

/**
 * Step 1: Database connectivity check
 */
async function checkDatabaseConnectivity() {
  console.log('🔗 Step 1: Checking database connectivity...');
  
  try {
    const result = await execCommand(`node "${join(__dirname, 'supa-db-ping.mjs')}"`, {
      timeout: 10000
    });
    
    if (result.success) {
      console.log('✅ Database connectivity: PASS');
      return true;
    } else {
      console.log('❌ Database connectivity: FAIL');
      console.log('   Run "node tools/scripts/supa-db-ping.mjs" for detailed diagnostics');
      return false;
    }
  } catch (error) {
    console.log(`❌ Database connectivity: ERROR - ${error.message}`);
    return false;
  }
}

/**
 * Step 2: TypeScript compilation check for hunters-run
 */
async function checkTypeScriptBuild() {
  console.log('\\n🔨 Step 2: Checking TypeScript compilation...');
  
  const appPath = resolve(__dirname, '../../apps/hunters-run');
  const tsconfigPath = join(appPath, 'tsconfig.json');
  
  if (!existsSync(tsconfigPath)) {
    console.log('ℹ️  No TypeScript configuration found');
    return true;
  }
  
  try {
    const result = await execCommand(`npx tsc -p "${tsconfigPath}" --noEmit`, {
      timeout: 30000,
      cwd: appPath
    });
    
    if (result.success) {
      console.log('✅ TypeScript compilation: PASS');
      return true;
    } else {
      console.log('❌ TypeScript compilation: FAIL');
      console.log('\\nCompilation errors:');
      if (result.stderr) {
        console.log(result.stderr);
      }
      return false;
    }
  } catch (error) {
    console.log(`❌ TypeScript compilation: ERROR - ${error.message}`);
    return false;
  }
}

/**
 * Step 3: Firebase configuration checks
 */
async function checkFirebaseConfig() {
  console.log('\\n🔐 Step 3: Checking Firebase configuration...');
  
  const required = ['FIREBASE_PROJECT_ID', 'FIREBASE_CLIENT_EMAIL', 'FIREBASE_PRIVATE_KEY'];
  const missing = required.filter(varName => !process.env[varName]);
  
  if (missing.length > 0) {
    console.log(`❌ Firebase config: FAIL - Missing variables: ${missing.join(', ')}`);
    console.log('   💡 Add Firebase service account credentials to .env file');
    return false;
  }
  
  // Check private key format
  const privateKey = process.env.FIREBASE_PRIVATE_KEY;
  if (!privateKey.includes('BEGIN PRIVATE KEY')) {
    console.log('⚠️  Firebase config: WARN - Private key format may be invalid');
    console.log('   💡 Ensure FIREBASE_PRIVATE_KEY includes header and uses \\\\n escaping');
    return true; // Warning, not failure
  }
  
  if (!privateKey.includes('\\\\n')) {
    console.log('⚠️  Firebase config: WARN - Private key may need \\\\n newline escaping');
    console.log('   💡 Quote the private key and use \\\\n for newlines');
    return true; // Warning, not failure
  }
  
  console.log('✅ Firebase configuration: PASS');
  return true;
}

/**
 * Generate step1 report
 */
function generateStep1Report(results) {
  const handoverDir = resolve(__dirname, '../../docs/handover');
  
  if (!existsSync(handoverDir)) {
    mkdirSync(handoverDir, { recursive: true });
  }
  
  const allPassed = results.every(r => r);
  const status = allPassed ? '✅ Ready' : '🚫 Blocked';
  
  const content = `# Hunters Run - Step 1 Readiness Check

## Status: ${status}

Generated: ${new Date().toISOString()}

This is a focused check of the most critical blockers for immediate development.

## Critical Requirements

- **Database Connectivity:** ${results[0] ? '✅ PASS' : '❌ FAIL'}
- **TypeScript Compilation:** ${results[1] ? '✅ PASS' : '❌ FAIL'} 
- **Firebase Configuration:** ${results[2] ? '✅ PASS' : '❌ FAIL'}

## Next Steps

${allPassed ? `
🎉 **Ready for development!**

1. Run \`npm run selfcheck:hunters-run\` for comprehensive checks
2. Start the development server with \`npm run dev:api\`
3. Begin implementing business features
` : `
🔧 **Fix blockers first:**

1. Address any FAIL items above
2. Re-run this check: \`npm run selfcheck:hunters-run:step1\`
3. Once all PASS, run full selfcheck: \`npm run selfcheck:hunters-run\`
`}

## Quick Commands

\`\`\`bash
# Fix database issues
node tools/scripts/supa-db-ping.mjs

# Check TypeScript 
npx tsc -p apps/hunters-run/tsconfig.json --noEmit

# Re-run this check
npm run selfcheck:hunters-run:step1
\`\`\`
`;

  writeFileSync(join(handoverDir, 'hunters-run.step1.md'), content);
  console.log(`\\n📋 Report: docs/handover/hunters-run.step1.md`);
}

// Main execution
async function main() {
  console.log('=== HUNTERS RUN STEP 1 READINESS CHECK ===\\n');
  
  // Load environment variables
  const envFile = resolve(__dirname, '../../apps/hunters-run/.env');
  const dotenvLoaded = await loadEnvWithDotenv(envFile);
  const envLoaded = dotenvLoaded || loadEnvFile(envFile);
  
  if (envLoaded) {
    console.log(`📁 Loaded environment from: ${envFile}\\n`);
  } else {
    console.log('⚠️  No .env file found - using system environment variables\\n');
  }
  
  // Run critical checks
  const results = [
    await checkDatabaseConnectivity(),
    await checkTypeScriptBuild(), 
    await checkFirebaseConfig()
  ];
  
  generateStep1Report(results);
  
  const allPassed = results.every(r => r);
  const exitCode = allPassed ? 0 : 1;
  
  console.log('\\n=== STEP 1 SUMMARY ===');
  console.log(allPassed ? '✅ All critical checks PASSED - ready for development!' : 
              '❌ Some checks FAILED - fix blockers before continuing');
  
  process.exit(exitCode);
}

main().catch(error => {
  console.error('Step 1 check failed:', error.message);
  process.exit(1);
});
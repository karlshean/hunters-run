#!/usr/bin/env node
// G3-2: Robust selfcheck engine for all applications
// Executes comprehensive probes and generates JSON/Markdown reports

import { spawn, exec } from 'child_process';
import { promisify } from 'util';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, dirname, resolve } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const execAsync = promisify(exec);

/**
 * Load environment using dotenv if available
 */
async function loadEnvWithDotenv(envPath) {
  try {
    const dotenv = await import('dotenv');
    dotenv.config({ path: envPath });
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Probe result structure
 */
const PROBE_STATUS = {
  PASS: 'PASS',
  WARN: 'WARN', 
  FAIL: 'FAIL',
  INFO: 'INFO'
};

/**
 * Load environment variables from .env file
 */
function loadEnvFile(envPath) {
  try {
    if (!existsSync(envPath)) {
      return false;
    }
    
    const envContent = readFileSync(envPath, 'utf8');
    const lines = envContent.split('\n');
    
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed && !trimmed.startsWith('#')) {
        const [key, ...valueParts] = trimmed.split('=');
        if (key && valueParts.length > 0) {
          const value = valueParts.join('=').replace(/^["']|["']$/g, '');
          process.env[key.trim()] = value;
        }
      }
    }
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Execute a command and return result
 */
async function execCommand(command, options = {}) {
  try {
    const { stdout, stderr } = await execAsync(command, {
      timeout: options.timeout || 30000,
      ...options
    });
    return { success: true, stdout, stderr };
  } catch (error) {
    return { 
      success: false, 
      stdout: error.stdout || '', 
      stderr: error.stderr || error.message,
      code: error.code
    };
  }
}

/**
 * ENV-001: Check required environment variables
 */
async function probeEnvironmentVariables(appPath) {
  const probe = {
    id: 'ENV-001',
    name: 'Environment Variables',
    status: PROBE_STATUS.PASS,
    message: '',
    suggestions: []
  };
  
  // Define required variables per application
  const requiredVars = {
    'hunters-run': [
      'SUPABASE_DB_URL',
      'FIREBASE_PROJECT_ID',
      'FIREBASE_CLIENT_EMAIL', 
      'FIREBASE_PRIVATE_KEY'
    ]
  };
  
  const appName = appPath.split('/').pop() || appPath.split('\\\\').pop();
  const required = requiredVars[appName] || ['SUPABASE_DB_URL'];
  
  const missing = required.filter(varName => !process.env[varName]);
  
  if (missing.length > 0) {
    probe.status = PROBE_STATUS.FAIL;
    probe.message = `Missing environment variables: ${missing.join(', ')}`;
    
    // Improved suggestions based on missing variables
    const suggestions = [];
    if (missing.includes('SUPABASE_DB_URL')) {
      suggestions.push(`Missing SUPABASE_DB_URL. Suggestion: copy apps/${appName}/.env.example to apps/${appName}/.env and paste the connection string from your Supabase dashboard. Make sure it ends with ?sslmode=require.`);
    }
    if (missing.some(v => v.startsWith('FIREBASE_'))) {
      suggestions.push('Missing FIREBASE_CLIENT_EMAIL and/or FIREBASE_PRIVATE_KEY. Suggestion: download a service account from Firebase Console > Project Settings > Service Accounts; escape private key newlines as \\n and wrap in quotes.');
    }
    if (!suggestions.length) {
      suggestions.push('Add missing variables to your .env file');
      suggestions.push('Check environment variable names for typos');
    }
    
    probe.suggestions = suggestions;
  } else {
    probe.message = `All required environment variables present (${required.length})`;
  }
  
  return probe;
}

/**
 * DB-002: Test database connectivity
 */
async function probeDatabaseConnectivity() {
  const probe = {
    id: 'DB-002',
    name: 'Database Connectivity',
    status: PROBE_STATUS.PASS,
    message: '',
    suggestions: []
  };
  
  const dbUrl = process.env.SUPABASE_DB_URL || process.env.DATABASE_URL;
  if (!dbUrl) {
    probe.status = PROBE_STATUS.FAIL;
    probe.message = 'Database URL not configured';
    probe.suggestions = [
      'Set SUPABASE_DB_URL environment variable',
      'Get connection string from Supabase Dashboard > Settings > Database'
    ];
    return probe;
  }
  
  try {
    // Use our supa-db-ping script
    const result = await execCommand(`node "${join(__dirname, 'supa-db-ping.mjs')}"`, {
      timeout: 10000
    });
    
    if (result.success) {
      probe.message = 'Database connection successful';
    } else {
      probe.status = PROBE_STATUS.FAIL;
      probe.message = 'Database connection failed';
      probe.suggestions = [
        'Check SUPABASE_DB_URL format and credentials',
        'Verify internet connectivity',
        'Check Supabase project status'
      ];
    }
  } catch (error) {
    probe.status = PROBE_STATUS.FAIL;
    probe.message = `Database check error: ${error.message}`;
    probe.suggestions = ['Run supa-db-ping.mjs directly for detailed diagnostics'];
  }
  
  return probe;
}

/**
 * DB-003: Check for pending migrations
 */
async function probeDatabaseMigrations(appPath) {
  const probe = {
    id: 'DB-003',
    name: 'Database Migrations',
    status: PROBE_STATUS.INFO,
    message: 'Migration check not implemented',
    suggestions: []
  };
  
  // TODO: Implement migration drift detection when migration system is available
  probe.message = 'Migration system not yet implemented';
  probe.suggestions = ['Implement database migration tracking'];
  
  return probe;
}

/**
 * SEC-004: Row Level Security smoke test (WARN-only initially)
 */
async function probeRowLevelSecurity() {
  const probe = {
    id: 'SEC-004',
    name: 'Row Level Security',
    status: PROBE_STATUS.WARN,
    message: 'Row Level Security policies not yet implemented',
    suggestions: [
      'Create non-privileged database role for application',
      'Implement Row Level Security policies for data isolation',
      'Test multi-tenant data access patterns'
    ]
  };
  
  return probe;
}

/**
 * API-005: Application health endpoint check
 */
async function probeApiHealth(appPath) {
  const probe = {
    id: 'API-005', 
    name: 'API Health Endpoint',
    status: PROBE_STATUS.INFO,
    message: '',
    suggestions: []
  };
  
  // Try common health endpoints
  const healthUrls = [
    'http://localhost:3000/health',
    'http://localhost:3000/api/health',
    'http://localhost:3012/api/health'  // Current running port
  ];
  
  let healthy = false;
  for (const url of healthUrls) {
    try {
      const result = await execCommand(`curl -f -m 2 "${url}"`, { timeout: 3000 });
      if (result.success) {
        probe.status = PROBE_STATUS.PASS;
        probe.message = `Health endpoint responding: ${url}`;
        healthy = true;
        break;
      }
    } catch (error) {
      // Continue trying other URLs
    }
  }
  
  if (!healthy) {
    probe.status = PROBE_STATUS.INFO;
    probe.message = 'No health endpoint responding (application may not be running)';
    probe.suggestions = [
      'Start the application to test health endpoints',
      'Implement /health or /api/health endpoint'
    ];
  }
  
  return probe;
}

/**
 * BUILD-006: TypeScript compilation check
 */
async function probeTypeScriptBuild(appPath) {
  const probe = {
    id: 'BUILD-006',
    name: 'TypeScript Compilation',
    status: PROBE_STATUS.PASS,
    message: '',
    suggestions: []
  };
  
  const tsconfigPath = join(appPath, 'tsconfig.json');
  if (!existsSync(tsconfigPath)) {
    probe.status = PROBE_STATUS.INFO;
    probe.message = 'No TypeScript configuration found';
    return probe;
  }
  
  try {
    const result = await execCommand(`npx tsc -p "${tsconfigPath}" --noEmit`, {
      timeout: 30000,
      cwd: appPath
    });
    
    if (result.success) {
      probe.message = 'TypeScript compilation successful';
    } else {
      probe.status = PROBE_STATUS.FAIL;
      probe.message = 'TypeScript compilation failed';
      probe.suggestions = [
        'Fix TypeScript errors shown above',
        'Check import paths and dependencies',
        'Verify tsconfig.json configuration'
      ];
    }
  } catch (error) {
    probe.status = PROBE_STATUS.FAIL;
    probe.message = `TypeScript build error: ${error.message}`;
  }
  
  return probe;
}

/**
 * LINT-007: ESLint check with import boundary validation
 */
async function probeESLint(appPath) {
  const probe = {
    id: 'LINT-007',
    name: 'ESLint & Import Boundaries',
    status: PROBE_STATUS.PASS,
    message: '',
    suggestions: []
  };
  
  try {
    const result = await execCommand(`npx eslint "${appPath}" --format=compact`, {
      timeout: 20000,
      cwd: resolve(__dirname, '../..')
    });
    
    if (result.success && !result.stdout.includes('error')) {
      probe.message = 'ESLint validation passed';
    } else {
      // Check specifically for import boundary violations
      const boundaryViolations = result.stderr.includes('boundaries/') || 
                                 result.stdout.includes('Cross-app imports are forbidden');
      
      if (boundaryViolations) {
        probe.status = PROBE_STATUS.FAIL;
        probe.message = '🚨 Import boundary violations detected';
        probe.suggestions = [
          'Fix cross-application imports using @platform/* packages',
          'Review ESLint output for specific boundary violations',
          'Use centralized packages for shared functionality'
        ];
      } else {
        probe.status = PROBE_STATUS.WARN;
        probe.message = 'ESLint warnings found';
        probe.suggestions = ['Review and fix ESLint warnings'];
      }
    }
  } catch (error) {
    probe.status = PROBE_STATUS.WARN;
    probe.message = `ESLint check skipped: ${error.message}`;
  }
  
  return probe;
}

/**
 * SEC-008: Secret placeholder detection
 */
async function probeSecretPlaceholders(appPath) {
  const probe = {
    id: 'SEC-008',
    name: 'Secret Placeholders',
    status: PROBE_STATUS.PASS,
    message: '',
    suggestions: []
  };
  
  const dangerousPatterns = [
    'changeme',
    'default_password',
    'secret123',
    'password123',
    'YOUR_API_KEY',
    'REPLACE_ME'
  ];
  
  try {
    // Check environment variables
    const envVars = Object.entries(process.env);
    const foundSecrets = [];
    
    for (const [key, value] of envVars) {
      if (value && dangerousPatterns.some(pattern => 
        value.toLowerCase().includes(pattern.toLowerCase())
      )) {
        foundSecrets.push(key);
      }
    }
    
    if (foundSecrets.length > 0) {
      probe.status = PROBE_STATUS.FAIL;
      probe.message = `Placeholder values detected in: ${foundSecrets.join(', ')}`;
      probe.suggestions = [
        'Replace placeholder values with real credentials',
        'Use proper secret management for production',
        'Review environment variable values'
      ];
    } else {
      probe.message = 'No obvious secret placeholders found';
    }
  } catch (error) {
    probe.status = PROBE_STATUS.INFO;
    probe.message = `Secret check incomplete: ${error.message}`;
  }
  
  return probe;
}

/**
 * CFG-009: Feature flags snapshot
 */
async function probeFeatureFlags() {
  const probe = {
    id: 'CFG-009',
    name: 'Feature Flags',
    status: PROBE_STATUS.INFO,
    message: 'Feature flag system not implemented',
    suggestions: []
  };
  
  return probe;
}

/**
 * AUTH-010: Firebase Admin initialization
 */
async function probeFirebaseInit() {
  const probe = {
    id: 'AUTH-010',
    name: 'Firebase Admin Init',
    status: PROBE_STATUS.PASS,
    message: '',
    suggestions: []
  };
  
  const required = ['FIREBASE_PROJECT_ID', 'FIREBASE_CLIENT_EMAIL', 'FIREBASE_PRIVATE_KEY'];
  const missing = required.filter(varName => !process.env[varName]);
  
  if (missing.length > 0) {
    probe.status = PROBE_STATUS.FAIL;
    probe.message = `Missing Firebase variables: ${missing.join(', ')}`;
    probe.suggestions = [
      'Add Firebase service account credentials to environment',
      'Download service account key from Firebase Console',
      'Ensure FIREBASE_PRIVATE_KEY has proper \\n escaping'
    ];
    return probe;
  }
  
  // Basic validation
  const privateKey = process.env.FIREBASE_PRIVATE_KEY;
  if (!privateKey.includes('BEGIN PRIVATE KEY')) {
    probe.status = PROBE_STATUS.WARN;
    probe.message = 'FIREBASE_PRIVATE_KEY format may be invalid';
    probe.suggestions = [
      'Ensure private key includes -----BEGIN PRIVATE KEY----- header',
      'Check that \\n newlines are properly escaped in the environment variable'
    ];
  } else {
    probe.message = 'Firebase configuration appears valid';
  }
  
  return probe;
}

/**
 * AUTH-011: Private key newline formatting check
 */
async function probePrivateKeyFormatting() {
  const probe = {
    id: 'AUTH-011',
    name: 'Private Key Formatting',
    status: PROBE_STATUS.PASS,
    message: '',
    suggestions: []
  };
  
  const privateKey = process.env.FIREBASE_PRIVATE_KEY;
  if (!privateKey) {
    probe.status = PROBE_STATUS.INFO;
    probe.message = 'No private key to validate';
    return probe;
  }
  
  if (!privateKey.includes('\\n')) {
    probe.status = PROBE_STATUS.WARN;
    probe.message = 'Private key may be missing \\n newline escaping';
    probe.suggestions = [
      'Firebase private keys should contain \\n (not actual newlines)',
      'Quote the entire private key in your .env file',
      'Example: FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\\nMII...\\n-----END PRIVATE KEY-----"'
    ];
  } else {
    probe.message = 'Private key formatting looks correct';
  }
  
  return probe;
}

/**
 * AUTH-012: Synthetic Firebase Admin call
 */
async function probeFirebaseAdminCall() {
  const probe = {
    id: 'AUTH-012',
    name: 'Firebase Admin Call',
    status: PROBE_STATUS.WARN,
    message: 'Firebase Admin test not implemented',
    suggestions: [
      'Implement Firebase Admin SDK test call',
      'Test token verification functionality',
      'Verify service account permissions'
    ]
  };
  
  return probe;
}

/**
 * Execute all probes for an application
 */
async function runAllProbes(appPath) {
  console.log(`=== SELFCHECK: ${appPath} ===\\n`);
  
  const probes = [
    await probeEnvironmentVariables(appPath),
    await probeDatabaseConnectivity(),
    await probeDatabaseMigrations(appPath),
    await probeRowLevelSecurity(),
    await probeApiHealth(appPath),
    await probeTypeScriptBuild(appPath),
    await probeESLint(appPath),
    await probeSecretPlaceholders(appPath),
    await probeFeatureFlags(),
    await probeFirebaseInit(),
    await probePrivateKeyFormatting(),
    await probeFirebaseAdminCall()
  ];
  
  // Print results
  for (const probe of probes) {
    const icon = {
      [PROBE_STATUS.PASS]: '✅',
      [PROBE_STATUS.WARN]: '⚠️',
      [PROBE_STATUS.FAIL]: '❌',
      [PROBE_STATUS.INFO]: 'ℹ️'
    }[probe.status];
    
    console.log(`${icon} ${probe.status} - ${probe.id}: ${probe.message}`);
    
    if (probe.suggestions.length > 0) {
      for (const suggestion of probe.suggestions) {
        console.log(`   💡 ${suggestion}`);
      }
    }
    console.log('');
  }
  
  // Summary
  const counts = probes.reduce((acc, probe) => {
    acc[probe.status] = (acc[probe.status] || 0) + 1;
    return acc;
  }, {});
  
  console.log('=== SUMMARY ===');
  console.log(`✅ PASS: ${counts.PASS || 0}`);
  console.log(`⚠️  WARN: ${counts.WARN || 0}`);
  console.log(`❌ FAIL: ${counts.FAIL || 0}`);
  console.log(`ℹ️  INFO: ${counts.INFO || 0}`);
  console.log('');
  
  return { probes, counts };
}

/**
 * Generate JSON and Markdown reports
 */
function generateReports(appPath, results, timestamp) {
  const appName = appPath.split('/').pop() || appPath.split('\\\\').pop();
  const handoverDir = resolve(__dirname, '../../docs/handover');
  
  if (!existsSync(handoverDir)) {
    mkdirSync(handoverDir, { recursive: true });
  }
  
  // JSON report
  const jsonReport = {
    application: appName,
    timestamp,
    summary: results.counts,
    probes: results.probes
  };
  
  writeFileSync(
    join(handoverDir, `${appName}.status.json`),
    JSON.stringify(jsonReport, null, 2)
  );
  
  // Markdown report
  const status = results.counts.FAIL > 0 ? '⛔ Blocked' : 
                 results.counts.WARN > 0 ? '⚠️ Flaky' : '✅ Working';
  
  const mdContent = `# ${appName} - System Status
  
## Overall Status: ${status}

Generated: ${new Date(timestamp).toISOString()}

## Summary
- ✅ PASS: ${results.counts.PASS || 0}
- ⚠️ WARN: ${results.counts.WARN || 0} 
- ❌ FAIL: ${results.counts.FAIL || 0}
- ℹ️ INFO: ${results.counts.INFO || 0}

## Probe Results

${results.probes.map(probe => {
  const icon = {
    PASS: '✅',
    WARN: '⚠️',
    FAIL: '❌',
    INFO: 'ℹ️'
  }[probe.status];
  
  return `### ${icon} ${probe.id}: ${probe.name}
  
**Status:** ${probe.status}  
**Message:** ${probe.message}

${probe.suggestions.length > 0 ? `**Suggestions:**
${probe.suggestions.map(s => `- ${s}`).join('\\n')}` : ''}
`;
}).join('\\n')}

## Next Three One-Day Actions

${results.counts.FAIL > 0 ? `
1. **Priority:** Fix failing probes (${results.probes.filter(p => p.status === 'FAIL').map(p => p.id).join(', ')})
2. **Security:** Address Row Level Security implementation (SEC-004)
3. **Testing:** Implement comprehensive integration tests
` : results.counts.WARN > 0 ? `
1. **Quality:** Address warning conditions (${results.probes.filter(p => p.status === 'WARN').map(p => p.id).join(', ')})
2. **Features:** Complete missing functionality implementations
3. **Documentation:** Update deployment and operational guides
` : `
1. **Enhancement:** Implement missing features (AUTH-012, CFG-009)
2. **Monitoring:** Add application metrics and alerting
3. **Optimization:** Performance testing and optimization
`}`;

  writeFileSync(
    join(handoverDir, `${appName}.status.md`),
    mdContent
  );
  
  console.log(`Reports generated:`);
  console.log(`  📋 ${join(handoverDir, `${appName}.status.json`)}`);
  console.log(`  📄 ${join(handoverDir, `${appName}.status.md`)}`);
}

/**
 * Determine exit code based on probe results
 */
function getExitCode(counts) {
  if (counts.FAIL > 0) return 20;
  if (counts.WARN > 0) return 10;
  return 0;
}

// Main execution
async function main() {
  const args = process.argv.slice(2);
  const appPath = args[0] || 'apps/hunters-run';
  
  if (!appPath) {
    console.error('Usage: node selfcheck.mjs <app-path>');
    process.exit(1);
  }
  
  // Load .env file if it exists
  const envFile = join(appPath, '.env');
  const dotenvLoaded = await loadEnvWithDotenv(envFile);
  if (!dotenvLoaded) {
    loadEnvFile(envFile);
  }
  
  const timestamp = Date.now();
  const results = await runAllProbes(appPath);
  
  generateReports(appPath, results, timestamp);
  
  const exitCode = getExitCode(results.counts);
  process.exit(exitCode);
}

main().catch(error => {
  console.error('Selfcheck failed:', error.message);
  process.exit(1);
});
#!/usr/bin/env node
// G5-1: Snapshot script for consolidating system status
// Collects git state, test results, and selfcheck data

import { exec } from 'child_process';
import { promisify } from 'util';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, dirname, resolve } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const execAsync = promisify(exec);

/**
 * Execute command safely
 */
async function execCommand(command, options = {}) {
  try {
    const { stdout, stderr } = await execAsync(command, {
      timeout: options.timeout || 30000,
      ...options
    });
    return { success: true, stdout: stdout.trim(), stderr };
  } catch (error) {
    return { 
      success: false, 
      stdout: (error.stdout || '').trim(), 
      stderr: error.stderr || error.message
    };
  }
}

/**
 * Get git information
 */
async function getGitInfo() {
  const info = {
    branch: 'unknown',
    commit: 'unknown',
    commitMessage: 'unknown',
    isDirty: false,
    remoteUrl: 'unknown'
  };
  
  try {
    const branch = await execCommand('git rev-parse --abbrev-ref HEAD');
    if (branch.success) info.branch = branch.stdout;
    
    const commit = await execCommand('git rev-parse --short HEAD');
    if (commit.success) info.commit = commit.stdout;
    
    const message = await execCommand('git log -1 --pretty=format:"%s"');
    if (message.success) info.commitMessage = message.stdout.replace(/"/g, '');
    
    const status = await execCommand('git status --porcelain');
    if (status.success) info.isDirty = status.stdout.length > 0;
    
    const remote = await execCommand('git remote get-url origin');
    if (remote.success) info.remoteUrl = remote.stdout;
  } catch (error) {
    // Git info is best-effort
  }
  
  return info;
}

/**
 * Run tests if available
 */
async function runTests(appPath) {
  const testInfo = {
    hasTests: false,
    ran: false,
    passed: false,
    summary: 'No tests found'
  };
  
  // Check for package.json test script
  const packageJsonPath = join(appPath, 'package.json');
  if (!existsSync(packageJsonPath)) {
    return testInfo;
  }
  
  try {
    const packageJson = JSON.parse(readFileSync(packageJsonPath, 'utf8'));
    const hasTestScript = packageJson.scripts && packageJson.scripts.test;
    
    if (!hasTestScript) {
      return testInfo;
    }
    
    testInfo.hasTests = true;
    
    // Run tests with timeout
    const result = await execCommand('npm test', {
      timeout: 60000,
      cwd: appPath
    });
    
    testInfo.ran = true;
    testInfo.passed = result.success;
    testInfo.summary = result.success ? 
      'Tests passed' : 
      `Tests failed: ${result.stderr.split('\\n')[0]}`;
      
  } catch (error) {
    testInfo.summary = `Test execution error: ${error.message}`;
  }
  
  return testInfo;
}

/**
 * Read last selfcheck results
 */
function getLastSelfcheckResults(appName) {
  const handoverDir = resolve(__dirname, '../../docs/handover');
  const statusFile = join(handoverDir, `${appName}.status.json`);
  
  if (!existsSync(statusFile)) {
    return null;
  }
  
  try {
    return JSON.parse(readFileSync(statusFile, 'utf8'));
  } catch (error) {
    return null;
  }
}

/**
 * Generate comprehensive snapshot
 */
async function generateSnapshot(appPath) {
  const appName = appPath.split('/').pop() || appPath.split('\\\\').pop();
  const timestamp = Date.now();
  
  console.log(`=== SNAPSHOT: ${appName} ===\\n`);
  
  console.log('📋 Collecting git information...');
  const gitInfo = await getGitInfo();
  
  console.log('🧪 Checking for tests...');
  const testInfo = await runTests(appPath);
  
  console.log('📊 Reading last selfcheck results...');
  const lastSelfcheck = getLastSelfcheckResults(appName);
  
  // Create consolidated snapshot
  const snapshot = {
    application: appName,
    timestamp,
    generatedAt: new Date(timestamp).toISOString(),
    git: gitInfo,
    tests: testInfo,
    lastSelfcheck: lastSelfcheck ? {
      timestamp: lastSelfcheck.timestamp,
      summary: lastSelfcheck.summary,
      criticalIssues: lastSelfcheck.probes ? 
        lastSelfcheck.probes.filter(p => p.status === 'FAIL').length : 0
    } : null
  };
  
  // Update status files
  const handoverDir = resolve(__dirname, '../../docs/handover');
  if (!existsSync(handoverDir)) {
    mkdirSync(handoverDir, { recursive: true });
  }
  
  // Update JSON with snapshot data
  const statusFile = join(handoverDir, `${appName}.status.json`);
  let statusData = lastSelfcheck || { application: appName, probes: [] };
  statusData.lastSnapshot = snapshot;
  statusData.timestamp = timestamp;
  
  writeFileSync(statusFile, JSON.stringify(statusData, null, 2));
  
  // Update Markdown with snapshot
  const overall = snapshot.lastSelfcheck?.criticalIssues > 0 ? '⛔ Blocked' :
                 !snapshot.lastSelfcheck ? '⚠️ Unknown' : '✅ Working';
  
  // Build selfcheck section
  const selfcheckSection = snapshot.lastSelfcheck ? 
    `## Last Selfcheck
- **When:** ${new Date(snapshot.lastSelfcheck.timestamp).toISOString()}
- **Critical Issues:** ${snapshot.lastSelfcheck.criticalIssues}
- **Status:** ${JSON.stringify(snapshot.lastSelfcheck.summary)}

For detailed probe results, see the full selfcheck report.` :
    `## Selfcheck
No selfcheck data available. Run \`npm run selfcheck:${appName}\` first.`;

  // Build tests section
  const testsSection = testInfo.hasTests ? `# Run tests
npm test

` : '';
  
  const mdContent = `# ${appName} - System Snapshot

## Overall Status: ${overall}

Generated: ${snapshot.generatedAt}

## Git Status
- **Branch:** ${gitInfo.branch}
- **Commit:** ${gitInfo.commit}
- **Message:** ${gitInfo.commitMessage}
- **Clean:** ${gitInfo.isDirty ? '❌ Uncommitted changes' : '✅ Clean working tree'}
- **Remote:** ${gitInfo.remoteUrl}

## Tests
- **Available:** ${testInfo.hasTests ? '✅ Yes' : '❌ No'}
- **Last Run:** ${testInfo.ran ? (testInfo.passed ? '✅ Passed' : '❌ Failed') : 'Not run'}
- **Summary:** ${testInfo.summary}

${selfcheckSection}

## Quick Actions
\`\`\`bash
# Run full selfcheck
npm run selfcheck:${appName}

# Update snapshot  
npm run snapshot:${appName}

${testsSection}# Check git status
git status
\`\`\`
`;

  const mdFile = join(handoverDir, `${appName}.status.md`);
  writeFileSync(mdFile, mdContent);
  
  console.log('\\n📋 Snapshot complete:');
  console.log(`   JSON: ${statusFile}`);
  console.log(`   MD: ${mdFile}`);
  console.log('\\n📊 Summary:');
  console.log(`   Git: ${gitInfo.branch}@${gitInfo.commit} ${gitInfo.isDirty ? '(dirty)' : '(clean)'}`);
  console.log(`   Tests: ${testInfo.hasTests ? (testInfo.passed ? 'PASS' : 'FAIL') : 'N/A'}`);
  console.log(`   Selfcheck: ${snapshot.lastSelfcheck ? `${snapshot.lastSelfcheck.criticalIssues} critical issues` : 'Not run'}`);
  
  return snapshot;
}

// Main execution
async function main() {
  const args = process.argv.slice(2);
  const appPath = args[0] || 'apps/hunters-run';
  
  if (!appPath) {
    console.error('Usage: node snapshot.mjs <app-path>');
    process.exit(1);
  }
  
  try {
    await generateSnapshot(appPath);
    process.exit(0);
  } catch (error) {
    console.error('Snapshot failed:', error.message);
    process.exit(1);
  }
}

main();
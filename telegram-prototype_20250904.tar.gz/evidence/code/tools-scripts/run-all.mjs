#!/usr/bin/env node
// G1-3: Run-all helper for executing scripts across all applications
// Provides summary table with PASS/WARN/FAIL counts

import { spawn } from 'child_process';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Applications to check (A1 scope)
const APPS = [
  'hunters-run',
  'adhd', 
  'marco-rides',
  'mass-quest',
  'warehouse-ai',
  'parent-child-app',
  'catholic-mass-edu'
];

/**
 * Execute script for a single application
 */
async function runForApp(scriptName, appName) {
  return new Promise((resolve) => {
    const appPath = `apps/${appName}`;
    const scriptPath = join(__dirname, `${scriptName}.mjs`);
    
    console.log(`\\n=== ${appName.toUpperCase()} ===`);
    
    const child = spawn('node', [scriptPath, appPath], {
      stdio: ['inherit', 'inherit', 'inherit']
    });
    
    const startTime = Date.now();
    
    child.on('close', (code) => {
      const duration = Date.now() - startTime;
      let status;
      
      if (code === 0) status = 'PASS';
      else if (code === 10) status = 'WARN';
      else status = 'FAIL';
      
      resolve({
        app: appName,
        status,
        exitCode: code,
        duration: Math.round(duration / 1000)
      });
    });
    
    child.on('error', (error) => {
      resolve({
        app: appName,
        status: 'ERROR',
        exitCode: -1,
        duration: 0,
        error: error.message
      });
    });
  });
}

/**
 * Print summary table
 */
function printSummary(results, scriptName) {
  console.log('\\n'.repeat(2));
  console.log('='.repeat(60));
  console.log(`${scriptName.toUpperCase()} SUMMARY`);
  console.log('='.repeat(60));
  
  // Table header
  console.log('');
  console.log('Application          Status    Exit Code    Duration');
  console.log('-'.repeat(55));
  
  // Table rows
  for (const result of results) {
    const app = result.app.padEnd(18);
    const status = result.status.padEnd(8);
    const exitCode = result.exitCode.toString().padEnd(11);
    const duration = `${result.duration}s`.padEnd(8);
    
    const icon = {
      'PASS': '✅',
      'WARN': '⚠️',
      'FAIL': '❌',
      'ERROR': '🔥'
    }[result.status] || '❓';
    
    console.log(`${app}  ${icon} ${status}  ${exitCode}  ${duration}`);
    
    if (result.error) {
      console.log(`                     Error: ${result.error}`);
    }
  }
  
  // Summary stats
  console.log('');
  console.log('-'.repeat(55));
  
  const counts = results.reduce((acc, r) => {
    acc[r.status] = (acc[r.status] || 0) + 1;
    return acc;
  }, {});
  
  console.log(`Total: ${results.length} applications`);
  if (counts.PASS) console.log(`✅ PASS: ${counts.PASS}`);
  if (counts.WARN) console.log(`⚠️  WARN: ${counts.WARN}`);
  if (counts.FAIL) console.log(`❌ FAIL: ${counts.FAIL}`);
  if (counts.ERROR) console.log(`🔥 ERROR: ${counts.ERROR}`);
  
  console.log('');
  
  // Overall assessment
  if (counts.ERROR > 0 || counts.FAIL > 0) {
    console.log('🚨 OVERALL: Issues need attention');
    return false;
  } else if (counts.WARN > 0) {
    console.log('⚠️  OVERALL: Some warnings, mostly functional');
    return true;
  } else {
    console.log('🎉 OVERALL: All applications healthy');
    return true;
  }
}

// Main execution
async function main() {
  const args = process.argv.slice(2);
  const scriptName = args[0];
  
  if (!scriptName || !['selfcheck', 'snapshot'].includes(scriptName)) {
    console.error('Usage: node run-all.mjs <selfcheck|snapshot>');
    console.error('');
    console.error('Examples:');
    console.error('  node run-all.mjs selfcheck  # Run selfcheck for all apps');
    console.error('  node run-all.mjs snapshot   # Generate snapshots for all apps');
    process.exit(1);
  }
  
  console.log(`Running ${scriptName} for all applications...`);
  console.log(`Applications: ${APPS.join(', ')}`);
  
  const results = [];
  
  // Run for each application
  for (const app of APPS) {
    try {
      const result = await runForApp(scriptName, app);
      results.push(result);
    } catch (error) {
      results.push({
        app,
        status: 'ERROR',
        exitCode: -1,
        duration: 0,
        error: error.message
      });
    }
  }
  
  // Print summary
  const overall = printSummary(results, scriptName);
  
  // Exit with appropriate code
  const hasFailures = results.some(r => r.status === 'FAIL' || r.status === 'ERROR');
  const hasWarnings = results.some(r => r.status === 'WARN');
  
  if (hasFailures) {
    process.exit(20); // FAIL exit code
  } else if (hasWarnings) {
    process.exit(10); // WARN exit code
  } else {
    process.exit(0);  // PASS exit code
  }
}

main().catch(error => {
  console.error('Run-all script failed:', error.message);
  process.exit(1);
});
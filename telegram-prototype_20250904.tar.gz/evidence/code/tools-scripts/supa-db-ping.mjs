#!/usr/bin/env node
// DB: Supabase database connectivity checker
// Connects to SUPABASE_DB_URL with timeout and provides actionable diagnostics

import pkg from 'pg';
const { Client } = pkg;
import { readFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

/**
 * Load environment using dotenv if available
 */
async function loadEnvWithDotenv(envPath) {
  try {
    const dotenv = await import('dotenv');
    dotenv.config({ path: envPath });
    return true;
  } catch (error) {
    console.log('⚠️  dotenv not available, using manual parsing');
    return false;
  }
}

/**
 * Load environment variables from .env file if provided
 */
function loadEnvFile(envPath) {
  try {
    if (!existsSync(envPath)) {
      return false;
    }
    
    const envContent = readFileSync(envPath, 'utf8');
    const lines = envContent.split('\n');
    
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed && !trimmed.startsWith('#')) {
        const [key, ...valueParts] = trimmed.split('=');
        if (key && valueParts.length > 0) {
          const value = valueParts.join('=').replace(/^["']|["']$/g, '');
          process.env[key.trim()] = value;
        }
      }
    }
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Test database connectivity with comprehensive diagnostics
 */
async function pingDatabase() {
  console.log('=== SUPABASE DATABASE CONNECTIVITY CHECK ===\n');
  
  // ENV-001: Check required environment variables
  const dbUrl = process.env.SUPABASE_DB_URL || process.env.DATABASE_URL;
  if (!dbUrl) {
    console.log('❌ FAIL - ENV-001: SUPABASE_DB_URL missing');
    console.log('   Add SUPABASE_DB_URL to your environment variables.');
    console.log('   Get this from Supabase Dashboard > Settings > Database > Connection string');
    console.log('   Format: postgresql://postgres:[PASSWORD]@[HOST]:[PORT]/postgres?sslmode=require');
    console.log('');
    return false;
  }
  
  console.log('✅ PASS - ENV-001: SUPABASE_DB_URL present');
  
  // Validate SSL mode requirement
  if (!dbUrl.includes('sslmode=require')) {
    console.log('⚠️  WARN - DB-002: Connection string missing sslmode=require');
    console.log('   Supabase requires SSL. Add ?sslmode=require to your connection string.');
    console.log('');
  }
  
  // Parse connection details for diagnostics
  let host, port;
  try {
    const url = new URL(dbUrl);
    host = url.hostname;
    port = url.port || '5432';
  } catch (error) {
    console.log('❌ FAIL - DB-002: Invalid connection string format');
    console.log('   Connection string must be a valid PostgreSQL URL.');
    console.log('');
    return false;
  }
  
  console.log(`🔗 Connecting to: ${host}:${port}`);
  console.log('');
  
  // DB-002: Test database connectivity
  const client = new Client({
    connectionString: dbUrl,
    connectionTimeoutMillis: 5000,
  });
  
  try {
    console.log('⏳ Testing connection...');
    await client.connect();
    
    // Test basic query
    const result = await client.query('SELECT NOW() as server_time, current_user as db_user');
    const serverTime = result.rows[0].server_time;
    const dbUser = result.rows[0].db_user;
    
    console.log('✅ PASS - DB-002: Database connection successful');
    console.log(`   Server time: ${serverTime}`);
    console.log(`   Database user: ${dbUser}`);
    console.log('');
    
    await client.end();
    return true;
    
  } catch (error) {
    console.log('❌ FAIL - DB-002: Database connection failed');
    
    if (error.code === 'ENOTFOUND') {
      console.log('   DNS resolution failed. Check your internet connection and hostname.');
    } else if (error.code === 'ECONNREFUSED') {
      console.log('   Connection refused. Check if the database server is running.');
    } else if (error.code === '28P01') {
      console.log('   Authentication failed. Verify your username and password.');
    } else if (error.code === 'ETIMEDOUT') {
      console.log('   Connection timed out. Check firewall settings and network connectivity.');
    } else {
      console.log(`   Error: ${error.message}`);
    }
    
    console.log('   Troubleshooting:');
    console.log('   1. Verify SUPABASE_DB_URL is correct from Supabase Dashboard');
    console.log('   2. Check your internet connection');
    console.log('   3. Ensure your IP is allowed in Supabase Network Restrictions');
    console.log('');
    
    try {
      await client.end();
    } catch (cleanupError) {
      // Ignore cleanup errors
    }
    
    return false;
  }
}

// Main execution
async function main() {
  const args = process.argv.slice(2);
  const envFile = args[0];
  
  if (envFile) {
    console.log(`Loading environment from: ${envFile}`);
    const dotenvLoaded = await loadEnvWithDotenv(envFile);
    if (!dotenvLoaded) {
      const manualLoaded = loadEnvFile(envFile);
      if (!manualLoaded) {
        console.log(`⚠️  Could not load ${envFile}`);
      }
    }
    console.log('');
  }
  
  const success = await pingDatabase();
  process.exit(success ? 0 : 1);
}

main().catch(error => {
  console.error('Unexpected error:', error.message);
  process.exit(1);
});
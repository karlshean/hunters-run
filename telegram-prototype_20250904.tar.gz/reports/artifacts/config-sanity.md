# Configuration Sanity Report
Generated: 2025-08-28T13:33:42.794Z

## Overall Status: OK

- **Total Variables Checked**: 15
- **Required Variables**: 2
- **Missing Required**: 0
- **Environment Variables Set**: 3

## Service: hr-api

**Status**: ✅ OK

### Required Configuration
- **DATABASE_URL**: ✅ PostgreSQL connection string
- **FIREBASE_PROJECT_ID**: ✅ Firebase project identifier

### Optional Configuration
- **DB_SSL_MODE**: ✅ Database SSL mode (strict/relaxed)
- **FIREBASE_SERVICE_ACCOUNT_JSON**: ⚪ Firebase service account JSON
- **FIREBASE_SERVICE_ACCOUNT_PATH**: ⚪ Path to Firebase service account file



## Service: hr-web

**Status**: ✅ OK

### Required Configuration
- **FIREBASE_PROJECT_ID**: ✅ Firebase project identifier

### Optional Configuration
- **NODE_ENV**: ⚪ Node environment (development/production)



## Environment Variables Overview

- **DATABASE_URL**: ✅ Set - PostgreSQL connection string
- **DB_SSL_MODE**: ✅ Set - Database SSL mode (strict/relaxed)
- **FIREBASE_PROJECT_ID**: ✅ Set - Firebase project identifier
- **FIREBASE_CLIENT_EMAIL**: ❌ Not Set - Firebase service account email
- **FIREBASE_PRIVATE_KEY**: ❌ Not Set - Firebase service account private key
- **FIREBASE_SERVICE_ACCOUNT_JSON**: ❌ Not Set - Firebase service account JSON
- **FIREBASE_SERVICE_ACCOUNT_PATH**: ❌ Not Set - Path to Firebase service account file
- **AWS_REGION**: ❌ Not Set - AWS region for S3
- **AWS_S3_BUCKET**: ❌ Not Set - S3 bucket name for file storage
- **AWS_ACCESS_KEY_ID**: ❌ Not Set - AWS access key
- **AWS_SECRET_ACCESS_KEY**: ❌ Not Set - AWS secret key
- **NODE_ENV**: ❌ Not Set - Node environment (development/production)
- **PORT**: ❌ Not Set - Server port number
- **DEV_AUTH_BYPASS**: ❌ Not Set - Development authentication bypass
- **TENANT_PHOTO_FLOW_ENABLED**: ❌ Not Set - Enable tenant photo upload flow

---
*Note: This report shows only the presence of configuration variables, not their actual values.*

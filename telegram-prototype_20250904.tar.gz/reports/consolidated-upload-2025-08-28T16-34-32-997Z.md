# Complete System State for Claude Analysis
Generated: 2025-08-28T16:34:32.997Z
Platform: win32 x64
Node: v22.18.0
PWD: C:\Users\KA\myprojects3\hunters-run

## Latest Status Report (JSON)
```json
{
  "status": {
    "generatedAt": "2025-08-28T13:33:37.304Z",
    "api": {
      "running": true,
      "health": "{\"ok\":true}",
      "endpoints": {
        "/api/health": {
          "status": 200,
          "exists": true,
          "response": "{\"ok\":true}"
        },
        "/api/work-orders": {
          "status": 404,
          "exists": true,
          "response": "{\"message\":\"Cannot GET /api/work-orders\",\"error\":\"Not Found\",\"statusCode\":404}"
        },
        "/api/properties": {
          "status": 400,
          "exists": true,
          "response": "{\"message\":\"Valid x-org-id (UUID) header required\",\"error\":\"Bad Request\",\"statusCode\":400}"
        },
        "/api/test": {
          "status": 200,
          "exists": true,
          "response": "{\"ok\":true,\"service\":\"hr-api\",\"database\":{\"connected\":true,\"data\":{\"test\":1,\"timestamp\":\"2025-08-28T"
        },
        "/api/test-protected": {
          "status": 404,
          "exists": true,
          "response": "{\"message\":\"Cannot GET /api/test-protected\",\"error\":\"Not Found\",\"statusCode\":404}"
        }
      }
    },
    "build": {
      "ok": true,
      "error": null
    },
    "db": {
      "ok": true,
      "tables": [
        {
          "schemaname": "audit",
          "tablename": "events"
        },
        {
          "schemaname": "hr",
          "tablename": "events"
        },
        {
          "schemaname": "hr",
          "tablename": "legal_notices"
        },
        {
          "schemaname": "hr",
          "tablename": "notice_templates"
        },
        {
          "schemaname": "hr",
          "tablename": "payment_disputes"
        },
        {
          "schemaname": "hr",
          "tablename": "properties"
        },
        {
          "schemaname": "hr",
          "tablename": "service_attempts"
        },
        {
          "schemaname": "hr",
          "tablename": "sms_messages"
        },
        {
          "schemaname": "hr",
          "tablename": "test_rls"
        },
        {
          "schemaname": "hr",
          "tablename": "webhook_events"
        },
        {
          "schemaname": "hr",
          "tablename": "work_order_transitions"
        },
        {
          "schemaname": "hr",
          "tablename": "work_orders"
        },
        {
          "schemaname": "platform",
          "tablename": "audit_events"
        },
        {
          "schemaname": "platform",
          "tablename": "memberships"
        },
        {
          "schemaname": "platform",
          "tablename": "organizations"
        },
        {
          "schemaname": "platform",
          "tablename": "role_permissions"
        },
        {
          "schemaname": "platform",
          "tablename": "roles"
        },
        {
          "schemaname": "platform",
          "tablename": "user_permissions"
        },
        {
          "schemaname": "platform",
          "tablename": "users"
        }
      ],
      "content": {
        "hr.properties": {
          "count": 4,
          "accessible": true
        },
        "hr.events": {
          "count": 0,
          "accessible": true
        },
        "audit.events": {
          "count": 2,
          "accessible": true
        }
      },
      "rls": {
        "working": false,
        "note": "User 'postgres' has BYPASSRLS privilege - RLS policies ignored (admin user)"
      }
    },
    "env": {
      "DATABASE_URL": true,
      "DB_SSL_MODE": "relaxed",
      "FIREBASE_PROJECT_ID": true,
      "DEV_AUTH_BYPASS": null
    },
    "code": {
      "hasAuthFolder": true,
      "hasWorkorders": true,
      "structure": {
        "hasControllersFolder": false,
        "hasEntitiesFolder": false,
        "hasGuardsFolder": false,
        "hasModulesFolder": true,
        "scriptsAuthExists": true,
        "totalSrcFiles": 36,
        "packageJsonScripts": [
          "build",
          "build:api",
          "test",
          "migrate",
          "dev:all",
          "dev:api",
          "dev:web",
          "selfcheck:workorders",
          "selfcheck:workorders:list",
          "selfcheck:rls",
          "selfcheck:staging",
          "selfcheck:local",
          "selfcheck:testplan",
          "status",
          "verify",
          "report",
          "report:quick",
          "launch",
          "launch:api",
          "launch:quick",
          "health",
          "seed:demo-units",
          "probe:db",
          "auth:inspect",
          "auth:inspect:verify",
          "diagnostic:env",
          "diagnostic:net",
          "diagnostic:drift",
          "diagnostic:config",
          "diagnostic:smoke",
          "report:diagnostics:v2",
          "generate-upload",
          "seed:dev",
          "test:identity",
          "test:rls",
          "test:identity:full",
          "test:identity:windows",
          "verify:identity",
          "verify:identity:manual",
          "verify:manual",
          "verify:complete",
          "debug:auth",
          "debug:identity",
          "debug:guards",
          "debug:migration",
          "test:db",
          "test:env",
          "setup:test:env",
          "lint",
          "selfcheck:all",
          "snapshot:all",
          "db:ping:hunters-run",
          "db:wait:hunters-run",
          "build:hunters-run",
          "selfcheck:hunters-run:step1",
          "prove"
        ],
        "hasDockerfile": true,
        "hasEnvFile": true
      }
    },
    "metrics": {
      "elapsedMs": 7272
    }
  },
  "verify": {
    "parseError": ""
  },
  "diagnostics": {
    "environment": {
      "timestamp": "2025-08-28T13:33:40.690Z",
      "environment": {
        "type": "win32",
        "container": false,
        "virtualized": false,
        "details": {
          "osType": "Windows_NT",
          "osRelease": "10.0.26100"
        }
      },
      "resources": {
        "cpu": {
          "cores": 4,
          "architecture": "x64"
        },
        "memory": {
          "total": 16912171008,
          "free": 7572488192,
          "totalGB": 15.75
        }
      },
      "node": {
        "version": "v22.18.0",
        "platform": "win32",
        "arch": "x64",
        "execPath": "C:\\Program Files\\nodejs\\node.exe",
        "cwd": "C:\\Users\\KA\\myprojects3\\hunters-run",
        "env": {
          "NODE_ENV": "undefined",
          "npm_config_user_config": "undefined",
          "npm_node_execpath": "C:\\Program Files\\nodejs\\node.exe"
        }
      },
      "hostname": "DESKTOP-BAMDQDC",
      "uptime": 401446.921
    },
    "network": {
      "timestamp": "2025-08-28T13:33:41.120Z",
      "totalTargets": 5,
      "successful": 5,
      "failed": 0,
      "averageLatency": 193.8,
      "results": [
        {
          "name": "database",
          "type": "tcp",
          "description": "PostgreSQL database connection",
          "target": "aws-1-us-east-2.pooler.supabase.com",
          "port": 6543,
          "success": true,
          "latency": 80,
          "error": null,
          "timestamp": "2025-08-28T13:33:41.204Z"
        },
        {
          "name": "firebase-auth",
          "type": "http",
          "description": "Firebase Authentication API",
          "target": "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=test",
          "port": null,
          "success": true,
          "latency": 550,
          "error": null,
          "statusCode": 404,
          "timestamp": "2025-08-28T13:33:41.756Z"
        },
        {
          "name": "firebase-jwks",
          "type": "http",
          "description": "Firebase JWKS endpoint",
          "target": "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com",
          "port": null,
          "success": true,
          "latency": 126,
          "error": null,
          "statusCode": 200,
          "timestamp": "2025-08-28T13:33:41.882Z"
        },
        {
          "name": "google-dns",
          "type": "tcp",
          "description": "Google DNS (connectivity test)",
          "target": "8.8.8.8",
          "port": 53,
          "success": true,
          "latency": 42,
          "error": null,
          "timestamp": "2025-08-28T13:33:41.925Z"
        },
        {
          "name": "github-api",
          "type": "http",
          "description": "GitHub API (external connectivity)",
          "target": "https://api.github.com",
          "port": null,
          "success": true,
          "latency": 171,
          "error": null,
          "statusCode": 200,
          "timestamp": "2025-08-28T13:33:42.096Z"
        }
      ]
    },
    "dependencies": {
      "timestamp": "2025-08-28T13:33:42.440Z",
      "rootPackage": {
        "missing": [],
        "extra": [
          {
            "name": "@ampproject/remapping",
            "version": "2.3.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/crc32",
            "version": "5.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/crc32c",
            "version": "5.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/sha1-browser",
            "version": "5.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/sha1-browser/node_modules/@smithy/is-array-buffer",
            "version": "2.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/sha1-browser/node_modules/@smithy/util-buffer-from",
            "version": "2.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/sha1-browser/node_modules/@smithy/util-utf8",
            "version": "2.3.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/sha256-browser",
            "version": "5.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/sha256-browser/node_modules/@smithy/is-array-buffer",
            "version": "2.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/sha256-browser/node_modules/@smithy/util-buffer-from",
            "version": "2.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/sha256-browser/node_modules/@smithy/util-utf8",
            "version": "2.3.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/sha256-js",
            "version": "5.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/supports-web-crypto",
            "version": "5.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/util",
            "version": "5.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/util/node_modules/@smithy/is-array-buffer",
            "version": "2.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/util/node_modules/@smithy/util-buffer-from",
            "version": "2.2.0",
            "type": "extra"
          },
          {
            "name": "@aws-crypto/util/node_modules/@smithy/util-utf8",
            "version": "2.3.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/client-s3",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/client-sso",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/client-sso-oidc",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/client-sts",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/core",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/credential-provider-env",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/credential-provider-http",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/credential-provider-ini",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/credential-provider-node",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/credential-provider-process",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/credential-provider-sso",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/credential-provider-web-identity",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/middleware-bucket-endpoint",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/middleware-expect-continue",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/middleware-flexible-checksums",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/middleware-host-header",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/middleware-location-constraint",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/middleware-logger",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/middleware-recursion-detection",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/middleware-sdk-s3",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/middleware-signing",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/middleware-ssec",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/middleware-user-agent",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/region-config-resolver",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/s3-request-presigner",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/signature-v4-multi-region",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/token-providers",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/types",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/util-arn-parser",
            "version": "3.568.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/util-endpoints",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/util-format-url",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/util-locate-window",
            "version": "3.873.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/util-user-agent-browser",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/util-user-agent-node",
            "version": "3.614.0",
            "type": "extra"
          },
          {
            "name": "@aws-sdk/xml-builder",
            "version": "3.609.0",
            "type": "extra"
          },
          {
            "name": "@babel/code-frame",
            "version": "7.27.1",
            "type": "extra"
          },
          {
            "name": "@babel/compat-data",
            "version": "7.28.0",
            "type": "extra"
          },
          {
            "name": "@babel/core",
            "version": "7.28.3",
            "type": "extra"
          },
          {
            "name": "@babel/generator",
            "version": "7.28.3",
            "type": "extra"
          },
          {
            "name": "@babel/helper-compilation-targets",
            "version": "7.27.2",
            "type": "extra"
          },
          {
            "name": "@babel/helper-globals",
            "version": "7.28.0",
            "type": "extra"
          },
          {
            "name": "@babel/helper-module-imports",
            "version": "7.27.1",
            "type": "extra"
          },
          {
            "name": "@babel/helper-module-transforms",
            "version": "7.28.3",
            "type": "extra"
          },
          {
            "name": "@babel/helper-plugin-utils",
            "version": "7.27.1",
            "type": "extra"
          },
          {
            "name": "@babel/helper-string-parser",
            "version": "7.27.1",
            "type": "extra"
          },
          {
            "name": "@babel/helper-validator-identifier",
            "version": "7.27.1",
            "type": "extra"
          },
          {
            "name": "@babel/helper-validator-option",
            "version": "7.27.1",
            "type": "extra"
          },
          {
            "name": "@babel/helpers",
            "version": "7.28.3",
            "type": "extra"
          },
          {
            "name": "@babel/parser",
            "version": "7.28.3",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-async-generators",
            "version": "7.8.4",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-bigint",
            "version": "7.8.3",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-class-properties",
            "version": "7.12.13",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-class-static-block",
            "version": "7.14.5",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-import-attributes",
            "version": "7.27.1",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-import-meta",
            "version": "7.10.4",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-json-strings",
            "version": "7.8.3",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-jsx",
            "version": "7.27.1",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-logical-assignment-operators",
            "version": "7.10.4",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-nullish-coalescing-operator",
            "version": "7.8.3",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-numeric-separator",
            "version": "7.10.4",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-object-rest-spread",
            "version": "7.8.3",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-optional-catch-binding",
            "version": "7.8.3",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-optional-chaining",
            "version": "7.8.3",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-private-property-in-object",
            "version": "7.14.5",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-top-level-await",
            "version": "7.14.5",
            "type": "extra"
          },
          {
            "name": "@babel/plugin-syntax-typescript",
            "version": "7.27.1",
            "type": "extra"
          },
          {
            "name": "@babel/runtime",
            "version": "7.28.3",
            "type": "extra"
          },
          {
            "name": "@babel/template",
            "version": "7.27.2",
            "type": "extra"
          },
          {
            "name": "@babel/traverse",
            "version": "7.28.3",
            "type": "extra"
          },
          {
            "name": "@babel/types",
            "version": "7.28.2",
            "type": "extra"
          },
          {
            "name": "@bcoe/v8-coverage",
            "version": "0.2.3",
            "type": "extra"
          },
          {
            "name": "@eslint-community/eslint-utils",
            "version": "4.7.0",
            "type": "extra"
          },
          {
            "name": "@eslint-community/regexpp",
            "version": "4.12.1",
            "type": "extra"
          },
          {
            "name": "@eslint/eslintrc",
            "version": "2.1.4",
            "type": "extra"
          },
          {
            "name": "@eslint/js",
            "version": "8.57.0",
            "type": "extra"
          },
          {
            "name": "@fastify/busboy",
            "version": "3.2.0",
            "type": "extra"
          },
          {
            "name": "@firebase/app-check-interop-types",
            "version": "0.3.2",
            "type": "extra"
          },
          {
            "name": "@firebase/app-types",
            "version": "0.9.3",
            "type": "extra"
          },
          {
            "name": "@firebase/auth-interop-types",
            "version": "0.2.3",
            "type": "extra"
          },
          {
            "name": "@firebase/component",
            "version": "0.6.10",
            "type": "extra"
          },
          {
            "name": "@firebase/database",
            "version": "1.0.9",
            "type": "extra"
          },
          {
            "name": "@firebase/database-compat",
            "version": "1.0.10",
            "type": "extra"
          },
          {
            "name": "@firebase/database-compat/node_modules/@firebase/app-types",
            "version": "0.9.2",
            "type": "extra"
          },
          {
            "name": "@firebase/database-compat/node_modules/@firebase/database-types",
            "version": "1.0.6",
            "type": "extra"
          },
          {
            "name": "@firebase/database-types",
            "version": "1.0.16",
            "type": "extra"
          },
          {
            "name": "@firebase/database-types/node_modules/@firebase/util",
            "version": "1.13.0",
            "type": "extra"
          },
          {
            "name": "@firebase/logger",
            "version": "0.4.3",
            "type": "extra"
          },
          {
            "name": "@firebase/util",
            "version": "1.10.1",
            "type": "extra"
          },
          {
            "name": "@google-cloud/firestore",
            "version": "7.11.3",
            "type": "extra"
          },
          {
            "name": "@google-cloud/paginator",
            "version": "5.0.2",
            "type": "extra"
          },
          {
            "name": "@google-cloud/projectify",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "@google-cloud/promisify",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "@google-cloud/storage",
            "version": "7.17.0",
            "type": "extra"
          },
          {
            "name": "@google-cloud/storage/node_modules/fast-xml-parser",
            "version": "4.5.3",
            "type": "extra"
          },
          {
            "name": "@google-cloud/storage/node_modules/uuid",
            "version": "8.3.2",
            "type": "extra"
          },
          {
            "name": "@grpc/grpc-js",
            "version": "1.13.4",
            "type": "extra"
          },
          {
            "name": "@grpc/proto-loader",
            "version": "0.7.15",
            "type": "extra"
          },
          {
            "name": "@humanwhocodes/config-array",
            "version": "0.11.14",
            "type": "extra"
          },
          {
            "name": "@humanwhocodes/module-importer",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "@humanwhocodes/object-schema",
            "version": "2.0.3",
            "type": "extra"
          },
          {
            "name": "@isaacs/cliui",
            "version": "8.0.2",
            "type": "extra"
          },
          {
            "name": "@isaacs/cliui/node_modules/ansi-regex",
            "version": "6.2.0",
            "type": "extra"
          },
          {
            "name": "@isaacs/cliui/node_modules/ansi-styles",
            "version": "6.2.1",
            "type": "extra"
          },
          {
            "name": "@isaacs/cliui/node_modules/emoji-regex",
            "version": "9.2.2",
            "type": "extra"
          },
          {
            "name": "@isaacs/cliui/node_modules/string-width",
            "version": "5.1.2",
            "type": "extra"
          },
          {
            "name": "@isaacs/cliui/node_modules/strip-ansi",
            "version": "7.1.0",
            "type": "extra"
          },
          {
            "name": "@isaacs/cliui/node_modules/wrap-ansi",
            "version": "8.1.0",
            "type": "extra"
          },
          {
            "name": "@istanbuljs/load-nyc-config",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "@istanbuljs/load-nyc-config/node_modules/argparse",
            "version": "1.0.10",
            "type": "extra"
          },
          {
            "name": "@istanbuljs/load-nyc-config/node_modules/find-up",
            "version": "4.1.0",
            "type": "extra"
          },
          {
            "name": "@istanbuljs/load-nyc-config/node_modules/js-yaml",
            "version": "3.14.1",
            "type": "extra"
          },
          {
            "name": "@istanbuljs/load-nyc-config/node_modules/locate-path",
            "version": "5.0.0",
            "type": "extra"
          },
          {
            "name": "@istanbuljs/load-nyc-config/node_modules/p-limit",
            "version": "2.3.0",
            "type": "extra"
          },
          {
            "name": "@istanbuljs/load-nyc-config/node_modules/p-locate",
            "version": "4.1.0",
            "type": "extra"
          },
          {
            "name": "@istanbuljs/load-nyc-config/node_modules/resolve-from",
            "version": "5.0.0",
            "type": "extra"
          },
          {
            "name": "@istanbuljs/schema",
            "version": "0.1.3",
            "type": "extra"
          },
          {
            "name": "@jest/console",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "@jest/core",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "@jest/environment",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "@jest/expect",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "@jest/expect-utils",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "@jest/fake-timers",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "@jest/globals",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "@jest/reporters",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "@jest/schemas",
            "version": "29.6.3",
            "type": "extra"
          },
          {
            "name": "@jest/source-map",
            "version": "29.6.3",
            "type": "extra"
          },
          {
            "name": "@jest/test-result",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "@jest/test-sequencer",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "@jest/transform",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "@jest/types",
            "version": "29.6.3",
            "type": "extra"
          },
          {
            "name": "@jridgewell/gen-mapping",
            "version": "0.3.13",
            "type": "extra"
          },
          {
            "name": "@jridgewell/resolve-uri",
            "version": "3.1.2",
            "type": "extra"
          },
          {
            "name": "@jridgewell/sourcemap-codec",
            "version": "1.5.5",
            "type": "extra"
          },
          {
            "name": "@jridgewell/trace-mapping",
            "version": "0.3.30",
            "type": "extra"
          },
          {
            "name": "@js-sdsl/ordered-map",
            "version": "4.4.2",
            "type": "extra"
          },
          {
            "name": "@lukeed/csprng",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "@nestjs/common",
            "version": "10.3.0",
            "type": "extra"
          },
          {
            "name": "@nestjs/common/node_modules/tslib",
            "version": "2.6.2",
            "type": "extra"
          },
          {
            "name": "@nestjs/core",
            "version": "10.4.20",
            "type": "extra"
          },
          {
            "name": "@nestjs/core/node_modules/path-to-regexp",
            "version": "3.3.0",
            "type": "extra"
          },
          {
            "name": "@nestjs/platform-express",
            "version": "10.3.0",
            "type": "extra"
          },
          {
            "name": "@nestjs/platform-express/node_modules/tslib",
            "version": "2.6.2",
            "type": "extra"
          },
          {
            "name": "@nodelib/fs.scandir",
            "version": "2.1.5",
            "type": "extra"
          },
          {
            "name": "@nodelib/fs.stat",
            "version": "2.0.5",
            "type": "extra"
          },
          {
            "name": "@nodelib/fs.walk",
            "version": "1.2.8",
            "type": "extra"
          },
          {
            "name": "@nuxtjs/opencollective",
            "version": "0.3.2",
            "type": "extra"
          },
          {
            "name": "@opentelemetry/api",
            "version": "1.9.0",
            "type": "extra"
          },
          {
            "name": "@pkgjs/parseargs",
            "version": "0.11.0",
            "type": "extra"
          },
          {
            "name": "@protobufjs/aspromise",
            "version": "1.1.2",
            "type": "extra"
          },
          {
            "name": "@protobufjs/base64",
            "version": "1.1.2",
            "type": "extra"
          },
          {
            "name": "@protobufjs/codegen",
            "version": "2.0.4",
            "type": "extra"
          },
          {
            "name": "@protobufjs/eventemitter",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "@protobufjs/fetch",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "@protobufjs/float",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "@protobufjs/inquire",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "@protobufjs/path",
            "version": "1.1.2",
            "type": "extra"
          },
          {
            "name": "@protobufjs/pool",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "@protobufjs/utf8",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "@sendgrid/client",
            "version": "8.1.5",
            "type": "extra"
          },
          {
            "name": "@sendgrid/client/node_modules/axios",
            "version": "1.11.0",
            "type": "extra"
          },
          {
            "name": "@sendgrid/helpers",
            "version": "8.0.0",
            "type": "extra"
          },
          {
            "name": "@sendgrid/mail",
            "version": "8.1.3",
            "type": "extra"
          },
          {
            "name": "@sinclair/typebox",
            "version": "0.27.8",
            "type": "extra"
          },
          {
            "name": "@sinonjs/commons",
            "version": "3.0.1",
            "type": "extra"
          },
          {
            "name": "@sinonjs/fake-timers",
            "version": "10.3.0",
            "type": "extra"
          },
          {
            "name": "@smithy/abort-controller",
            "version": "3.1.9",
            "type": "extra"
          },
          {
            "name": "@smithy/chunked-blob-reader",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "@smithy/chunked-blob-reader-native",
            "version": "3.0.1",
            "type": "extra"
          },
          {
            "name": "@smithy/config-resolver",
            "version": "3.0.13",
            "type": "extra"
          },
          {
            "name": "@smithy/core",
            "version": "2.5.7",
            "type": "extra"
          },
          {
            "name": "@smithy/credential-provider-imds",
            "version": "3.2.8",
            "type": "extra"
          },
          {
            "name": "@smithy/eventstream-codec",
            "version": "3.1.10",
            "type": "extra"
          },
          {
            "name": "@smithy/eventstream-serde-browser",
            "version": "3.0.14",
            "type": "extra"
          },
          {
            "name": "@smithy/eventstream-serde-config-resolver",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/eventstream-serde-node",
            "version": "3.0.13",
            "type": "extra"
          },
          {
            "name": "@smithy/eventstream-serde-universal",
            "version": "3.0.13",
            "type": "extra"
          },
          {
            "name": "@smithy/fetch-http-handler",
            "version": "3.2.9",
            "type": "extra"
          },
          {
            "name": "@smithy/hash-blob-browser",
            "version": "3.1.10",
            "type": "extra"
          },
          {
            "name": "@smithy/hash-node",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/hash-stream-node",
            "version": "3.1.10",
            "type": "extra"
          },
          {
            "name": "@smithy/invalid-dependency",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/is-array-buffer",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "@smithy/md5-js",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/middleware-content-length",
            "version": "3.0.13",
            "type": "extra"
          },
          {
            "name": "@smithy/middleware-endpoint",
            "version": "3.2.8",
            "type": "extra"
          },
          {
            "name": "@smithy/middleware-retry",
            "version": "3.0.34",
            "type": "extra"
          },
          {
            "name": "@smithy/middleware-retry/node_modules/uuid",
            "version": "9.0.1",
            "type": "extra"
          },
          {
            "name": "@smithy/middleware-serde",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/middleware-stack",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/node-config-provider",
            "version": "3.1.12",
            "type": "extra"
          },
          {
            "name": "@smithy/node-http-handler",
            "version": "3.3.3",
            "type": "extra"
          },
          {
            "name": "@smithy/property-provider",
            "version": "3.1.11",
            "type": "extra"
          },
          {
            "name": "@smithy/protocol-http",
            "version": "4.1.8",
            "type": "extra"
          },
          {
            "name": "@smithy/querystring-builder",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/querystring-parser",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/service-error-classification",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/shared-ini-file-loader",
            "version": "3.1.12",
            "type": "extra"
          },
          {
            "name": "@smithy/signature-v4",
            "version": "3.1.2",
            "type": "extra"
          },
          {
            "name": "@smithy/smithy-client",
            "version": "3.7.0",
            "type": "extra"
          },
          {
            "name": "@smithy/types",
            "version": "3.7.2",
            "type": "extra"
          },
          {
            "name": "@smithy/url-parser",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/util-base64",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "@smithy/util-body-length-browser",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "@smithy/util-body-length-node",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "@smithy/util-buffer-from",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "@smithy/util-config-provider",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "@smithy/util-defaults-mode-browser",
            "version": "3.0.34",
            "type": "extra"
          },
          {
            "name": "@smithy/util-defaults-mode-node",
            "version": "3.0.34",
            "type": "extra"
          },
          {
            "name": "@smithy/util-endpoints",
            "version": "2.1.7",
            "type": "extra"
          },
          {
            "name": "@smithy/util-hex-encoding",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "@smithy/util-middleware",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/util-retry",
            "version": "3.0.11",
            "type": "extra"
          },
          {
            "name": "@smithy/util-stream",
            "version": "3.3.4",
            "type": "extra"
          },
          {
            "name": "@smithy/util-stream/node_modules/@smithy/fetch-http-handler",
            "version": "4.1.3",
            "type": "extra"
          },
          {
            "name": "@smithy/util-uri-escape",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "@smithy/util-utf8",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "@smithy/util-waiter",
            "version": "3.2.0",
            "type": "extra"
          },
          {
            "name": "@sqltools/formatter",
            "version": "1.2.5",
            "type": "extra"
          },
          {
            "name": "@tootallnate/once",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "@types/babel__core",
            "version": "7.20.5",
            "type": "extra"
          },
          {
            "name": "@types/babel__generator",
            "version": "7.27.0",
            "type": "extra"
          },
          {
            "name": "@types/babel__template",
            "version": "7.4.4",
            "type": "extra"
          },
          {
            "name": "@types/babel__traverse",
            "version": "7.28.0",
            "type": "extra"
          },
          {
            "name": "@types/body-parser",
            "version": "1.19.6",
            "type": "extra"
          },
          {
            "name": "@types/caseless",
            "version": "0.12.5",
            "type": "extra"
          },
          {
            "name": "@types/connect",
            "version": "3.4.38",
            "type": "extra"
          },
          {
            "name": "@types/express",
            "version": "4.17.23",
            "type": "extra"
          },
          {
            "name": "@types/express-serve-static-core",
            "version": "4.19.6",
            "type": "extra"
          },
          {
            "name": "@types/graceful-fs",
            "version": "4.1.9",
            "type": "extra"
          },
          {
            "name": "@types/http-errors",
            "version": "2.0.5",
            "type": "extra"
          },
          {
            "name": "@types/istanbul-lib-coverage",
            "version": "2.0.6",
            "type": "extra"
          },
          {
            "name": "@types/istanbul-lib-report",
            "version": "3.0.3",
            "type": "extra"
          },
          {
            "name": "@types/istanbul-reports",
            "version": "3.0.4",
            "type": "extra"
          },
          {
            "name": "@types/jsonwebtoken",
            "version": "9.0.10",
            "type": "extra"
          },
          {
            "name": "@types/long",
            "version": "4.0.2",
            "type": "extra"
          },
          {
            "name": "@types/mime",
            "version": "1.3.5",
            "type": "extra"
          },
          {
            "name": "@types/ms",
            "version": "2.1.0",
            "type": "extra"
          },
          {
            "name": "@types/node",
            "version": "20.12.12",
            "type": "extra"
          },
          {
            "name": "@types/pg",
            "version": "8.15.5",
            "type": "extra"
          },
          {
            "name": "@types/qs",
            "version": "6.14.0",
            "type": "extra"
          },
          {
            "name": "@types/range-parser",
            "version": "1.2.7",
            "type": "extra"
          },
          {
            "name": "@types/request",
            "version": "2.48.13",
            "type": "extra"
          },
          {
            "name": "@types/request/node_modules/form-data",
            "version": "2.5.5",
            "type": "extra"
          },
          {
            "name": "@types/send",
            "version": "0.17.5",
            "type": "extra"
          },
          {
            "name": "@types/serve-static",
            "version": "1.15.8",
            "type": "extra"
          },
          {
            "name": "@types/stack-utils",
            "version": "2.0.3",
            "type": "extra"
          },
          {
            "name": "@types/tough-cookie",
            "version": "4.0.5",
            "type": "extra"
          },
          {
            "name": "@types/validator",
            "version": "13.15.2",
            "type": "extra"
          },
          {
            "name": "@types/yargs",
            "version": "17.0.33",
            "type": "extra"
          },
          {
            "name": "@types/yargs-parser",
            "version": "21.0.3",
            "type": "extra"
          },
          {
            "name": "@ungap/structured-clone",
            "version": "1.3.0",
            "type": "extra"
          },
          {
            "name": "abort-controller",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "accepts",
            "version": "1.3.8",
            "type": "extra"
          },
          {
            "name": "acorn",
            "version": "8.15.0",
            "type": "extra"
          },
          {
            "name": "acorn-jsx",
            "version": "5.3.2",
            "type": "extra"
          },
          {
            "name": "agent-base",
            "version": "7.1.4",
            "type": "extra"
          },
          {
            "name": "ajv",
            "version": "6.12.6",
            "type": "extra"
          },
          {
            "name": "ansi-escapes",
            "version": "4.3.2",
            "type": "extra"
          },
          {
            "name": "ansi-escapes/node_modules/type-fest",
            "version": "0.21.3",
            "type": "extra"
          },
          {
            "name": "ansi-regex",
            "version": "5.0.1",
            "type": "extra"
          },
          {
            "name": "ansi-styles",
            "version": "4.3.0",
            "type": "extra"
          },
          {
            "name": "any-promise",
            "version": "1.3.0",
            "type": "extra"
          },
          {
            "name": "anymatch",
            "version": "3.1.3",
            "type": "extra"
          },
          {
            "name": "app-root-path",
            "version": "3.1.0",
            "type": "extra"
          },
          {
            "name": "append-field",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "argparse",
            "version": "2.0.1",
            "type": "extra"
          },
          {
            "name": "array-buffer-byte-length",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "array-flatten",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "arraybuffer.prototype.slice",
            "version": "1.0.4",
            "type": "extra"
          },
          {
            "name": "arrify",
            "version": "2.0.1",
            "type": "extra"
          },
          {
            "name": "async-function",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "async-retry",
            "version": "1.3.3",
            "type": "extra"
          },
          {
            "name": "asynckit",
            "version": "0.4.0",
            "type": "extra"
          },
          {
            "name": "available-typed-arrays",
            "version": "1.0.7",
            "type": "extra"
          },
          {
            "name": "axios",
            "version": "1.7.4",
            "type": "extra"
          },
          {
            "name": "babel-jest",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "babel-plugin-istanbul",
            "version": "6.1.1",
            "type": "extra"
          },
          {
            "name": "babel-plugin-istanbul/node_modules/istanbul-lib-instrument",
            "version": "5.2.1",
            "type": "extra"
          },
          {
            "name": "babel-plugin-jest-hoist",
            "version": "29.6.3",
            "type": "extra"
          },
          {
            "name": "babel-preset-current-node-syntax",
            "version": "1.2.0",
            "type": "extra"
          },
          {
            "name": "babel-preset-jest",
            "version": "29.6.3",
            "type": "extra"
          },
          {
            "name": "balanced-match",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "base64-js",
            "version": "1.5.1",
            "type": "extra"
          },
          {
            "name": "bignumber.js",
            "version": "9.3.1",
            "type": "extra"
          },
          {
            "name": "binary-extensions",
            "version": "2.3.0",
            "type": "extra"
          },
          {
            "name": "body-parser",
            "version": "1.20.2",
            "type": "extra"
          },
          {
            "name": "body-parser/node_modules/debug",
            "version": "2.6.9",
            "type": "extra"
          },
          {
            "name": "body-parser/node_modules/ms",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "body-parser/node_modules/qs",
            "version": "6.11.0",
            "type": "extra"
          },
          {
            "name": "bowser",
            "version": "2.12.1",
            "type": "extra"
          },
          {
            "name": "brace-expansion",
            "version": "1.1.12",
            "type": "extra"
          },
          {
            "name": "braces",
            "version": "3.0.3",
            "type": "extra"
          },
          {
            "name": "browserslist",
            "version": "4.25.3",
            "type": "extra"
          },
          {
            "name": "bser",
            "version": "2.1.1",
            "type": "extra"
          },
          {
            "name": "buffer",
            "version": "6.0.3",
            "type": "extra"
          },
          {
            "name": "buffer-equal-constant-time",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "buffer-from",
            "version": "1.1.2",
            "type": "extra"
          },
          {
            "name": "busboy",
            "version": "1.6.0",
            "type": "extra"
          },
          {
            "name": "bytes",
            "version": "3.1.2",
            "type": "extra"
          },
          {
            "name": "call-bind",
            "version": "1.0.8",
            "type": "extra"
          },
          {
            "name": "call-bind-apply-helpers",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "call-bound",
            "version": "1.0.4",
            "type": "extra"
          },
          {
            "name": "callsites",
            "version": "3.1.0",
            "type": "extra"
          },
          {
            "name": "camelcase",
            "version": "5.3.1",
            "type": "extra"
          },
          {
            "name": "caniuse-lite",
            "version": "1.0.30001737",
            "type": "extra"
          },
          {
            "name": "chalk",
            "version": "4.1.2",
            "type": "extra"
          },
          {
            "name": "chalk/node_modules/supports-color",
            "version": "7.2.0",
            "type": "extra"
          },
          {
            "name": "char-regex",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "chokidar",
            "version": "3.6.0",
            "type": "extra"
          },
          {
            "name": "chokidar/node_modules/glob-parent",
            "version": "5.1.2",
            "type": "extra"
          },
          {
            "name": "ci-info",
            "version": "3.9.0",
            "type": "extra"
          },
          {
            "name": "cjs-module-lexer",
            "version": "1.4.3",
            "type": "extra"
          },
          {
            "name": "class-transformer",
            "version": "0.5.1",
            "type": "extra"
          },
          {
            "name": "class-validator",
            "version": "0.14.2",
            "type": "extra"
          },
          {
            "name": "cli-highlight",
            "version": "2.1.11",
            "type": "extra"
          },
          {
            "name": "cli-highlight/node_modules/cliui",
            "version": "7.0.4",
            "type": "extra"
          },
          {
            "name": "cli-highlight/node_modules/yargs",
            "version": "16.2.0",
            "type": "extra"
          },
          {
            "name": "cli-highlight/node_modules/yargs-parser",
            "version": "20.2.9",
            "type": "extra"
          },
          {
            "name": "cliui",
            "version": "8.0.1",
            "type": "extra"
          },
          {
            "name": "co",
            "version": "4.6.0",
            "type": "extra"
          },
          {
            "name": "collect-v8-coverage",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "color-convert",
            "version": "2.0.1",
            "type": "extra"
          },
          {
            "name": "color-name",
            "version": "1.1.4",
            "type": "extra"
          },
          {
            "name": "combined-stream",
            "version": "1.0.8",
            "type": "extra"
          },
          {
            "name": "concat-map",
            "version": "0.0.1",
            "type": "extra"
          },
          {
            "name": "concat-stream",
            "version": "1.6.2",
            "type": "extra"
          },
          {
            "name": "concat-stream/node_modules/isarray",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "concat-stream/node_modules/readable-stream",
            "version": "2.3.8",
            "type": "extra"
          },
          {
            "name": "concat-stream/node_modules/safe-buffer",
            "version": "5.1.2",
            "type": "extra"
          },
          {
            "name": "concat-stream/node_modules/string_decoder",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "consola",
            "version": "2.15.3",
            "type": "extra"
          },
          {
            "name": "content-disposition",
            "version": "0.5.4",
            "type": "extra"
          },
          {
            "name": "content-type",
            "version": "1.0.5",
            "type": "extra"
          },
          {
            "name": "convert-source-map",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "cookie",
            "version": "0.5.0",
            "type": "extra"
          },
          {
            "name": "cookie-signature",
            "version": "1.0.6",
            "type": "extra"
          },
          {
            "name": "core-util-is",
            "version": "1.0.3",
            "type": "extra"
          },
          {
            "name": "cors",
            "version": "2.8.5",
            "type": "extra"
          },
          {
            "name": "create-jest",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "cross-spawn",
            "version": "7.0.6",
            "type": "extra"
          },
          {
            "name": "data-view-buffer",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "data-view-byte-length",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "data-view-byte-offset",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "date-fns",
            "version": "2.30.0",
            "type": "extra"
          },
          {
            "name": "dayjs",
            "version": "1.11.13",
            "type": "extra"
          },
          {
            "name": "debug",
            "version": "4.4.1",
            "type": "extra"
          },
          {
            "name": "dedent",
            "version": "1.6.0",
            "type": "extra"
          },
          {
            "name": "deep-is",
            "version": "0.1.4",
            "type": "extra"
          },
          {
            "name": "deepmerge",
            "version": "4.3.1",
            "type": "extra"
          },
          {
            "name": "define-data-property",
            "version": "1.1.4",
            "type": "extra"
          },
          {
            "name": "define-properties",
            "version": "1.2.1",
            "type": "extra"
          },
          {
            "name": "delayed-stream",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "depd",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "destroy",
            "version": "1.2.0",
            "type": "extra"
          },
          {
            "name": "detect-newline",
            "version": "3.1.0",
            "type": "extra"
          },
          {
            "name": "diff-sequences",
            "version": "29.6.3",
            "type": "extra"
          },
          {
            "name": "doctrine",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "dunder-proto",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "duplexify",
            "version": "4.1.3",
            "type": "extra"
          },
          {
            "name": "eastasianwidth",
            "version": "0.2.0",
            "type": "extra"
          },
          {
            "name": "ecdsa-sig-formatter",
            "version": "1.0.11",
            "type": "extra"
          },
          {
            "name": "ee-first",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "electron-to-chromium",
            "version": "1.5.208",
            "type": "extra"
          },
          {
            "name": "emittery",
            "version": "0.13.1",
            "type": "extra"
          },
          {
            "name": "emoji-regex",
            "version": "8.0.0",
            "type": "extra"
          },
          {
            "name": "encodeurl",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "end-of-stream",
            "version": "1.4.5",
            "type": "extra"
          },
          {
            "name": "error-ex",
            "version": "1.3.2",
            "type": "extra"
          },
          {
            "name": "es-abstract",
            "version": "1.24.0",
            "type": "extra"
          },
          {
            "name": "es-define-property",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "es-errors",
            "version": "1.3.0",
            "type": "extra"
          },
          {
            "name": "es-object-atoms",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "es-set-tostringtag",
            "version": "2.1.0",
            "type": "extra"
          },
          {
            "name": "es-to-primitive",
            "version": "1.3.0",
            "type": "extra"
          },
          {
            "name": "escalade",
            "version": "3.2.0",
            "type": "extra"
          },
          {
            "name": "escape-html",
            "version": "1.0.3",
            "type": "extra"
          },
          {
            "name": "escape-string-regexp",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "eslint-import-resolver-node",
            "version": "0.3.9",
            "type": "extra"
          },
          {
            "name": "eslint-import-resolver-node/node_modules/debug",
            "version": "3.2.7",
            "type": "extra"
          },
          {
            "name": "eslint-module-utils",
            "version": "2.12.0",
            "type": "extra"
          },
          {
            "name": "eslint-module-utils/node_modules/debug",
            "version": "3.2.7",
            "type": "extra"
          },
          {
            "name": "eslint-scope",
            "version": "7.2.2",
            "type": "extra"
          },
          {
            "name": "eslint-visitor-keys",
            "version": "3.4.3",
            "type": "extra"
          },
          {
            "name": "espree",
            "version": "9.6.1",
            "type": "extra"
          },
          {
            "name": "esprima",
            "version": "4.0.1",
            "type": "extra"
          },
          {
            "name": "esquery",
            "version": "1.6.0",
            "type": "extra"
          },
          {
            "name": "esrecurse",
            "version": "4.3.0",
            "type": "extra"
          },
          {
            "name": "estraverse",
            "version": "5.3.0",
            "type": "extra"
          },
          {
            "name": "esutils",
            "version": "2.0.3",
            "type": "extra"
          },
          {
            "name": "etag",
            "version": "1.8.1",
            "type": "extra"
          },
          {
            "name": "event-target-shim",
            "version": "5.0.1",
            "type": "extra"
          },
          {
            "name": "execa",
            "version": "5.1.1",
            "type": "extra"
          },
          {
            "name": "exit",
            "version": "0.1.2",
            "type": "extra"
          },
          {
            "name": "expect",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "express",
            "version": "4.18.2",
            "type": "extra"
          },
          {
            "name": "express/node_modules/body-parser",
            "version": "1.20.1",
            "type": "extra"
          },
          {
            "name": "express/node_modules/debug",
            "version": "2.6.9",
            "type": "extra"
          },
          {
            "name": "express/node_modules/ms",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "express/node_modules/qs",
            "version": "6.11.0",
            "type": "extra"
          },
          {
            "name": "express/node_modules/raw-body",
            "version": "2.5.1",
            "type": "extra"
          },
          {
            "name": "extend",
            "version": "3.0.2",
            "type": "extra"
          },
          {
            "name": "farmhash-modern",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "fast-deep-equal",
            "version": "3.1.3",
            "type": "extra"
          },
          {
            "name": "fast-json-stable-stringify",
            "version": "2.1.0",
            "type": "extra"
          },
          {
            "name": "fast-levenshtein",
            "version": "2.0.6",
            "type": "extra"
          },
          {
            "name": "fast-safe-stringify",
            "version": "2.1.1",
            "type": "extra"
          },
          {
            "name": "fast-xml-parser",
            "version": "4.2.5",
            "type": "extra"
          },
          {
            "name": "fastq",
            "version": "1.19.1",
            "type": "extra"
          },
          {
            "name": "faye-websocket",
            "version": "0.11.4",
            "type": "extra"
          },
          {
            "name": "fb-watchman",
            "version": "2.0.2",
            "type": "extra"
          },
          {
            "name": "file-entry-cache",
            "version": "6.0.1",
            "type": "extra"
          },
          {
            "name": "fill-range",
            "version": "7.1.1",
            "type": "extra"
          },
          {
            "name": "finalhandler",
            "version": "1.2.0",
            "type": "extra"
          },
          {
            "name": "finalhandler/node_modules/debug",
            "version": "2.6.9",
            "type": "extra"
          },
          {
            "name": "finalhandler/node_modules/ms",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "find-up",
            "version": "5.0.0",
            "type": "extra"
          },
          {
            "name": "firebase-admin",
            "version": "12.3.1",
            "type": "extra"
          },
          {
            "name": "firebase-admin/node_modules/@types/node",
            "version": "22.18.0",
            "type": "extra"
          },
          {
            "name": "firebase-admin/node_modules/undici-types",
            "version": "6.21.0",
            "type": "extra"
          },
          {
            "name": "firebase-admin/node_modules/uuid",
            "version": "10.0.0",
            "type": "extra"
          },
          {
            "name": "flat-cache",
            "version": "3.2.0",
            "type": "extra"
          },
          {
            "name": "flatted",
            "version": "3.3.3",
            "type": "extra"
          },
          {
            "name": "follow-redirects",
            "version": "1.15.11",
            "type": "extra"
          },
          {
            "name": "for-each",
            "version": "0.3.5",
            "type": "extra"
          },
          {
            "name": "foreground-child",
            "version": "3.3.1",
            "type": "extra"
          },
          {
            "name": "foreground-child/node_modules/signal-exit",
            "version": "4.1.0",
            "type": "extra"
          },
          {
            "name": "form-data",
            "version": "4.0.4",
            "type": "extra"
          },
          {
            "name": "forwarded",
            "version": "0.2.0",
            "type": "extra"
          },
          {
            "name": "fresh",
            "version": "0.5.2",
            "type": "extra"
          },
          {
            "name": "fs.realpath",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "fsevents",
            "version": "2.3.3",
            "type": "extra"
          },
          {
            "name": "function-bind",
            "version": "1.1.2",
            "type": "extra"
          },
          {
            "name": "function.prototype.name",
            "version": "1.1.8",
            "type": "extra"
          },
          {
            "name": "functional-red-black-tree",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "functions-have-names",
            "version": "1.2.3",
            "type": "extra"
          },
          {
            "name": "gaxios",
            "version": "6.7.1",
            "type": "extra"
          },
          {
            "name": "gaxios/node_modules/uuid",
            "version": "9.0.1",
            "type": "extra"
          },
          {
            "name": "gcp-metadata",
            "version": "6.1.1",
            "type": "extra"
          },
          {
            "name": "gensync",
            "version": "1.0.0-beta.2",
            "type": "extra"
          },
          {
            "name": "get-caller-file",
            "version": "2.0.5",
            "type": "extra"
          },
          {
            "name": "get-intrinsic",
            "version": "1.3.0",
            "type": "extra"
          },
          {
            "name": "get-package-type",
            "version": "0.1.0",
            "type": "extra"
          },
          {
            "name": "get-proto",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "get-stream",
            "version": "6.0.1",
            "type": "extra"
          },
          {
            "name": "get-symbol-description",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "glob",
            "version": "7.2.3",
            "type": "extra"
          },
          {
            "name": "glob-parent",
            "version": "6.0.2",
            "type": "extra"
          },
          {
            "name": "globals",
            "version": "13.24.0",
            "type": "extra"
          },
          {
            "name": "globalthis",
            "version": "1.0.4",
            "type": "extra"
          },
          {
            "name": "google-auth-library",
            "version": "9.15.1",
            "type": "extra"
          },
          {
            "name": "google-gax",
            "version": "4.6.1",
            "type": "extra"
          },
          {
            "name": "google-gax/node_modules/uuid",
            "version": "9.0.1",
            "type": "extra"
          },
          {
            "name": "google-logging-utils",
            "version": "0.0.2",
            "type": "extra"
          },
          {
            "name": "gopd",
            "version": "1.2.0",
            "type": "extra"
          },
          {
            "name": "graceful-fs",
            "version": "4.2.11",
            "type": "extra"
          },
          {
            "name": "graphemer",
            "version": "1.4.0",
            "type": "extra"
          },
          {
            "name": "gtoken",
            "version": "7.1.0",
            "type": "extra"
          },
          {
            "name": "has-bigints",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "has-flag",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "has-property-descriptors",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "has-proto",
            "version": "1.2.0",
            "type": "extra"
          },
          {
            "name": "has-symbols",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "has-tostringtag",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "hasown",
            "version": "2.0.2",
            "type": "extra"
          },
          {
            "name": "highlight.js",
            "version": "10.7.3",
            "type": "extra"
          },
          {
            "name": "hosted-git-info",
            "version": "2.8.9",
            "type": "extra"
          },
          {
            "name": "html-entities",
            "version": "2.6.0",
            "type": "extra"
          },
          {
            "name": "html-escaper",
            "version": "2.0.2",
            "type": "extra"
          },
          {
            "name": "http-errors",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "http-parser-js",
            "version": "0.5.10",
            "type": "extra"
          },
          {
            "name": "http-proxy-agent",
            "version": "5.0.0",
            "type": "extra"
          },
          {
            "name": "http-proxy-agent/node_modules/agent-base",
            "version": "6.0.2",
            "type": "extra"
          },
          {
            "name": "https-proxy-agent",
            "version": "7.0.6",
            "type": "extra"
          },
          {
            "name": "human-signals",
            "version": "2.1.0",
            "type": "extra"
          },
          {
            "name": "iconv-lite",
            "version": "0.4.24",
            "type": "extra"
          },
          {
            "name": "ieee754",
            "version": "1.2.1",
            "type": "extra"
          },
          {
            "name": "ignore",
            "version": "5.3.2",
            "type": "extra"
          },
          {
            "name": "ignore-by-default",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "import-fresh",
            "version": "3.3.1",
            "type": "extra"
          },
          {
            "name": "import-local",
            "version": "3.2.0",
            "type": "extra"
          },
          {
            "name": "imurmurhash",
            "version": "0.1.4",
            "type": "extra"
          },
          {
            "name": "inflight",
            "version": "1.0.6",
            "type": "extra"
          },
          {
            "name": "inherits",
            "version": "2.0.4",
            "type": "extra"
          },
          {
            "name": "internal-slot",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "ipaddr.js",
            "version": "1.9.1",
            "type": "extra"
          },
          {
            "name": "is-array-buffer",
            "version": "3.0.5",
            "type": "extra"
          },
          {
            "name": "is-arrayish",
            "version": "0.2.1",
            "type": "extra"
          },
          {
            "name": "is-async-function",
            "version": "2.1.1",
            "type": "extra"
          },
          {
            "name": "is-bigint",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "is-binary-path",
            "version": "2.1.0",
            "type": "extra"
          },
          {
            "name": "is-boolean-object",
            "version": "1.2.2",
            "type": "extra"
          },
          {
            "name": "is-callable",
            "version": "1.2.7",
            "type": "extra"
          },
          {
            "name": "is-core-module",
            "version": "2.16.1",
            "type": "extra"
          },
          {
            "name": "is-data-view",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "is-date-object",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "is-extglob",
            "version": "2.1.1",
            "type": "extra"
          },
          {
            "name": "is-finalizationregistry",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "is-fullwidth-code-point",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "is-generator-fn",
            "version": "2.1.0",
            "type": "extra"
          },
          {
            "name": "is-generator-function",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "is-glob",
            "version": "4.0.3",
            "type": "extra"
          },
          {
            "name": "is-map",
            "version": "2.0.3",
            "type": "extra"
          },
          {
            "name": "is-negative-zero",
            "version": "2.0.3",
            "type": "extra"
          },
          {
            "name": "is-number",
            "version": "7.0.0",
            "type": "extra"
          },
          {
            "name": "is-number-object",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "is-path-inside",
            "version": "3.0.3",
            "type": "extra"
          },
          {
            "name": "is-regex",
            "version": "1.2.1",
            "type": "extra"
          },
          {
            "name": "is-set",
            "version": "2.0.3",
            "type": "extra"
          },
          {
            "name": "is-shared-array-buffer",
            "version": "1.0.4",
            "type": "extra"
          },
          {
            "name": "is-stream",
            "version": "2.0.1",
            "type": "extra"
          },
          {
            "name": "is-string",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "is-symbol",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "is-typed-array",
            "version": "1.1.15",
            "type": "extra"
          },
          {
            "name": "is-weakmap",
            "version": "2.0.2",
            "type": "extra"
          },
          {
            "name": "is-weakref",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "is-weakset",
            "version": "2.0.4",
            "type": "extra"
          },
          {
            "name": "isarray",
            "version": "2.0.5",
            "type": "extra"
          },
          {
            "name": "isexe",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "istanbul-lib-coverage",
            "version": "3.2.2",
            "type": "extra"
          },
          {
            "name": "istanbul-lib-instrument",
            "version": "6.0.3",
            "type": "extra"
          },
          {
            "name": "istanbul-lib-instrument/node_modules/semver",
            "version": "7.7.2",
            "type": "extra"
          },
          {
            "name": "istanbul-lib-report",
            "version": "3.0.1",
            "type": "extra"
          },
          {
            "name": "istanbul-lib-report/node_modules/supports-color",
            "version": "7.2.0",
            "type": "extra"
          },
          {
            "name": "istanbul-lib-source-maps",
            "version": "4.0.1",
            "type": "extra"
          },
          {
            "name": "istanbul-reports",
            "version": "3.2.0",
            "type": "extra"
          },
          {
            "name": "iterare",
            "version": "1.2.1",
            "type": "extra"
          },
          {
            "name": "jackspeak",
            "version": "3.4.3",
            "type": "extra"
          },
          {
            "name": "jest",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-changed-files",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-circus",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-cli",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-config",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-diff",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-docblock",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-each",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-environment-node",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-get-type",
            "version": "29.6.3",
            "type": "extra"
          },
          {
            "name": "jest-haste-map",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-leak-detector",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-matcher-utils",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-message-util",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-mock",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-pnp-resolver",
            "version": "1.2.3",
            "type": "extra"
          },
          {
            "name": "jest-regex-util",
            "version": "29.6.3",
            "type": "extra"
          },
          {
            "name": "jest-resolve",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-resolve-dependencies",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-runner",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-runtime",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-snapshot",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-snapshot/node_modules/semver",
            "version": "7.7.2",
            "type": "extra"
          },
          {
            "name": "jest-util",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-validate",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-validate/node_modules/camelcase",
            "version": "6.3.0",
            "type": "extra"
          },
          {
            "name": "jest-watcher",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jest-worker",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "jose",
            "version": "4.15.9",
            "type": "extra"
          },
          {
            "name": "js-tokens",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "js-yaml",
            "version": "4.1.0",
            "type": "extra"
          },
          {
            "name": "jsesc",
            "version": "3.1.0",
            "type": "extra"
          },
          {
            "name": "json-bigint",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "json-buffer",
            "version": "3.0.1",
            "type": "extra"
          },
          {
            "name": "json-parse-better-errors",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "json-parse-even-better-errors",
            "version": "2.3.1",
            "type": "extra"
          },
          {
            "name": "json-schema-traverse",
            "version": "0.4.1",
            "type": "extra"
          },
          {
            "name": "json-stable-stringify-without-jsonify",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "json5",
            "version": "2.2.3",
            "type": "extra"
          },
          {
            "name": "jsonwebtoken/node_modules/jwa",
            "version": "1.4.2",
            "type": "extra"
          },
          {
            "name": "jsonwebtoken/node_modules/jws",
            "version": "3.2.2",
            "type": "extra"
          },
          {
            "name": "jsonwebtoken/node_modules/semver",
            "version": "7.7.2",
            "type": "extra"
          },
          {
            "name": "jwa",
            "version": "2.0.1",
            "type": "extra"
          },
          {
            "name": "jwks-rsa",
            "version": "3.2.0",
            "type": "extra"
          },
          {
            "name": "jws",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "keyv",
            "version": "4.5.4",
            "type": "extra"
          },
          {
            "name": "kleur",
            "version": "3.0.3",
            "type": "extra"
          },
          {
            "name": "leven",
            "version": "3.1.0",
            "type": "extra"
          },
          {
            "name": "levn",
            "version": "0.4.1",
            "type": "extra"
          },
          {
            "name": "libphonenumber-js",
            "version": "1.12.13",
            "type": "extra"
          },
          {
            "name": "limiter",
            "version": "1.1.5",
            "type": "extra"
          },
          {
            "name": "lines-and-columns",
            "version": "1.2.4",
            "type": "extra"
          },
          {
            "name": "load-json-file",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "load-json-file/node_modules/parse-json",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "load-json-file/node_modules/strip-bom",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "locate-path",
            "version": "6.0.0",
            "type": "extra"
          },
          {
            "name": "lodash",
            "version": "4.17.21",
            "type": "extra"
          },
          {
            "name": "lodash.camelcase",
            "version": "4.3.0",
            "type": "extra"
          },
          {
            "name": "lodash.clonedeep",
            "version": "4.5.0",
            "type": "extra"
          },
          {
            "name": "lodash.includes",
            "version": "4.3.0",
            "type": "extra"
          },
          {
            "name": "lodash.isboolean",
            "version": "3.0.3",
            "type": "extra"
          },
          {
            "name": "lodash.isinteger",
            "version": "4.0.4",
            "type": "extra"
          },
          {
            "name": "lodash.isnumber",
            "version": "3.0.3",
            "type": "extra"
          },
          {
            "name": "lodash.isplainobject",
            "version": "4.0.6",
            "type": "extra"
          },
          {
            "name": "lodash.isstring",
            "version": "4.0.1",
            "type": "extra"
          },
          {
            "name": "lodash.merge",
            "version": "4.6.2",
            "type": "extra"
          },
          {
            "name": "lodash.once",
            "version": "4.1.1",
            "type": "extra"
          },
          {
            "name": "long",
            "version": "5.3.2",
            "type": "extra"
          },
          {
            "name": "lru-cache",
            "version": "5.1.1",
            "type": "extra"
          },
          {
            "name": "lru-memoizer",
            "version": "2.3.0",
            "type": "extra"
          },
          {
            "name": "lru-memoizer/node_modules/lru-cache",
            "version": "6.0.0",
            "type": "extra"
          },
          {
            "name": "lru-memoizer/node_modules/yallist",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "make-dir",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "make-dir/node_modules/semver",
            "version": "7.7.2",
            "type": "extra"
          },
          {
            "name": "makeerror",
            "version": "1.0.12",
            "type": "extra"
          },
          {
            "name": "math-intrinsics",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "media-typer",
            "version": "0.3.0",
            "type": "extra"
          },
          {
            "name": "memorystream",
            "version": "0.3.1",
            "type": "extra"
          },
          {
            "name": "merge-descriptors",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "merge-stream",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "methods",
            "version": "1.1.2",
            "type": "extra"
          },
          {
            "name": "micromatch",
            "version": "4.0.8",
            "type": "extra"
          },
          {
            "name": "mime",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "mime-db",
            "version": "1.52.0",
            "type": "extra"
          },
          {
            "name": "mime-types",
            "version": "2.1.35",
            "type": "extra"
          },
          {
            "name": "mimic-fn",
            "version": "2.1.0",
            "type": "extra"
          },
          {
            "name": "minimatch",
            "version": "3.1.2",
            "type": "extra"
          },
          {
            "name": "minimist",
            "version": "1.2.8",
            "type": "extra"
          },
          {
            "name": "minipass",
            "version": "7.1.2",
            "type": "extra"
          },
          {
            "name": "mkdirp",
            "version": "2.1.6",
            "type": "extra"
          },
          {
            "name": "ms",
            "version": "2.1.3",
            "type": "extra"
          },
          {
            "name": "multer",
            "version": "1.4.4-lts.1",
            "type": "extra"
          },
          {
            "name": "multer/node_modules/mkdirp",
            "version": "0.5.6",
            "type": "extra"
          },
          {
            "name": "mz",
            "version": "2.7.0",
            "type": "extra"
          },
          {
            "name": "natural-compare",
            "version": "1.4.0",
            "type": "extra"
          },
          {
            "name": "negotiator",
            "version": "0.6.3",
            "type": "extra"
          },
          {
            "name": "nice-try",
            "version": "1.0.5",
            "type": "extra"
          },
          {
            "name": "node-fetch",
            "version": "2.7.0",
            "type": "extra"
          },
          {
            "name": "node-forge",
            "version": "1.3.1",
            "type": "extra"
          },
          {
            "name": "node-int64",
            "version": "0.4.0",
            "type": "extra"
          },
          {
            "name": "node-releases",
            "version": "2.0.19",
            "type": "extra"
          },
          {
            "name": "nodemon",
            "version": "3.0.2",
            "type": "extra"
          },
          {
            "name": "nodemon/node_modules/has-flag",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "nodemon/node_modules/semver",
            "version": "7.7.2",
            "type": "extra"
          },
          {
            "name": "nodemon/node_modules/supports-color",
            "version": "5.5.0",
            "type": "extra"
          },
          {
            "name": "normalize-package-data",
            "version": "2.5.0",
            "type": "extra"
          },
          {
            "name": "normalize-package-data/node_modules/semver",
            "version": "5.7.2",
            "type": "extra"
          },
          {
            "name": "normalize-path",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/ansi-styles",
            "version": "3.2.1",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/chalk",
            "version": "2.4.2",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/color-convert",
            "version": "1.9.3",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/color-name",
            "version": "1.1.3",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/cross-spawn",
            "version": "6.0.6",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/escape-string-regexp",
            "version": "1.0.5",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/has-flag",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/path-key",
            "version": "2.0.1",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/semver",
            "version": "5.7.2",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/shebang-command",
            "version": "1.2.0",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/shebang-regex",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/supports-color",
            "version": "5.5.0",
            "type": "extra"
          },
          {
            "name": "npm-run-all/node_modules/which",
            "version": "1.3.1",
            "type": "extra"
          },
          {
            "name": "npm-run-path",
            "version": "4.0.1",
            "type": "extra"
          },
          {
            "name": "object-assign",
            "version": "4.1.1",
            "type": "extra"
          },
          {
            "name": "object-hash",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "object-inspect",
            "version": "1.13.4",
            "type": "extra"
          },
          {
            "name": "object-keys",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "object.assign",
            "version": "4.1.7",
            "type": "extra"
          },
          {
            "name": "on-finished",
            "version": "2.4.1",
            "type": "extra"
          },
          {
            "name": "once",
            "version": "1.4.0",
            "type": "extra"
          },
          {
            "name": "onetime",
            "version": "5.1.2",
            "type": "extra"
          },
          {
            "name": "optionator",
            "version": "0.9.4",
            "type": "extra"
          },
          {
            "name": "own-keys",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "p-limit",
            "version": "3.1.0",
            "type": "extra"
          },
          {
            "name": "p-locate",
            "version": "5.0.0",
            "type": "extra"
          },
          {
            "name": "p-try",
            "version": "2.2.0",
            "type": "extra"
          },
          {
            "name": "package-json-from-dist",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "parent-module",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "parse-json",
            "version": "5.2.0",
            "type": "extra"
          },
          {
            "name": "parse5",
            "version": "5.1.1",
            "type": "extra"
          },
          {
            "name": "parse5-htmlparser2-tree-adapter",
            "version": "6.0.1",
            "type": "extra"
          },
          {
            "name": "parse5-htmlparser2-tree-adapter/node_modules/parse5",
            "version": "6.0.1",
            "type": "extra"
          },
          {
            "name": "parseurl",
            "version": "1.3.3",
            "type": "extra"
          },
          {
            "name": "path-exists",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "path-is-absolute",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "path-key",
            "version": "3.1.1",
            "type": "extra"
          },
          {
            "name": "path-parse",
            "version": "1.0.7",
            "type": "extra"
          },
          {
            "name": "path-scurry",
            "version": "1.11.1",
            "type": "extra"
          },
          {
            "name": "path-scurry/node_modules/lru-cache",
            "version": "10.4.3",
            "type": "extra"
          },
          {
            "name": "path-to-regexp",
            "version": "0.1.7",
            "type": "extra"
          },
          {
            "name": "path-type",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "pg-cloudflare",
            "version": "1.2.7",
            "type": "extra"
          },
          {
            "name": "pg-connection-string",
            "version": "2.9.1",
            "type": "extra"
          },
          {
            "name": "pg-int8",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "pg-pool",
            "version": "3.10.1",
            "type": "extra"
          },
          {
            "name": "pg-protocol",
            "version": "1.10.3",
            "type": "extra"
          },
          {
            "name": "pg-types",
            "version": "2.2.0",
            "type": "extra"
          },
          {
            "name": "pgpass",
            "version": "1.0.5",
            "type": "extra"
          },
          {
            "name": "picocolors",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "picomatch",
            "version": "2.3.1",
            "type": "extra"
          },
          {
            "name": "pidtree",
            "version": "0.3.1",
            "type": "extra"
          },
          {
            "name": "pify",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "pirates",
            "version": "4.0.7",
            "type": "extra"
          },
          {
            "name": "pkg-dir",
            "version": "4.2.0",
            "type": "extra"
          },
          {
            "name": "pkg-dir/node_modules/find-up",
            "version": "4.1.0",
            "type": "extra"
          },
          {
            "name": "pkg-dir/node_modules/locate-path",
            "version": "5.0.0",
            "type": "extra"
          },
          {
            "name": "pkg-dir/node_modules/p-limit",
            "version": "2.3.0",
            "type": "extra"
          },
          {
            "name": "pkg-dir/node_modules/p-locate",
            "version": "4.1.0",
            "type": "extra"
          },
          {
            "name": "possible-typed-array-names",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "postgres-array",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "postgres-bytea",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "postgres-date",
            "version": "1.0.7",
            "type": "extra"
          },
          {
            "name": "postgres-interval",
            "version": "1.2.0",
            "type": "extra"
          },
          {
            "name": "prelude-ls",
            "version": "1.2.1",
            "type": "extra"
          },
          {
            "name": "pretty-format",
            "version": "29.7.0",
            "type": "extra"
          },
          {
            "name": "pretty-format/node_modules/ansi-styles",
            "version": "5.2.0",
            "type": "extra"
          },
          {
            "name": "process-nextick-args",
            "version": "2.0.1",
            "type": "extra"
          },
          {
            "name": "prompts",
            "version": "2.4.2",
            "type": "extra"
          },
          {
            "name": "proto3-json-serializer",
            "version": "2.0.2",
            "type": "extra"
          },
          {
            "name": "protobufjs",
            "version": "7.5.4",
            "type": "extra"
          },
          {
            "name": "proxy-addr",
            "version": "2.0.7",
            "type": "extra"
          },
          {
            "name": "proxy-from-env",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "pstree.remy",
            "version": "1.1.8",
            "type": "extra"
          },
          {
            "name": "punycode",
            "version": "2.3.1",
            "type": "extra"
          },
          {
            "name": "pure-rand",
            "version": "6.1.0",
            "type": "extra"
          },
          {
            "name": "qs",
            "version": "6.14.0",
            "type": "extra"
          },
          {
            "name": "queue-microtask",
            "version": "1.2.3",
            "type": "extra"
          },
          {
            "name": "range-parser",
            "version": "1.2.1",
            "type": "extra"
          },
          {
            "name": "raw-body",
            "version": "2.5.2",
            "type": "extra"
          },
          {
            "name": "react-is",
            "version": "18.3.1",
            "type": "extra"
          },
          {
            "name": "read-pkg",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "readable-stream",
            "version": "3.6.2",
            "type": "extra"
          },
          {
            "name": "readdirp",
            "version": "3.6.0",
            "type": "extra"
          },
          {
            "name": "reflect-metadata",
            "version": "0.2.2",
            "type": "extra"
          },
          {
            "name": "reflect.getprototypeof",
            "version": "1.0.10",
            "type": "extra"
          },
          {
            "name": "regexp.prototype.flags",
            "version": "1.5.4",
            "type": "extra"
          },
          {
            "name": "require-directory",
            "version": "2.1.1",
            "type": "extra"
          },
          {
            "name": "resolve",
            "version": "1.22.10",
            "type": "extra"
          },
          {
            "name": "resolve-cwd",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "resolve-cwd/node_modules/resolve-from",
            "version": "5.0.0",
            "type": "extra"
          },
          {
            "name": "resolve-from",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "resolve.exports",
            "version": "2.0.3",
            "type": "extra"
          },
          {
            "name": "retry",
            "version": "0.13.1",
            "type": "extra"
          },
          {
            "name": "retry-request",
            "version": "7.0.2",
            "type": "extra"
          },
          {
            "name": "reusify",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "rimraf",
            "version": "3.0.2",
            "type": "extra"
          },
          {
            "name": "run-parallel",
            "version": "1.2.0",
            "type": "extra"
          },
          {
            "name": "rxjs",
            "version": "7.8.2",
            "type": "extra"
          },
          {
            "name": "safe-array-concat",
            "version": "1.1.3",
            "type": "extra"
          },
          {
            "name": "safe-buffer",
            "version": "5.2.1",
            "type": "extra"
          },
          {
            "name": "safe-push-apply",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "safe-regex-test",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "safer-buffer",
            "version": "2.1.2",
            "type": "extra"
          },
          {
            "name": "semver",
            "version": "6.3.1",
            "type": "extra"
          },
          {
            "name": "send",
            "version": "0.18.0",
            "type": "extra"
          },
          {
            "name": "send/node_modules/debug",
            "version": "2.6.9",
            "type": "extra"
          },
          {
            "name": "send/node_modules/debug/node_modules/ms",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "send/node_modules/mime",
            "version": "1.6.0",
            "type": "extra"
          },
          {
            "name": "serve-static",
            "version": "1.15.0",
            "type": "extra"
          },
          {
            "name": "set-function-length",
            "version": "1.2.2",
            "type": "extra"
          },
          {
            "name": "set-function-name",
            "version": "2.0.2",
            "type": "extra"
          },
          {
            "name": "set-proto",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "setprototypeof",
            "version": "1.2.0",
            "type": "extra"
          },
          {
            "name": "sha.js",
            "version": "2.4.12",
            "type": "extra"
          },
          {
            "name": "shebang-command",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "shebang-regex",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "shell-quote",
            "version": "1.8.3",
            "type": "extra"
          },
          {
            "name": "side-channel",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "side-channel-list",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "side-channel-map",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "side-channel-weakmap",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "signal-exit",
            "version": "3.0.7",
            "type": "extra"
          },
          {
            "name": "simple-update-notifier",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "simple-update-notifier/node_modules/semver",
            "version": "7.7.2",
            "type": "extra"
          },
          {
            "name": "sisteransi",
            "version": "1.0.5",
            "type": "extra"
          },
          {
            "name": "slash",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "source-map",
            "version": "0.6.1",
            "type": "extra"
          },
          {
            "name": "source-map-support",
            "version": "0.5.13",
            "type": "extra"
          },
          {
            "name": "spawn-command",
            "version": "0.0.2",
            "type": "extra"
          },
          {
            "name": "spdx-correct",
            "version": "3.2.0",
            "type": "extra"
          },
          {
            "name": "spdx-exceptions",
            "version": "2.5.0",
            "type": "extra"
          },
          {
            "name": "spdx-expression-parse",
            "version": "3.0.1",
            "type": "extra"
          },
          {
            "name": "spdx-license-ids",
            "version": "3.0.22",
            "type": "extra"
          },
          {
            "name": "split2",
            "version": "4.2.0",
            "type": "extra"
          },
          {
            "name": "sprintf-js",
            "version": "1.0.3",
            "type": "extra"
          },
          {
            "name": "stack-utils",
            "version": "2.0.6",
            "type": "extra"
          },
          {
            "name": "stack-utils/node_modules/escape-string-regexp",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "statuses",
            "version": "2.0.1",
            "type": "extra"
          },
          {
            "name": "stop-iteration-iterator",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "stream-events",
            "version": "1.0.5",
            "type": "extra"
          },
          {
            "name": "stream-shift",
            "version": "1.0.3",
            "type": "extra"
          },
          {
            "name": "streamsearch",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "string_decoder",
            "version": "1.3.0",
            "type": "extra"
          },
          {
            "name": "string-length",
            "version": "4.0.2",
            "type": "extra"
          },
          {
            "name": "string-width",
            "version": "4.2.3",
            "type": "extra"
          },
          {
            "name": "string-width-cjs",
            "version": "4.2.3",
            "type": "extra"
          },
          {
            "name": "string.prototype.padend",
            "version": "3.1.6",
            "type": "extra"
          },
          {
            "name": "string.prototype.trim",
            "version": "1.2.10",
            "type": "extra"
          },
          {
            "name": "string.prototype.trimend",
            "version": "1.0.9",
            "type": "extra"
          },
          {
            "name": "string.prototype.trimstart",
            "version": "1.0.8",
            "type": "extra"
          },
          {
            "name": "strip-ansi",
            "version": "6.0.1",
            "type": "extra"
          },
          {
            "name": "strip-ansi-cjs",
            "version": "6.0.1",
            "type": "extra"
          },
          {
            "name": "strip-bom",
            "version": "4.0.0",
            "type": "extra"
          },
          {
            "name": "strip-final-newline",
            "version": "2.0.0",
            "type": "extra"
          },
          {
            "name": "strip-json-comments",
            "version": "3.1.1",
            "type": "extra"
          },
          {
            "name": "stripe",
            "version": "16.8.0",
            "type": "extra"
          },
          {
            "name": "strnum",
            "version": "1.1.2",
            "type": "extra"
          },
          {
            "name": "stubs",
            "version": "3.0.0",
            "type": "extra"
          },
          {
            "name": "supports-color",
            "version": "8.1.1",
            "type": "extra"
          },
          {
            "name": "supports-preserve-symlinks-flag",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "teeny-request",
            "version": "9.0.0",
            "type": "extra"
          },
          {
            "name": "teeny-request/node_modules/agent-base",
            "version": "6.0.2",
            "type": "extra"
          },
          {
            "name": "teeny-request/node_modules/https-proxy-agent",
            "version": "5.0.1",
            "type": "extra"
          },
          {
            "name": "teeny-request/node_modules/uuid",
            "version": "9.0.1",
            "type": "extra"
          },
          {
            "name": "test-exclude",
            "version": "6.0.0",
            "type": "extra"
          },
          {
            "name": "text-table",
            "version": "0.2.0",
            "type": "extra"
          },
          {
            "name": "thenify",
            "version": "3.3.1",
            "type": "extra"
          },
          {
            "name": "thenify-all",
            "version": "1.6.0",
            "type": "extra"
          },
          {
            "name": "tmpl",
            "version": "1.0.5",
            "type": "extra"
          },
          {
            "name": "to-buffer",
            "version": "1.2.1",
            "type": "extra"
          },
          {
            "name": "to-regex-range",
            "version": "5.0.1",
            "type": "extra"
          },
          {
            "name": "toidentifier",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "touch",
            "version": "3.1.1",
            "type": "extra"
          },
          {
            "name": "tr46",
            "version": "0.0.3",
            "type": "extra"
          },
          {
            "name": "tree-kill",
            "version": "1.2.2",
            "type": "extra"
          },
          {
            "name": "tslib",
            "version": "2.8.1",
            "type": "extra"
          },
          {
            "name": "type-check",
            "version": "0.4.0",
            "type": "extra"
          },
          {
            "name": "type-detect",
            "version": "4.0.8",
            "type": "extra"
          },
          {
            "name": "type-fest",
            "version": "0.20.2",
            "type": "extra"
          },
          {
            "name": "type-is",
            "version": "1.6.18",
            "type": "extra"
          },
          {
            "name": "typed-array-buffer",
            "version": "1.0.3",
            "type": "extra"
          },
          {
            "name": "typed-array-byte-length",
            "version": "1.0.3",
            "type": "extra"
          },
          {
            "name": "typed-array-byte-offset",
            "version": "1.0.4",
            "type": "extra"
          },
          {
            "name": "typed-array-length",
            "version": "1.0.7",
            "type": "extra"
          },
          {
            "name": "typedarray",
            "version": "0.0.6",
            "type": "extra"
          },
          {
            "name": "typeorm",
            "version": "0.3.20",
            "type": "extra"
          },
          {
            "name": "typeorm/node_modules/brace-expansion",
            "version": "2.0.2",
            "type": "extra"
          },
          {
            "name": "typeorm/node_modules/dotenv",
            "version": "16.6.1",
            "type": "extra"
          },
          {
            "name": "typeorm/node_modules/glob",
            "version": "10.4.5",
            "type": "extra"
          },
          {
            "name": "typeorm/node_modules/minimatch",
            "version": "9.0.5",
            "type": "extra"
          },
          {
            "name": "typeorm/node_modules/uuid",
            "version": "9.0.1",
            "type": "extra"
          },
          {
            "name": "uid",
            "version": "2.0.2",
            "type": "extra"
          },
          {
            "name": "unbox-primitive",
            "version": "1.1.0",
            "type": "extra"
          },
          {
            "name": "undefsafe",
            "version": "2.0.5",
            "type": "extra"
          },
          {
            "name": "undici-types",
            "version": "5.26.5",
            "type": "extra"
          },
          {
            "name": "unpipe",
            "version": "1.0.0",
            "type": "extra"
          },
          {
            "name": "update-browserslist-db",
            "version": "1.1.3",
            "type": "extra"
          },
          {
            "name": "uri-js",
            "version": "4.4.1",
            "type": "extra"
          },
          {
            "name": "util-deprecate",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "utils-merge",
            "version": "1.0.1",
            "type": "extra"
          },
          {
            "name": "v8-to-istanbul",
            "version": "9.3.0",
            "type": "extra"
          },
          {
            "name": "validate-npm-package-license",
            "version": "3.0.4",
            "type": "extra"
          },
          {
            "name": "validator",
            "version": "13.15.15",
            "type": "extra"
          },
          {
            "name": "vary",
            "version": "1.1.2",
            "type": "extra"
          },
          {
            "name": "walker",
            "version": "1.0.8",
            "type": "extra"
          },
          {
            "name": "webidl-conversions",
            "version": "3.0.1",
            "type": "extra"
          },
          {
            "name": "websocket-driver",
            "version": "0.7.4",
            "type": "extra"
          },
          {
            "name": "websocket-extensions",
            "version": "0.1.4",
            "type": "extra"
          },
          {
            "name": "whatwg-url",
            "version": "5.0.0",
            "type": "extra"
          },
          {
            "name": "which",
            "version": "2.0.2",
            "type": "extra"
          },
          {
            "name": "which-boxed-primitive",
            "version": "1.1.1",
            "type": "extra"
          },
          {
            "name": "which-builtin-type",
            "version": "1.2.1",
            "type": "extra"
          },
          {
            "name": "which-collection",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "which-typed-array",
            "version": "1.1.19",
            "type": "extra"
          },
          {
            "name": "word-wrap",
            "version": "1.2.5",
            "type": "extra"
          },
          {
            "name": "wrap-ansi",
            "version": "7.0.0",
            "type": "extra"
          },
          {
            "name": "wrap-ansi-cjs",
            "version": "7.0.0",
            "type": "extra"
          },
          {
            "name": "wrappy",
            "version": "1.0.2",
            "type": "extra"
          },
          {
            "name": "write-file-atomic",
            "version": "4.0.2",
            "type": "extra"
          },
          {
            "name": "xtend",
            "version": "4.0.2",
            "type": "extra"
          },
          {
            "name": "y18n",
            "version": "5.0.8",
            "type": "extra"
          },
          {
            "name": "yallist",
            "version": "3.1.1",
            "type": "extra"
          },
          {
            "name": "yargs",
            "version": "17.7.2",
            "type": "extra"
          },
          {
            "name": "yargs-parser",
            "version": "21.1.1",
            "type": "extra"
          },
          {
            "name": "yocto-queue",
            "version": "0.1.0",
            "type": "extra"
          },
          {
            "name": "zod",
            "version": "3.23.8",
            "type": "extra"
          }
        ],
        "mismatched": []
      },
      "workspaces": {
        "apps/hr-api": {
          "name": "@apps/hr-api",
          "dependencyCount": 20,
          "issues": []
        },
        "apps/hr-web": {
          "name": "@apps/hr-web",
          "dependencyCount": 1,
          "issues": []
        },
        "packages/auth": {
          "name": "@platform/auth",
          "dependencyCount": 2,
          "issues": []
        },
        "packages/db": {
          "name": "@platform/db",
          "dependencyCount": 2,
          "issues": []
        },
        "packages/integrations": {
          "name": "@hunters-run/integrations",
          "dependencyCount": 7,
          "issues": []
        },
        "packages/shared": {
          "name": "@platform/shared",
          "dependencyCount": 1,
          "issues": []
        }
      },
      "summary": {
        "totalDependencies": 11,
        "issues": 879,
        "hasLockfile": true,
        "lockfileType": "npm"
      }
    },
    "config": {
      "timestamp": "2025-08-28T13:33:42.794Z",
      "environment": {
        "DATABASE_URL": {
          "key": "DATABASE_URL",
          "exists": true,
          "required": true,
          "description": "PostgreSQL connection string",
          "hasValue": true,
          "valueLength": 110,
          "status": "ok"
        },
        "DB_SSL_MODE": {
          "key": "DB_SSL_MODE",
          "exists": true,
          "required": false,
          "description": "Database SSL mode (strict/relaxed)",
          "hasValue": true,
          "valueLength": 7,
          "status": "present"
        },
        "FIREBASE_PROJECT_ID": {
          "key": "FIREBASE_PROJECT_ID",
          "exists": true,
          "required": true,
          "description": "Firebase project identifier",
          "hasValue": true,
          "valueLength": 21,
          "status": "ok"
        },
        "FIREBASE_CLIENT_EMAIL": {
          "key": "FIREBASE_CLIENT_EMAIL",
          "exists": false,
          "required": false,
          "description": "Firebase service account email",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        "FIREBASE_PRIVATE_KEY": {
          "key": "FIREBASE_PRIVATE_KEY",
          "exists": false,
          "required": false,
          "description": "Firebase service account private key",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        "FIREBASE_SERVICE_ACCOUNT_JSON": {
          "key": "FIREBASE_SERVICE_ACCOUNT_JSON",
          "exists": false,
          "required": false,
          "description": "Firebase service account JSON",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        "FIREBASE_SERVICE_ACCOUNT_PATH": {
          "key": "FIREBASE_SERVICE_ACCOUNT_PATH",
          "exists": false,
          "required": false,
          "description": "Path to Firebase service account file",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        "AWS_REGION": {
          "key": "AWS_REGION",
          "exists": false,
          "required": false,
          "description": "AWS region for S3",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        "AWS_S3_BUCKET": {
          "key": "AWS_S3_BUCKET",
          "exists": false,
          "required": false,
          "description": "S3 bucket name for file storage",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        "AWS_ACCESS_KEY_ID": {
          "key": "AWS_ACCESS_KEY_ID",
          "exists": false,
          "required": false,
          "description": "AWS access key",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        "AWS_SECRET_ACCESS_KEY": {
          "key": "AWS_SECRET_ACCESS_KEY",
          "exists": false,
          "required": false,
          "description": "AWS secret key",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        "NODE_ENV": {
          "key": "NODE_ENV",
          "exists": false,
          "required": false,
          "description": "Node environment (development/production)",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        "PORT": {
          "key": "PORT",
          "exists": false,
          "required": false,
          "description": "Server port number",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        "DEV_AUTH_BYPASS": {
          "key": "DEV_AUTH_BYPASS",
          "exists": false,
          "required": false,
          "description": "Development authentication bypass",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        "TENANT_PHOTO_FLOW_ENABLED": {
          "key": "TENANT_PHOTO_FLOW_ENABLED",
          "exists": false,
          "required": false,
          "description": "Enable tenant photo upload flow",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        }
      },
      "services": {
        "hr-api": {
          "serviceName": "hr-api",
          "status": "ok",
          "required": [
            {
              "key": "DATABASE_URL",
              "exists": true,
              "required": true,
              "description": "PostgreSQL connection string",
              "hasValue": true,
              "valueLength": 110,
              "status": "ok"
            },
            {
              "key": "FIREBASE_PROJECT_ID",
              "exists": true,
              "required": true,
              "description": "Firebase project identifier",
              "hasValue": true,
              "valueLength": 21,
              "status": "ok"
            }
          ],
          "optional": [
            {
              "key": "DB_SSL_MODE",
              "exists": true,
              "required": false,
              "description": "Database SSL mode (strict/relaxed)",
              "hasValue": true,
              "valueLength": 7,
              "status": "present"
            },
            {
              "key": "FIREBASE_SERVICE_ACCOUNT_JSON",
              "exists": false,
              "required": false,
              "description": "Firebase service account JSON",
              "hasValue": false,
              "valueLength": 0,
              "status": "not-set"
            },
            {
              "key": "FIREBASE_SERVICE_ACCOUNT_PATH",
              "exists": false,
              "required": false,
              "description": "Path to Firebase service account file",
              "hasValue": false,
              "valueLength": 0,
              "status": "not-set"
            }
          ],
          "issues": []
        },
        "hr-web": {
          "serviceName": "hr-web",
          "status": "ok",
          "required": [
            {
              "key": "FIREBASE_PROJECT_ID",
              "exists": true,
              "required": true,
              "description": "Firebase project identifier",
              "hasValue": true,
              "valueLength": 21,
              "status": "ok"
            }
          ],
          "optional": [
            {
              "key": "NODE_ENV",
              "exists": false,
              "required": false,
              "description": "Node environment (development/production)",
              "hasValue": false,
              "valueLength": 0,
              "status": "not-set"
            }
          ],
          "issues": []
        }
      },
      "summary": {
        "overallStatus": "ok",
        "totalVariables": 15,
        "requiredVariables": 2,
        "missingRequired": 0,
        "environmentVariablesSet": 3
      }
    },
    "smoke": {
      "timestamp": "2025-08-28T13:33:43.216Z",
      "framework": "npm-script",
      "tests": [
        {
          "name": "npm-test",
          "passed": false,
          "duration": 6,
          "output": ""
        }
      ],
      "summary": {
        "total": 1,
        "passed": 0,
        "failed": 1,
        "duration": 6,
        "success": false
      },
      "details": {
        "npmScript": {
          "exitCode": 1,
          "stdout": "",
          "stderr": "spawn npm ENOENT",
          "success": false,
          "error": "spawn npm ENOENT"
        }
      }
    },
    "executionStatus": {
      "success": true,
      "skipped": false
    }
  }
}
```

## Recent Status Reports (Markdown)
### status-report-2025-08-28T13-34-43-281Z.md
```markdown
# Enhanced Project Status Report
Generated: 2025-08-28T13:33:37.304Z

## API Status

- **Running**: ✅ YES
- **Health**: `{"ok":true}`

### Endpoint Availability

- **/api/health**: ✅ (200)
- **/api/work-orders**: ✅ (404)
- **/api/properties**: ✅ (400)
- **/api/test**: ✅ (200)
- **/api/test-protected**: ✅ (404)

## Project Structure

- **Source Files**: 36 TypeScript/JavaScript files
- **Controllers Folder**: ❌
- **Entities Folder**: ❌
- **Guards Folder**: ❌
- **Modules Folder**: ✅
- **Auth Scripts**: ✅
- **Dockerfile**: ✅
- **Environment File**: ✅
- **NPM Scripts**: 56 available

## Build Status

- **API Build**: ✅ OK
  

## Database

- **Connection**: ✅ OK
  | schemaname | tablename |
| --- | --- |
| audit | events |
| hr | events |
| hr | legal_notices |
| hr | notice_templates |
| hr | payment_disputes |
| hr | properties |
| hr | service_attempts |
| hr | sms_messages |
| hr | test_rls |
| hr | webhook_events |
| hr | work_order_transitions |
| hr | work_orders |
| platform | audit_events |
| platform | memberships |
| platform | organizations |
| platform | role_permissions |
| platform | roles |
| platform | user_permissions |
| platform | users |

### Database Content

- **hr.properties**: ✅ 4 records
- **hr.events**: ✅ 0 records
- **audit.events**: ✅ 2 records

### Row Level Security (RLS)

- **Status**: ❌ Not Working
- **Details**: User 'postgres' has BYPASSRLS privilege - RLS policies ignored (admin user)

## Environment Configuration

- **DATABASE_URL**: ✅ SET
- **DB_SSL_MODE**: `relaxed`
- **FIREBASE_PROJECT_ID**: ✅ SET
- **DEV_AUTH_BYPASS**: `null`

## System Verification (Selfchecks)



- **Pool Exhaustion**: ❌ ()
- **Audit Leak Prevention**: ❌ (HTTP n/a)
- **Performance Baseline**: ❌ (n/a)

### Authentication Matrix

*No authentication matrix available*

## Diagnostics v2



### Environment Runtime


- **Platform**: win32
- **Container**: ❌ No
- **Node Version**: v22.18.0
- **Memory**: 15.75GB total
- **CPU Cores**: 4


### Network Reachability


- **Targets Tested**: 5
- **Successful**: 5/5
- **Average Latency**: 194ms

- **database**: ✅ (80ms)
- **firebase-auth**: ✅ (550ms)
- **firebase-jwks**: ✅ (126ms)
- **google-dns**: ✅ (42ms)
- **github-api**: ✅ (171ms)


### Dependency Drift


- **Status**: ⚠️ 879 Issues
- **Dependencies**: 11 total
- **Lockfile**: ✅ Present (npm)



### Configuration Sanity


- **Status**: ✅ OK
- **Environment Variables**: 3/15 set
- **Missing Required**: 0


### Smoke Tests


- **Framework**: npm-script
- **Tests**: 0/1 passed
- **Duration**: 6ms
- **Status**: ❌ Failed


---
*Enhanced report generated in 7272ms*

```

### status-report-2025-08-28T01-41-13-645Z.md
```markdown
# Enhanced Project Status Report
Generated: 2025-08-28T01:40:07.712Z

## API Status

- **Running**: ✅ YES
- **Health**: `{"ok":true}`

### Endpoint Availability

- **/api/health**: ✅ (200)
- **/api/work-orders**: ✅ (404)
- **/api/properties**: ✅ (400)
- **/api/test**: ✅ (200)
- **/api/test-protected**: ✅ (404)

## Project Structure

- **Source Files**: 36 TypeScript/JavaScript files
- **Controllers Folder**: ❌
- **Entities Folder**: ❌
- **Guards Folder**: ❌
- **Modules Folder**: ✅
- **Auth Scripts**: ✅
- **Dockerfile**: ✅
- **Environment File**: ✅
- **NPM Scripts**: 56 available

## Build Status

- **API Build**: ✅ OK
  

## Database

- **Connection**: ✅ OK
  | schemaname | tablename |
| --- | --- |
| audit | events |
| hr | events |
| hr | legal_notices |
| hr | notice_templates |
| hr | payment_disputes |
| hr | properties |
| hr | service_attempts |
| hr | sms_messages |
| hr | test_rls |
| hr | webhook_events |
| hr | work_order_transitions |
| hr | work_orders |
| platform | audit_events |
| platform | memberships |
| platform | organizations |
| platform | role_permissions |
| platform | roles |
| platform | user_permissions |
| platform | users |

### Database Content

- **hr.properties**: ✅ 4 records
- **hr.events**: ✅ 0 records
- **audit.events**: ✅ 2 records

### Row Level Security (RLS)

- **Status**: ❌ Not Working
- **Details**: User 'postgres' has BYPASSRLS privilege - RLS policies ignored (admin user)

## Environment Configuration

- **DATABASE_URL**: ✅ SET
- **DB_SSL_MODE**: `relaxed`
- **FIREBASE_PROJECT_ID**: ✅ SET
- **DEV_AUTH_BYPASS**: `null`

## System Verification (Selfchecks)



- **Pool Exhaustion**: ❌ ()
- **Audit Leak Prevention**: ❌ (HTTP n/a)
- **Performance Baseline**: ❌ (n/a)

### Authentication Matrix

*No authentication matrix available*

## Diagnostics v2



### Environment Runtime


- **Platform**: win32
- **Container**: ❌ No
- **Node Version**: v22.18.0
- **Memory**: 15.75GB total
- **CPU Cores**: 4


### Network Reachability


- **Targets Tested**: 5
- **Successful**: 5/5
- **Average Latency**: 127ms

- **database**: ✅ (82ms)
- **firebase-auth**: ✅ (195ms)
- **firebase-jwks**: ✅ (106ms)
- **google-dns**: ✅ (52ms)
- **github-api**: ✅ (198ms)


### Dependency Drift


- **Status**: ⚠️ 879 Issues
- **Dependencies**: 11 total
- **Lockfile**: ✅ Present (npm)



### Configuration Sanity


- **Status**: ✅ OK
- **Environment Variables**: 3/15 set
- **Missing Required**: 0


### Smoke Tests


- **Framework**: npm-script
- **Tests**: 0/1 passed
- **Duration**: 50ms
- **Status**: ❌ Failed


---
*Enhanced report generated in 7466ms*

```

### status-report-2025-08-28T00-04-01-156Z.md
```markdown
# Enhanced Project Status Report
Generated: 2025-08-28T00:02:55.655Z

## API Status

- **Running**: ✅ YES
- **Health**: `{"ok":true}`

### Endpoint Availability

- **/api/health**: ✅ (200)
- **/api/work-orders**: ✅ (404)
- **/api/properties**: ✅ (400)
- **/api/test**: ✅ (200)
- **/api/test-protected**: ✅ (404)

## Project Structure

- **Source Files**: 36 TypeScript/JavaScript files
- **Controllers Folder**: ❌
- **Entities Folder**: ❌
- **Guards Folder**: ❌
- **Modules Folder**: ✅
- **Auth Scripts**: ✅
- **Dockerfile**: ✅
- **Environment File**: ✅
- **NPM Scripts**: 56 available

## Build Status

- **API Build**: ✅ OK
  

## Database

- **Connection**: ❌ FAILED
  *No tables found or connection failed.*

### Database Content

*Database content inspection skipped*

### Row Level Security (RLS)

- **Status**: ⚠️ Unknown
- **Details**: No RLS test performed

## Environment Configuration

- **DATABASE_URL**: ❌ NOT SET
- **DB_SSL_MODE**: `unset`
- **FIREBASE_PROJECT_ID**: ❌ NOT SET
- **DEV_AUTH_BYPASS**: `null`

## System Verification (Selfchecks)



- **Pool Exhaustion**: ❌ (no DATABASE_URL)
- **Audit Leak Prevention**: ❌ (HTTP n/a)
- **Performance Baseline**: ✅ (p95=547ms)

### Authentication Matrix

| case | status |
| --- | --- |
| 401_no_token | 404 |
| 400_no_org | 404 |
| dev_ok_or_403 | 404 |

## Diagnostics v2



### Environment Runtime


- **Platform**: win32
- **Container**: ❌ No
- **Node Version**: v22.18.0
- **Memory**: 15.75GB total
- **CPU Cores**: 4


### Network Reachability


- **Targets Tested**: 2
- **Successful**: 2/2
- **Average Latency**: 167ms

- **google-dns**: ✅ (73ms)
- **github-api**: ✅ (260ms)


### Dependency Drift


- **Status**: ⚠️ 879 Issues
- **Dependencies**: 11 total
- **Lockfile**: ✅ Present (npm)



### Configuration Sanity


- **Status**: ❌ Issues Found
- **Environment Variables**: 0/15 set
- **Missing Required**: 2


### Smoke Tests


- **Framework**: npm-script
- **Tests**: 0/1 passed
- **Duration**: 15ms
- **Status**: ❌ Failed


---
*Enhanced report generated in 6473ms*

```

## Diagnostic Artifacts (JSON) — artifacts/report
_artifacts/report not found_

## Diagnostic Artifacts (JSON) — reports/artifacts
### config-sanity.json
```json
{
  "timestamp": "2025-08-28T13:33:42.794Z",
  "environment": {
    "DATABASE_URL": {
      "key": "DATABASE_URL",
      "exists": true,
      "required": true,
      "description": "PostgreSQL connection string",
      "hasValue": true,
      "valueLength": 110,
      "status": "ok"
    },
    "DB_SSL_MODE": {
      "key": "DB_SSL_MODE",
      "exists": true,
      "required": false,
      "description": "Database SSL mode (strict/relaxed)",
      "hasValue": true,
      "valueLength": 7,
      "status": "present"
    },
    "FIREBASE_PROJECT_ID": {
      "key": "FIREBASE_PROJECT_ID",
      "exists": true,
      "required": true,
      "description": "Firebase project identifier",
      "hasValue": true,
      "valueLength": 21,
      "status": "ok"
    },
    "FIREBASE_CLIENT_EMAIL": {
      "key": "FIREBASE_CLIENT_EMAIL",
      "exists": false,
      "required": false,
      "description": "Firebase service account email",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    },
    "FIREBASE_PRIVATE_KEY": {
      "key": "FIREBASE_PRIVATE_KEY",
      "exists": false,
      "required": false,
      "description": "Firebase service account private key",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    },
    "FIREBASE_SERVICE_ACCOUNT_JSON": {
      "key": "FIREBASE_SERVICE_ACCOUNT_JSON",
      "exists": false,
      "required": false,
      "description": "Firebase service account JSON",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    },
    "FIREBASE_SERVICE_ACCOUNT_PATH": {
      "key": "FIREBASE_SERVICE_ACCOUNT_PATH",
      "exists": false,
      "required": false,
      "description": "Path to Firebase service account file",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    },
    "AWS_REGION": {
      "key": "AWS_REGION",
      "exists": false,
      "required": false,
      "description": "AWS region for S3",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    },
    "AWS_S3_BUCKET": {
      "key": "AWS_S3_BUCKET",
      "exists": false,
      "required": false,
      "description": "S3 bucket name for file storage",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    },
    "AWS_ACCESS_KEY_ID": {
      "key": "AWS_ACCESS_KEY_ID",
      "exists": false,
      "required": false,
      "description": "AWS access key",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    },
    "AWS_SECRET_ACCESS_KEY": {
      "key": "AWS_SECRET_ACCESS_KEY",
      "exists": false,
      "required": false,
      "description": "AWS secret key",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    },
    "NODE_ENV": {
      "key": "NODE_ENV",
      "exists": false,
      "required": false,
      "description": "Node environment (development/production)",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    },
    "PORT": {
      "key": "PORT",
      "exists": false,
      "required": false,
      "description": "Server port number",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    },
    "DEV_AUTH_BYPASS": {
      "key": "DEV_AUTH_BYPASS",
      "exists": false,
      "required": false,
      "description": "Development authentication bypass",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    },
    "TENANT_PHOTO_FLOW_ENABLED": {
      "key": "TENANT_PHOTO_FLOW_ENABLED",
      "exists": false,
      "required": false,
      "description": "Enable tenant photo upload flow",
      "hasValue": false,
      "valueLength": 0,
      "status": "not-set"
    }
  },
  "services": {
    "hr-api": {
      "serviceName": "hr-api",
      "status": "ok",
      "required": [
        {
          "key": "DATABASE_URL",
          "exists": true,
          "required": true,
          "description": "PostgreSQL connection string",
          "hasValue": true,
          "valueLength": 110,
          "status": "ok"
        },
        {
          "key": "FIREBASE_PROJECT_ID",
          "exists": true,
          "required": true,
          "description": "Firebase project identifier",
          "hasValue": true,
          "valueLength": 21,
          "status": "ok"
        }
      ],
      "optional": [
        {
          "key": "DB_SSL_MODE",
          "exists": true,
          "required": false,
          "description": "Database SSL mode (strict/relaxed)",
          "hasValue": true,
          "valueLength": 7,
          "status": "present"
        },
        {
          "key": "FIREBASE_SERVICE_ACCOUNT_JSON",
          "exists": false,
          "required": false,
          "description": "Firebase service account JSON",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        },
        {
          "key": "FIREBASE_SERVICE_ACCOUNT_PATH",
          "exists": false,
          "required": false,
          "description": "Path to Firebase service account file",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        }
      ],
      "issues": []
    },
    "hr-web": {
      "serviceName": "hr-web",
      "status": "ok",
      "required": [
        {
          "key": "FIREBASE_PROJECT_ID",
          "exists": true,
          "required": true,
          "description": "Firebase project identifier",
          "hasValue": true,
          "valueLength": 21,
          "status": "ok"
        }
      ],
      "optional": [
        {
          "key": "NODE_ENV",
          "exists": false,
          "required": false,
          "description": "Node environment (development/production)",
          "hasValue": false,
          "valueLength": 0,
          "status": "not-set"
        }
      ],
      "issues": []
    }
  },
  "summary": {
    "overallStatus": "ok",
    "totalVariables": 15,
    "requiredVariables": 2,
    "missingRequired": 0,
    "environmentVariablesSet": 3
  }
}
```

### dep-drift.json
```json
{
  "timestamp": "2025-08-28T13:33:42.440Z",
  "rootPackage": {
    "missing": [],
    "extra": [
      {
        "name": "@ampproject/remapping",
        "version": "2.3.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/crc32",
        "version": "5.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/crc32c",
        "version": "5.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/sha1-browser",
        "version": "5.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/sha1-browser/node_modules/@smithy/is-array-buffer",
        "version": "2.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/sha1-browser/node_modules/@smithy/util-buffer-from",
        "version": "2.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/sha1-browser/node_modules/@smithy/util-utf8",
        "version": "2.3.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/sha256-browser",
        "version": "5.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/sha256-browser/node_modules/@smithy/is-array-buffer",
        "version": "2.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/sha256-browser/node_modules/@smithy/util-buffer-from",
        "version": "2.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/sha256-browser/node_modules/@smithy/util-utf8",
        "version": "2.3.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/sha256-js",
        "version": "5.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/supports-web-crypto",
        "version": "5.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/util",
        "version": "5.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/util/node_modules/@smithy/is-array-buffer",
        "version": "2.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/util/node_modules/@smithy/util-buffer-from",
        "version": "2.2.0",
        "type": "extra"
      },
      {
        "name": "@aws-crypto/util/node_modules/@smithy/util-utf8",
        "version": "2.3.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/client-s3",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/client-sso",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/client-sso-oidc",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/client-sts",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/core",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/credential-provider-env",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/credential-provider-http",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/credential-provider-ini",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/credential-provider-node",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/credential-provider-process",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/credential-provider-sso",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/credential-provider-web-identity",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/middleware-bucket-endpoint",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/middleware-expect-continue",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/middleware-flexible-checksums",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/middleware-host-header",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/middleware-location-constraint",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/middleware-logger",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/middleware-recursion-detection",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/middleware-sdk-s3",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/middleware-signing",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/middleware-ssec",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/middleware-user-agent",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/region-config-resolver",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/s3-request-presigner",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/signature-v4-multi-region",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/token-providers",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/types",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/util-arn-parser",
        "version": "3.568.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/util-endpoints",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/util-format-url",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/util-locate-window",
        "version": "3.873.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/util-user-agent-browser",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/util-user-agent-node",
        "version": "3.614.0",
        "type": "extra"
      },
      {
        "name": "@aws-sdk/xml-builder",
        "version": "3.609.0",
        "type": "extra"
      },
      {
        "name": "@babel/code-frame",
        "version": "7.27.1",
        "type": "extra"
      },
      {
        "name": "@babel/compat-data",
        "version": "7.28.0",
        "type": "extra"
      },
      {
        "name": "@babel/core",
        "version": "7.28.3",
        "type": "extra"
      },
      {
        "name": "@babel/generator",
        "version": "7.28.3",
        "type": "extra"
      },
      {
        "name": "@babel/helper-compilation-targets",
        "version": "7.27.2",
        "type": "extra"
      },
      {
        "name": "@babel/helper-globals",
        "version": "7.28.0",
        "type": "extra"
      },
      {
        "name": "@babel/helper-module-imports",
        "version": "7.27.1",
        "type": "extra"
      },
      {
        "name": "@babel/helper-module-transforms",
        "version": "7.28.3",
        "type": "extra"
      },
      {
        "name": "@babel/helper-plugin-utils",
        "version": "7.27.1",
        "type": "extra"
      },
      {
        "name": "@babel/helper-string-parser",
        "version": "7.27.1",
        "type": "extra"
      },
      {
        "name": "@babel/helper-validator-identifier",
        "version": "7.27.1",
        "type": "extra"
      },
      {
        "name": "@babel/helper-validator-option",
        "version": "7.27.1",
        "type": "extra"
      },
      {
        "name": "@babel/helpers",
        "version": "7.28.3",
        "type": "extra"
      },
      {
        "name": "@babel/parser",
        "version": "7.28.3",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-async-generators",
        "version": "7.8.4",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-bigint",
        "version": "7.8.3",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-class-properties",
        "version": "7.12.13",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-class-static-block",
        "version": "7.14.5",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-import-attributes",
        "version": "7.27.1",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-import-meta",
        "version": "7.10.4",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-json-strings",
        "version": "7.8.3",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-jsx",
        "version": "7.27.1",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-logical-assignment-operators",
        "version": "7.10.4",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-nullish-coalescing-operator",
        "version": "7.8.3",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-numeric-separator",
        "version": "7.10.4",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-object-rest-spread",
        "version": "7.8.3",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-optional-catch-binding",
        "version": "7.8.3",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-optional-chaining",
        "version": "7.8.3",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-private-property-in-object",
        "version": "7.14.5",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-top-level-await",
        "version": "7.14.5",
        "type": "extra"
      },
      {
        "name": "@babel/plugin-syntax-typescript",
        "version": "7.27.1",
        "type": "extra"
      },
      {
        "name": "@babel/runtime",
        "version": "7.28.3",
        "type": "extra"
      },
      {
        "name": "@babel/template",
        "version": "7.27.2",
        "type": "extra"
      },
      {
        "name": "@babel/traverse",
        "version": "7.28.3",
        "type": "extra"
      },
      {
        "name": "@babel/types",
        "version": "7.28.2",
        "type": "extra"
      },
      {
        "name": "@bcoe/v8-coverage",
        "version": "0.2.3",
        "type": "extra"
      },
      {
        "name": "@eslint-community/eslint-utils",
        "version": "4.7.0",
        "type": "extra"
      },
      {
        "name": "@eslint-community/regexpp",
        "version": "4.12.1",
        "type": "extra"
      },
      {
        "name": "@eslint/eslintrc",
        "version": "2.1.4",
        "type": "extra"
      },
      {
        "name": "@eslint/js",
        "version": "8.57.0",
        "type": "extra"
      },
      {
        "name": "@fastify/busboy",
        "version": "3.2.0",
        "type": "extra"
      },
      {
        "name": "@firebase/app-check-interop-types",
        "version": "0.3.2",
        "type": "extra"
      },
      {
        "name": "@firebase/app-types",
        "version": "0.9.3",
        "type": "extra"
      },
      {
        "name": "@firebase/auth-interop-types",
        "version": "0.2.3",
        "type": "extra"
      },
      {
        "name": "@firebase/component",
        "version": "0.6.10",
        "type": "extra"
      },
      {
        "name": "@firebase/database",
        "version": "1.0.9",
        "type": "extra"
      },
      {
        "name": "@firebase/database-compat",
        "version": "1.0.10",
        "type": "extra"
      },
      {
        "name": "@firebase/database-compat/node_modules/@firebase/app-types",
        "version": "0.9.2",
        "type": "extra"
      },
      {
        "name": "@firebase/database-compat/node_modules/@firebase/database-types",
        "version": "1.0.6",
        "type": "extra"
      },
      {
        "name": "@firebase/database-types",
        "version": "1.0.16",
        "type": "extra"
      },
      {
        "name": "@firebase/database-types/node_modules/@firebase/util",
        "version": "1.13.0",
        "type": "extra"
      },
      {
        "name": "@firebase/logger",
        "version": "0.4.3",
        "type": "extra"
      },
      {
        "name": "@firebase/util",
        "version": "1.10.1",
        "type": "extra"
      },
      {
        "name": "@google-cloud/firestore",
        "version": "7.11.3",
        "type": "extra"
      },
      {
        "name": "@google-cloud/paginator",
        "version": "5.0.2",
        "type": "extra"
      },
      {
        "name": "@google-cloud/projectify",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "@google-cloud/promisify",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "@google-cloud/storage",
        "version": "7.17.0",
        "type": "extra"
      },
      {
        "name": "@google-cloud/storage/node_modules/fast-xml-parser",
        "version": "4.5.3",
        "type": "extra"
      },
      {
        "name": "@google-cloud/storage/node_modules/uuid",
        "version": "8.3.2",
        "type": "extra"
      },
      {
        "name": "@grpc/grpc-js",
        "version": "1.13.4",
        "type": "extra"
      },
      {
        "name": "@grpc/proto-loader",
        "version": "0.7.15",
        "type": "extra"
      },
      {
        "name": "@humanwhocodes/config-array",
        "version": "0.11.14",
        "type": "extra"
      },
      {
        "name": "@humanwhocodes/module-importer",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "@humanwhocodes/object-schema",
        "version": "2.0.3",
        "type": "extra"
      },
      {
        "name": "@isaacs/cliui",
        "version": "8.0.2",
        "type": "extra"
      },
      {
        "name": "@isaacs/cliui/node_modules/ansi-regex",
        "version": "6.2.0",
        "type": "extra"
      },
      {
        "name": "@isaacs/cliui/node_modules/ansi-styles",
        "version": "6.2.1",
        "type": "extra"
      },
      {
        "name": "@isaacs/cliui/node_modules/emoji-regex",
        "version": "9.2.2",
        "type": "extra"
      },
      {
        "name": "@isaacs/cliui/node_modules/string-width",
        "version": "5.1.2",
        "type": "extra"
      },
      {
        "name": "@isaacs/cliui/node_modules/strip-ansi",
        "version": "7.1.0",
        "type": "extra"
      },
      {
        "name": "@isaacs/cliui/node_modules/wrap-ansi",
        "version": "8.1.0",
        "type": "extra"
      },
      {
        "name": "@istanbuljs/load-nyc-config",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "@istanbuljs/load-nyc-config/node_modules/argparse",
        "version": "1.0.10",
        "type": "extra"
      },
      {
        "name": "@istanbuljs/load-nyc-config/node_modules/find-up",
        "version": "4.1.0",
        "type": "extra"
      },
      {
        "name": "@istanbuljs/load-nyc-config/node_modules/js-yaml",
        "version": "3.14.1",
        "type": "extra"
      },
      {
        "name": "@istanbuljs/load-nyc-config/node_modules/locate-path",
        "version": "5.0.0",
        "type": "extra"
      },
      {
        "name": "@istanbuljs/load-nyc-config/node_modules/p-limit",
        "version": "2.3.0",
        "type": "extra"
      },
      {
        "name": "@istanbuljs/load-nyc-config/node_modules/p-locate",
        "version": "4.1.0",
        "type": "extra"
      },
      {
        "name": "@istanbuljs/load-nyc-config/node_modules/resolve-from",
        "version": "5.0.0",
        "type": "extra"
      },
      {
        "name": "@istanbuljs/schema",
        "version": "0.1.3",
        "type": "extra"
      },
      {
        "name": "@jest/console",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "@jest/core",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "@jest/environment",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "@jest/expect",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "@jest/expect-utils",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "@jest/fake-timers",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "@jest/globals",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "@jest/reporters",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "@jest/schemas",
        "version": "29.6.3",
        "type": "extra"
      },
      {
        "name": "@jest/source-map",
        "version": "29.6.3",
        "type": "extra"
      },
      {
        "name": "@jest/test-result",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "@jest/test-sequencer",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "@jest/transform",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "@jest/types",
        "version": "29.6.3",
        "type": "extra"
      },
      {
        "name": "@jridgewell/gen-mapping",
        "version": "0.3.13",
        "type": "extra"
      },
      {
        "name": "@jridgewell/resolve-uri",
        "version": "3.1.2",
        "type": "extra"
      },
      {
        "name": "@jridgewell/sourcemap-codec",
        "version": "1.5.5",
        "type": "extra"
      },
      {
        "name": "@jridgewell/trace-mapping",
        "version": "0.3.30",
        "type": "extra"
      },
      {
        "name": "@js-sdsl/ordered-map",
        "version": "4.4.2",
        "type": "extra"
      },
      {
        "name": "@lukeed/csprng",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "@nestjs/common",
        "version": "10.3.0",
        "type": "extra"
      },
      {
        "name": "@nestjs/common/node_modules/tslib",
        "version": "2.6.2",
        "type": "extra"
      },
      {
        "name": "@nestjs/core",
        "version": "10.4.20",
        "type": "extra"
      },
      {
        "name": "@nestjs/core/node_modules/path-to-regexp",
        "version": "3.3.0",
        "type": "extra"
      },
      {
        "name": "@nestjs/platform-express",
        "version": "10.3.0",
        "type": "extra"
      },
      {
        "name": "@nestjs/platform-express/node_modules/tslib",
        "version": "2.6.2",
        "type": "extra"
      },
      {
        "name": "@nodelib/fs.scandir",
        "version": "2.1.5",
        "type": "extra"
      },
      {
        "name": "@nodelib/fs.stat",
        "version": "2.0.5",
        "type": "extra"
      },
      {
        "name": "@nodelib/fs.walk",
        "version": "1.2.8",
        "type": "extra"
      },
      {
        "name": "@nuxtjs/opencollective",
        "version": "0.3.2",
        "type": "extra"
      },
      {
        "name": "@opentelemetry/api",
        "version": "1.9.0",
        "type": "extra"
      },
      {
        "name": "@pkgjs/parseargs",
        "version": "0.11.0",
        "type": "extra"
      },
      {
        "name": "@protobufjs/aspromise",
        "version": "1.1.2",
        "type": "extra"
      },
      {
        "name": "@protobufjs/base64",
        "version": "1.1.2",
        "type": "extra"
      },
      {
        "name": "@protobufjs/codegen",
        "version": "2.0.4",
        "type": "extra"
      },
      {
        "name": "@protobufjs/eventemitter",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "@protobufjs/fetch",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "@protobufjs/float",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "@protobufjs/inquire",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "@protobufjs/path",
        "version": "1.1.2",
        "type": "extra"
      },
      {
        "name": "@protobufjs/pool",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "@protobufjs/utf8",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "@sendgrid/client",
        "version": "8.1.5",
        "type": "extra"
      },
      {
        "name": "@sendgrid/client/node_modules/axios",
        "version": "1.11.0",
        "type": "extra"
      },
      {
        "name": "@sendgrid/helpers",
        "version": "8.0.0",
        "type": "extra"
      },
      {
        "name": "@sendgrid/mail",
        "version": "8.1.3",
        "type": "extra"
      },
      {
        "name": "@sinclair/typebox",
        "version": "0.27.8",
        "type": "extra"
      },
      {
        "name": "@sinonjs/commons",
        "version": "3.0.1",
        "type": "extra"
      },
      {
        "name": "@sinonjs/fake-timers",
        "version": "10.3.0",
        "type": "extra"
      },
      {
        "name": "@smithy/abort-controller",
        "version": "3.1.9",
        "type": "extra"
      },
      {
        "name": "@smithy/chunked-blob-reader",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "@smithy/chunked-blob-reader-native",
        "version": "3.0.1",
        "type": "extra"
      },
      {
        "name": "@smithy/config-resolver",
        "version": "3.0.13",
        "type": "extra"
      },
      {
        "name": "@smithy/core",
        "version": "2.5.7",
        "type": "extra"
      },
      {
        "name": "@smithy/credential-provider-imds",
        "version": "3.2.8",
        "type": "extra"
      },
      {
        "name": "@smithy/eventstream-codec",
        "version": "3.1.10",
        "type": "extra"
      },
      {
        "name": "@smithy/eventstream-serde-browser",
        "version": "3.0.14",
        "type": "extra"
      },
      {
        "name": "@smithy/eventstream-serde-config-resolver",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/eventstream-serde-node",
        "version": "3.0.13",
        "type": "extra"
      },
      {
        "name": "@smithy/eventstream-serde-universal",
        "version": "3.0.13",
        "type": "extra"
      },
      {
        "name": "@smithy/fetch-http-handler",
        "version": "3.2.9",
        "type": "extra"
      },
      {
        "name": "@smithy/hash-blob-browser",
        "version": "3.1.10",
        "type": "extra"
      },
      {
        "name": "@smithy/hash-node",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/hash-stream-node",
        "version": "3.1.10",
        "type": "extra"
      },
      {
        "name": "@smithy/invalid-dependency",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/is-array-buffer",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "@smithy/md5-js",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/middleware-content-length",
        "version": "3.0.13",
        "type": "extra"
      },
      {
        "name": "@smithy/middleware-endpoint",
        "version": "3.2.8",
        "type": "extra"
      },
      {
        "name": "@smithy/middleware-retry",
        "version": "3.0.34",
        "type": "extra"
      },
      {
        "name": "@smithy/middleware-retry/node_modules/uuid",
        "version": "9.0.1",
        "type": "extra"
      },
      {
        "name": "@smithy/middleware-serde",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/middleware-stack",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/node-config-provider",
        "version": "3.1.12",
        "type": "extra"
      },
      {
        "name": "@smithy/node-http-handler",
        "version": "3.3.3",
        "type": "extra"
      },
      {
        "name": "@smithy/property-provider",
        "version": "3.1.11",
        "type": "extra"
      },
      {
        "name": "@smithy/protocol-http",
        "version": "4.1.8",
        "type": "extra"
      },
      {
        "name": "@smithy/querystring-builder",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/querystring-parser",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/service-error-classification",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/shared-ini-file-loader",
        "version": "3.1.12",
        "type": "extra"
      },
      {
        "name": "@smithy/signature-v4",
        "version": "3.1.2",
        "type": "extra"
      },
      {
        "name": "@smithy/smithy-client",
        "version": "3.7.0",
        "type": "extra"
      },
      {
        "name": "@smithy/types",
        "version": "3.7.2",
        "type": "extra"
      },
      {
        "name": "@smithy/url-parser",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/util-base64",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "@smithy/util-body-length-browser",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "@smithy/util-body-length-node",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "@smithy/util-buffer-from",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "@smithy/util-config-provider",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "@smithy/util-defaults-mode-browser",
        "version": "3.0.34",
        "type": "extra"
      },
      {
        "name": "@smithy/util-defaults-mode-node",
        "version": "3.0.34",
        "type": "extra"
      },
      {
        "name": "@smithy/util-endpoints",
        "version": "2.1.7",
        "type": "extra"
      },
      {
        "name": "@smithy/util-hex-encoding",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "@smithy/util-middleware",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/util-retry",
        "version": "3.0.11",
        "type": "extra"
      },
      {
        "name": "@smithy/util-stream",
        "version": "3.3.4",
        "type": "extra"
      },
      {
        "name": "@smithy/util-stream/node_modules/@smithy/fetch-http-handler",
        "version": "4.1.3",
        "type": "extra"
      },
      {
        "name": "@smithy/util-uri-escape",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "@smithy/util-utf8",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "@smithy/util-waiter",
        "version": "3.2.0",
        "type": "extra"
      },
      {
        "name": "@sqltools/formatter",
        "version": "1.2.5",
        "type": "extra"
      },
      {
        "name": "@tootallnate/once",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "@types/babel__core",
        "version": "7.20.5",
        "type": "extra"
      },
      {
        "name": "@types/babel__generator",
        "version": "7.27.0",
        "type": "extra"
      },
      {
        "name": "@types/babel__template",
        "version": "7.4.4",
        "type": "extra"
      },
      {
        "name": "@types/babel__traverse",
        "version": "7.28.0",
        "type": "extra"
      },
      {
        "name": "@types/body-parser",
        "version": "1.19.6",
        "type": "extra"
      },
      {
        "name": "@types/caseless",
        "version": "0.12.5",
        "type": "extra"
      },
      {
        "name": "@types/connect",
        "version": "3.4.38",
        "type": "extra"
      },
      {
        "name": "@types/express",
        "version": "4.17.23",
        "type": "extra"
      },
      {
        "name": "@types/express-serve-static-core",
        "version": "4.19.6",
        "type": "extra"
      },
      {
        "name": "@types/graceful-fs",
        "version": "4.1.9",
        "type": "extra"
      },
      {
        "name": "@types/http-errors",
        "version": "2.0.5",
        "type": "extra"
      },
      {
        "name": "@types/istanbul-lib-coverage",
        "version": "2.0.6",
        "type": "extra"
      },
      {
        "name": "@types/istanbul-lib-report",
        "version": "3.0.3",
        "type": "extra"
      },
      {
        "name": "@types/istanbul-reports",
        "version": "3.0.4",
        "type": "extra"
      },
      {
        "name": "@types/jsonwebtoken",
        "version": "9.0.10",
        "type": "extra"
      },
      {
        "name": "@types/long",
        "version": "4.0.2",
        "type": "extra"
      },
      {
        "name": "@types/mime",
        "version": "1.3.5",
        "type": "extra"
      },
      {
        "name": "@types/ms",
        "version": "2.1.0",
        "type": "extra"
      },
      {
        "name": "@types/node",
        "version": "20.12.12",
        "type": "extra"
      },
      {
        "name": "@types/pg",
        "version": "8.15.5",
        "type": "extra"
      },
      {
        "name": "@types/qs",
        "version": "6.14.0",
        "type": "extra"
      },
      {
        "name": "@types/range-parser",
        "version": "1.2.7",
        "type": "extra"
      },
      {
        "name": "@types/request",
        "version": "2.48.13",
        "type": "extra"
      },
      {
        "name": "@types/request/node_modules/form-data",
        "version": "2.5.5",
        "type": "extra"
      },
      {
        "name": "@types/send",
        "version": "0.17.5",
        "type": "extra"
      },
      {
        "name": "@types/serve-static",
        "version": "1.15.8",
        "type": "extra"
      },
      {
        "name": "@types/stack-utils",
        "version": "2.0.3",
        "type": "extra"
      },
      {
        "name": "@types/tough-cookie",
        "version": "4.0.5",
        "type": "extra"
      },
      {
        "name": "@types/validator",
        "version": "13.15.2",
        "type": "extra"
      },
      {
        "name": "@types/yargs",
        "version": "17.0.33",
        "type": "extra"
      },
      {
        "name": "@types/yargs-parser",
        "version": "21.0.3",
        "type": "extra"
      },
      {
        "name": "@ungap/structured-clone",
        "version": "1.3.0",
        "type": "extra"
      },
      {
        "name": "abort-controller",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "accepts",
        "version": "1.3.8",
        "type": "extra"
      },
      {
        "name": "acorn",
        "version": "8.15.0",
        "type": "extra"
      },
      {
        "name": "acorn-jsx",
        "version": "5.3.2",
        "type": "extra"
      },
      {
        "name": "agent-base",
        "version": "7.1.4",
        "type": "extra"
      },
      {
        "name": "ajv",
        "version": "6.12.6",
        "type": "extra"
      },
      {
        "name": "ansi-escapes",
        "version": "4.3.2",
        "type": "extra"
      },
      {
        "name": "ansi-escapes/node_modules/type-fest",
        "version": "0.21.3",
        "type": "extra"
      },
      {
        "name": "ansi-regex",
        "version": "5.0.1",
        "type": "extra"
      },
      {
        "name": "ansi-styles",
        "version": "4.3.0",
        "type": "extra"
      },
      {
        "name": "any-promise",
        "version": "1.3.0",
        "type": "extra"
      },
      {
        "name": "anymatch",
        "version": "3.1.3",
        "type": "extra"
      },
      {
        "name": "app-root-path",
        "version": "3.1.0",
        "type": "extra"
      },
      {
        "name": "append-field",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "argparse",
        "version": "2.0.1",
        "type": "extra"
      },
      {
        "name": "array-buffer-byte-length",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "array-flatten",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "arraybuffer.prototype.slice",
        "version": "1.0.4",
        "type": "extra"
      },
      {
        "name": "arrify",
        "version": "2.0.1",
        "type": "extra"
      },
      {
        "name": "async-function",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "async-retry",
        "version": "1.3.3",
        "type": "extra"
      },
      {
        "name": "asynckit",
        "version": "0.4.0",
        "type": "extra"
      },
      {
        "name": "available-typed-arrays",
        "version": "1.0.7",
        "type": "extra"
      },
      {
        "name": "axios",
        "version": "1.7.4",
        "type": "extra"
      },
      {
        "name": "babel-jest",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "babel-plugin-istanbul",
        "version": "6.1.1",
        "type": "extra"
      },
      {
        "name": "babel-plugin-istanbul/node_modules/istanbul-lib-instrument",
        "version": "5.2.1",
        "type": "extra"
      },
      {
        "name": "babel-plugin-jest-hoist",
        "version": "29.6.3",
        "type": "extra"
      },
      {
        "name": "babel-preset-current-node-syntax",
        "version": "1.2.0",
        "type": "extra"
      },
      {
        "name": "babel-preset-jest",
        "version": "29.6.3",
        "type": "extra"
      },
      {
        "name": "balanced-match",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "base64-js",
        "version": "1.5.1",
        "type": "extra"
      },
      {
        "name": "bignumber.js",
        "version": "9.3.1",
        "type": "extra"
      },
      {
        "name": "binary-extensions",
        "version": "2.3.0",
        "type": "extra"
      },
      {
        "name": "body-parser",
        "version": "1.20.2",
        "type": "extra"
      },
      {
        "name": "body-parser/node_modules/debug",
        "version": "2.6.9",
        "type": "extra"
      },
      {
        "name": "body-parser/node_modules/ms",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "body-parser/node_modules/qs",
        "version": "6.11.0",
        "type": "extra"
      },
      {
        "name": "bowser",
        "version": "2.12.1",
        "type": "extra"
      },
      {
        "name": "brace-expansion",
        "version": "1.1.12",
        "type": "extra"
      },
      {
        "name": "braces",
        "version": "3.0.3",
        "type": "extra"
      },
      {
        "name": "browserslist",
        "version": "4.25.3",
        "type": "extra"
      },
      {
        "name": "bser",
        "version": "2.1.1",
        "type": "extra"
      },
      {
        "name": "buffer",
        "version": "6.0.3",
        "type": "extra"
      },
      {
        "name": "buffer-equal-constant-time",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "buffer-from",
        "version": "1.1.2",
        "type": "extra"
      },
      {
        "name": "busboy",
        "version": "1.6.0",
        "type": "extra"
      },
      {
        "name": "bytes",
        "version": "3.1.2",
        "type": "extra"
      },
      {
        "name": "call-bind",
        "version": "1.0.8",
        "type": "extra"
      },
      {
        "name": "call-bind-apply-helpers",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "call-bound",
        "version": "1.0.4",
        "type": "extra"
      },
      {
        "name": "callsites",
        "version": "3.1.0",
        "type": "extra"
      },
      {
        "name": "camelcase",
        "version": "5.3.1",
        "type": "extra"
      },
      {
        "name": "caniuse-lite",
        "version": "1.0.30001737",
        "type": "extra"
      },
      {
        "name": "chalk",
        "version": "4.1.2",
        "type": "extra"
      },
      {
        "name": "chalk/node_modules/supports-color",
        "version": "7.2.0",
        "type": "extra"
      },
      {
        "name": "char-regex",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "chokidar",
        "version": "3.6.0",
        "type": "extra"
      },
      {
        "name": "chokidar/node_modules/glob-parent",
        "version": "5.1.2",
        "type": "extra"
      },
      {
        "name": "ci-info",
        "version": "3.9.0",
        "type": "extra"
      },
      {
        "name": "cjs-module-lexer",
        "version": "1.4.3",
        "type": "extra"
      },
      {
        "name": "class-transformer",
        "version": "0.5.1",
        "type": "extra"
      },
      {
        "name": "class-validator",
        "version": "0.14.2",
        "type": "extra"
      },
      {
        "name": "cli-highlight",
        "version": "2.1.11",
        "type": "extra"
      },
      {
        "name": "cli-highlight/node_modules/cliui",
        "version": "7.0.4",
        "type": "extra"
      },
      {
        "name": "cli-highlight/node_modules/yargs",
        "version": "16.2.0",
        "type": "extra"
      },
      {
        "name": "cli-highlight/node_modules/yargs-parser",
        "version": "20.2.9",
        "type": "extra"
      },
      {
        "name": "cliui",
        "version": "8.0.1",
        "type": "extra"
      },
      {
        "name": "co",
        "version": "4.6.0",
        "type": "extra"
      },
      {
        "name": "collect-v8-coverage",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "color-convert",
        "version": "2.0.1",
        "type": "extra"
      },
      {
        "name": "color-name",
        "version": "1.1.4",
        "type": "extra"
      },
      {
        "name": "combined-stream",
        "version": "1.0.8",
        "type": "extra"
      },
      {
        "name": "concat-map",
        "version": "0.0.1",
        "type": "extra"
      },
      {
        "name": "concat-stream",
        "version": "1.6.2",
        "type": "extra"
      },
      {
        "name": "concat-stream/node_modules/isarray",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "concat-stream/node_modules/readable-stream",
        "version": "2.3.8",
        "type": "extra"
      },
      {
        "name": "concat-stream/node_modules/safe-buffer",
        "version": "5.1.2",
        "type": "extra"
      },
      {
        "name": "concat-stream/node_modules/string_decoder",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "consola",
        "version": "2.15.3",
        "type": "extra"
      },
      {
        "name": "content-disposition",
        "version": "0.5.4",
        "type": "extra"
      },
      {
        "name": "content-type",
        "version": "1.0.5",
        "type": "extra"
      },
      {
        "name": "convert-source-map",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "cookie",
        "version": "0.5.0",
        "type": "extra"
      },
      {
        "name": "cookie-signature",
        "version": "1.0.6",
        "type": "extra"
      },
      {
        "name": "core-util-is",
        "version": "1.0.3",
        "type": "extra"
      },
      {
        "name": "cors",
        "version": "2.8.5",
        "type": "extra"
      },
      {
        "name": "create-jest",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "cross-spawn",
        "version": "7.0.6",
        "type": "extra"
      },
      {
        "name": "data-view-buffer",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "data-view-byte-length",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "data-view-byte-offset",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "date-fns",
        "version": "2.30.0",
        "type": "extra"
      },
      {
        "name": "dayjs",
        "version": "1.11.13",
        "type": "extra"
      },
      {
        "name": "debug",
        "version": "4.4.1",
        "type": "extra"
      },
      {
        "name": "dedent",
        "version": "1.6.0",
        "type": "extra"
      },
      {
        "name": "deep-is",
        "version": "0.1.4",
        "type": "extra"
      },
      {
        "name": "deepmerge",
        "version": "4.3.1",
        "type": "extra"
      },
      {
        "name": "define-data-property",
        "version": "1.1.4",
        "type": "extra"
      },
      {
        "name": "define-properties",
        "version": "1.2.1",
        "type": "extra"
      },
      {
        "name": "delayed-stream",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "depd",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "destroy",
        "version": "1.2.0",
        "type": "extra"
      },
      {
        "name": "detect-newline",
        "version": "3.1.0",
        "type": "extra"
      },
      {
        "name": "diff-sequences",
        "version": "29.6.3",
        "type": "extra"
      },
      {
        "name": "doctrine",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "dunder-proto",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "duplexify",
        "version": "4.1.3",
        "type": "extra"
      },
      {
        "name": "eastasianwidth",
        "version": "0.2.0",
        "type": "extra"
      },
      {
        "name": "ecdsa-sig-formatter",
        "version": "1.0.11",
        "type": "extra"
      },
      {
        "name": "ee-first",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "electron-to-chromium",
        "version": "1.5.208",
        "type": "extra"
      },
      {
        "name": "emittery",
        "version": "0.13.1",
        "type": "extra"
      },
      {
        "name": "emoji-regex",
        "version": "8.0.0",
        "type": "extra"
      },
      {
        "name": "encodeurl",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "end-of-stream",
        "version": "1.4.5",
        "type": "extra"
      },
      {
        "name": "error-ex",
        "version": "1.3.2",
        "type": "extra"
      },
      {
        "name": "es-abstract",
        "version": "1.24.0",
        "type": "extra"
      },
      {
        "name": "es-define-property",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "es-errors",
        "version": "1.3.0",
        "type": "extra"
      },
      {
        "name": "es-object-atoms",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "es-set-tostringtag",
        "version": "2.1.0",
        "type": "extra"
      },
      {
        "name": "es-to-primitive",
        "version": "1.3.0",
        "type": "extra"
      },
      {
        "name": "escalade",
        "version": "3.2.0",
        "type": "extra"
      },
      {
        "name": "escape-html",
        "version": "1.0.3",
        "type": "extra"
      },
      {
        "name": "escape-string-regexp",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "eslint-import-resolver-node",
        "version": "0.3.9",
        "type": "extra"
      },
      {
        "name": "eslint-import-resolver-node/node_modules/debug",
        "version": "3.2.7",
        "type": "extra"
      },
      {
        "name": "eslint-module-utils",
        "version": "2.12.0",
        "type": "extra"
      },
      {
        "name": "eslint-module-utils/node_modules/debug",
        "version": "3.2.7",
        "type": "extra"
      },
      {
        "name": "eslint-scope",
        "version": "7.2.2",
        "type": "extra"
      },
      {
        "name": "eslint-visitor-keys",
        "version": "3.4.3",
        "type": "extra"
      },
      {
        "name": "espree",
        "version": "9.6.1",
        "type": "extra"
      },
      {
        "name": "esprima",
        "version": "4.0.1",
        "type": "extra"
      },
      {
        "name": "esquery",
        "version": "1.6.0",
        "type": "extra"
      },
      {
        "name": "esrecurse",
        "version": "4.3.0",
        "type": "extra"
      },
      {
        "name": "estraverse",
        "version": "5.3.0",
        "type": "extra"
      },
      {
        "name": "esutils",
        "version": "2.0.3",
        "type": "extra"
      },
      {
        "name": "etag",
        "version": "1.8.1",
        "type": "extra"
      },
      {
        "name": "event-target-shim",
        "version": "5.0.1",
        "type": "extra"
      },
      {
        "name": "execa",
        "version": "5.1.1",
        "type": "extra"
      },
      {
        "name": "exit",
        "version": "0.1.2",
        "type": "extra"
      },
      {
        "name": "expect",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "express",
        "version": "4.18.2",
        "type": "extra"
      },
      {
        "name": "express/node_modules/body-parser",
        "version": "1.20.1",
        "type": "extra"
      },
      {
        "name": "express/node_modules/debug",
        "version": "2.6.9",
        "type": "extra"
      },
      {
        "name": "express/node_modules/ms",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "express/node_modules/qs",
        "version": "6.11.0",
        "type": "extra"
      },
      {
        "name": "express/node_modules/raw-body",
        "version": "2.5.1",
        "type": "extra"
      },
      {
        "name": "extend",
        "version": "3.0.2",
        "type": "extra"
      },
      {
        "name": "farmhash-modern",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "fast-deep-equal",
        "version": "3.1.3",
        "type": "extra"
      },
      {
        "name": "fast-json-stable-stringify",
        "version": "2.1.0",
        "type": "extra"
      },
      {
        "name": "fast-levenshtein",
        "version": "2.0.6",
        "type": "extra"
      },
      {
        "name": "fast-safe-stringify",
        "version": "2.1.1",
        "type": "extra"
      },
      {
        "name": "fast-xml-parser",
        "version": "4.2.5",
        "type": "extra"
      },
      {
        "name": "fastq",
        "version": "1.19.1",
        "type": "extra"
      },
      {
        "name": "faye-websocket",
        "version": "0.11.4",
        "type": "extra"
      },
      {
        "name": "fb-watchman",
        "version": "2.0.2",
        "type": "extra"
      },
      {
        "name": "file-entry-cache",
        "version": "6.0.1",
        "type": "extra"
      },
      {
        "name": "fill-range",
        "version": "7.1.1",
        "type": "extra"
      },
      {
        "name": "finalhandler",
        "version": "1.2.0",
        "type": "extra"
      },
      {
        "name": "finalhandler/node_modules/debug",
        "version": "2.6.9",
        "type": "extra"
      },
      {
        "name": "finalhandler/node_modules/ms",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "find-up",
        "version": "5.0.0",
        "type": "extra"
      },
      {
        "name": "firebase-admin",
        "version": "12.3.1",
        "type": "extra"
      },
      {
        "name": "firebase-admin/node_modules/@types/node",
        "version": "22.18.0",
        "type": "extra"
      },
      {
        "name": "firebase-admin/node_modules/undici-types",
        "version": "6.21.0",
        "type": "extra"
      },
      {
        "name": "firebase-admin/node_modules/uuid",
        "version": "10.0.0",
        "type": "extra"
      },
      {
        "name": "flat-cache",
        "version": "3.2.0",
        "type": "extra"
      },
      {
        "name": "flatted",
        "version": "3.3.3",
        "type": "extra"
      },
      {
        "name": "follow-redirects",
        "version": "1.15.11",
        "type": "extra"
      },
      {
        "name": "for-each",
        "version": "0.3.5",
        "type": "extra"
      },
      {
        "name": "foreground-child",
        "version": "3.3.1",
        "type": "extra"
      },
      {
        "name": "foreground-child/node_modules/signal-exit",
        "version": "4.1.0",
        "type": "extra"
      },
      {
        "name": "form-data",
        "version": "4.0.4",
        "type": "extra"
      },
      {
        "name": "forwarded",
        "version": "0.2.0",
        "type": "extra"
      },
      {
        "name": "fresh",
        "version": "0.5.2",
        "type": "extra"
      },
      {
        "name": "fs.realpath",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "fsevents",
        "version": "2.3.3",
        "type": "extra"
      },
      {
        "name": "function-bind",
        "version": "1.1.2",
        "type": "extra"
      },
      {
        "name": "function.prototype.name",
        "version": "1.1.8",
        "type": "extra"
      },
      {
        "name": "functional-red-black-tree",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "functions-have-names",
        "version": "1.2.3",
        "type": "extra"
      },
      {
        "name": "gaxios",
        "version": "6.7.1",
        "type": "extra"
      },
      {
        "name": "gaxios/node_modules/uuid",
        "version": "9.0.1",
        "type": "extra"
      },
      {
        "name": "gcp-metadata",
        "version": "6.1.1",
        "type": "extra"
      },
      {
        "name": "gensync",
        "version": "1.0.0-beta.2",
        "type": "extra"
      },
      {
        "name": "get-caller-file",
        "version": "2.0.5",
        "type": "extra"
      },
      {
        "name": "get-intrinsic",
        "version": "1.3.0",
        "type": "extra"
      },
      {
        "name": "get-package-type",
        "version": "0.1.0",
        "type": "extra"
      },
      {
        "name": "get-proto",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "get-stream",
        "version": "6.0.1",
        "type": "extra"
      },
      {
        "name": "get-symbol-description",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "glob",
        "version": "7.2.3",
        "type": "extra"
      },
      {
        "name": "glob-parent",
        "version": "6.0.2",
        "type": "extra"
      },
      {
        "name": "globals",
        "version": "13.24.0",
        "type": "extra"
      },
      {
        "name": "globalthis",
        "version": "1.0.4",
        "type": "extra"
      },
      {
        "name": "google-auth-library",
        "version": "9.15.1",
        "type": "extra"
      },
      {
        "name": "google-gax",
        "version": "4.6.1",
        "type": "extra"
      },
      {
        "name": "google-gax/node_modules/uuid",
        "version": "9.0.1",
        "type": "extra"
      },
      {
        "name": "google-logging-utils",
        "version": "0.0.2",
        "type": "extra"
      },
      {
        "name": "gopd",
        "version": "1.2.0",
        "type": "extra"
      },
      {
        "name": "graceful-fs",
        "version": "4.2.11",
        "type": "extra"
      },
      {
        "name": "graphemer",
        "version": "1.4.0",
        "type": "extra"
      },
      {
        "name": "gtoken",
        "version": "7.1.0",
        "type": "extra"
      },
      {
        "name": "has-bigints",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "has-flag",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "has-property-descriptors",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "has-proto",
        "version": "1.2.0",
        "type": "extra"
      },
      {
        "name": "has-symbols",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "has-tostringtag",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "hasown",
        "version": "2.0.2",
        "type": "extra"
      },
      {
        "name": "highlight.js",
        "version": "10.7.3",
        "type": "extra"
      },
      {
        "name": "hosted-git-info",
        "version": "2.8.9",
        "type": "extra"
      },
      {
        "name": "html-entities",
        "version": "2.6.0",
        "type": "extra"
      },
      {
        "name": "html-escaper",
        "version": "2.0.2",
        "type": "extra"
      },
      {
        "name": "http-errors",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "http-parser-js",
        "version": "0.5.10",
        "type": "extra"
      },
      {
        "name": "http-proxy-agent",
        "version": "5.0.0",
        "type": "extra"
      },
      {
        "name": "http-proxy-agent/node_modules/agent-base",
        "version": "6.0.2",
        "type": "extra"
      },
      {
        "name": "https-proxy-agent",
        "version": "7.0.6",
        "type": "extra"
      },
      {
        "name": "human-signals",
        "version": "2.1.0",
        "type": "extra"
      },
      {
        "name": "iconv-lite",
        "version": "0.4.24",
        "type": "extra"
      },
      {
        "name": "ieee754",
        "version": "1.2.1",
        "type": "extra"
      },
      {
        "name": "ignore",
        "version": "5.3.2",
        "type": "extra"
      },
      {
        "name": "ignore-by-default",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "import-fresh",
        "version": "3.3.1",
        "type": "extra"
      },
      {
        "name": "import-local",
        "version": "3.2.0",
        "type": "extra"
      },
      {
        "name": "imurmurhash",
        "version": "0.1.4",
        "type": "extra"
      },
      {
        "name": "inflight",
        "version": "1.0.6",
        "type": "extra"
      },
      {
        "name": "inherits",
        "version": "2.0.4",
        "type": "extra"
      },
      {
        "name": "internal-slot",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "ipaddr.js",
        "version": "1.9.1",
        "type": "extra"
      },
      {
        "name": "is-array-buffer",
        "version": "3.0.5",
        "type": "extra"
      },
      {
        "name": "is-arrayish",
        "version": "0.2.1",
        "type": "extra"
      },
      {
        "name": "is-async-function",
        "version": "2.1.1",
        "type": "extra"
      },
      {
        "name": "is-bigint",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "is-binary-path",
        "version": "2.1.0",
        "type": "extra"
      },
      {
        "name": "is-boolean-object",
        "version": "1.2.2",
        "type": "extra"
      },
      {
        "name": "is-callable",
        "version": "1.2.7",
        "type": "extra"
      },
      {
        "name": "is-core-module",
        "version": "2.16.1",
        "type": "extra"
      },
      {
        "name": "is-data-view",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "is-date-object",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "is-extglob",
        "version": "2.1.1",
        "type": "extra"
      },
      {
        "name": "is-finalizationregistry",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "is-fullwidth-code-point",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "is-generator-fn",
        "version": "2.1.0",
        "type": "extra"
      },
      {
        "name": "is-generator-function",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "is-glob",
        "version": "4.0.3",
        "type": "extra"
      },
      {
        "name": "is-map",
        "version": "2.0.3",
        "type": "extra"
      },
      {
        "name": "is-negative-zero",
        "version": "2.0.3",
        "type": "extra"
      },
      {
        "name": "is-number",
        "version": "7.0.0",
        "type": "extra"
      },
      {
        "name": "is-number-object",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "is-path-inside",
        "version": "3.0.3",
        "type": "extra"
      },
      {
        "name": "is-regex",
        "version": "1.2.1",
        "type": "extra"
      },
      {
        "name": "is-set",
        "version": "2.0.3",
        "type": "extra"
      },
      {
        "name": "is-shared-array-buffer",
        "version": "1.0.4",
        "type": "extra"
      },
      {
        "name": "is-stream",
        "version": "2.0.1",
        "type": "extra"
      },
      {
        "name": "is-string",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "is-symbol",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "is-typed-array",
        "version": "1.1.15",
        "type": "extra"
      },
      {
        "name": "is-weakmap",
        "version": "2.0.2",
        "type": "extra"
      },
      {
        "name": "is-weakref",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "is-weakset",
        "version": "2.0.4",
        "type": "extra"
      },
      {
        "name": "isarray",
        "version": "2.0.5",
        "type": "extra"
      },
      {
        "name": "isexe",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "istanbul-lib-coverage",
        "version": "3.2.2",
        "type": "extra"
      },
      {
        "name": "istanbul-lib-instrument",
        "version": "6.0.3",
        "type": "extra"
      },
      {
        "name": "istanbul-lib-instrument/node_modules/semver",
        "version": "7.7.2",
        "type": "extra"
      },
      {
        "name": "istanbul-lib-report",
        "version": "3.0.1",
        "type": "extra"
      },
      {
        "name": "istanbul-lib-report/node_modules/supports-color",
        "version": "7.2.0",
        "type": "extra"
      },
      {
        "name": "istanbul-lib-source-maps",
        "version": "4.0.1",
        "type": "extra"
      },
      {
        "name": "istanbul-reports",
        "version": "3.2.0",
        "type": "extra"
      },
      {
        "name": "iterare",
        "version": "1.2.1",
        "type": "extra"
      },
      {
        "name": "jackspeak",
        "version": "3.4.3",
        "type": "extra"
      },
      {
        "name": "jest",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-changed-files",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-circus",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-cli",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-config",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-diff",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-docblock",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-each",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-environment-node",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-get-type",
        "version": "29.6.3",
        "type": "extra"
      },
      {
        "name": "jest-haste-map",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-leak-detector",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-matcher-utils",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-message-util",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-mock",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-pnp-resolver",
        "version": "1.2.3",
        "type": "extra"
      },
      {
        "name": "jest-regex-util",
        "version": "29.6.3",
        "type": "extra"
      },
      {
        "name": "jest-resolve",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-resolve-dependencies",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-runner",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-runtime",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-snapshot",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-snapshot/node_modules/semver",
        "version": "7.7.2",
        "type": "extra"
      },
      {
        "name": "jest-util",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-validate",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-validate/node_modules/camelcase",
        "version": "6.3.0",
        "type": "extra"
      },
      {
        "name": "jest-watcher",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jest-worker",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "jose",
        "version": "4.15.9",
        "type": "extra"
      },
      {
        "name": "js-tokens",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "js-yaml",
        "version": "4.1.0",
        "type": "extra"
      },
      {
        "name": "jsesc",
        "version": "3.1.0",
        "type": "extra"
      },
      {
        "name": "json-bigint",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "json-buffer",
        "version": "3.0.1",
        "type": "extra"
      },
      {
        "name": "json-parse-better-errors",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "json-parse-even-better-errors",
        "version": "2.3.1",
        "type": "extra"
      },
      {
        "name": "json-schema-traverse",
        "version": "0.4.1",
        "type": "extra"
      },
      {
        "name": "json-stable-stringify-without-jsonify",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "json5",
        "version": "2.2.3",
        "type": "extra"
      },
      {
        "name": "jsonwebtoken/node_modules/jwa",
        "version": "1.4.2",
        "type": "extra"
      },
      {
        "name": "jsonwebtoken/node_modules/jws",
        "version": "3.2.2",
        "type": "extra"
      },
      {
        "name": "jsonwebtoken/node_modules/semver",
        "version": "7.7.2",
        "type": "extra"
      },
      {
        "name": "jwa",
        "version": "2.0.1",
        "type": "extra"
      },
      {
        "name": "jwks-rsa",
        "version": "3.2.0",
        "type": "extra"
      },
      {
        "name": "jws",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "keyv",
        "version": "4.5.4",
        "type": "extra"
      },
      {
        "name": "kleur",
        "version": "3.0.3",
        "type": "extra"
      },
      {
        "name": "leven",
        "version": "3.1.0",
        "type": "extra"
      },
      {
        "name": "levn",
        "version": "0.4.1",
        "type": "extra"
      },
      {
        "name": "libphonenumber-js",
        "version": "1.12.13",
        "type": "extra"
      },
      {
        "name": "limiter",
        "version": "1.1.5",
        "type": "extra"
      },
      {
        "name": "lines-and-columns",
        "version": "1.2.4",
        "type": "extra"
      },
      {
        "name": "load-json-file",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "load-json-file/node_modules/parse-json",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "load-json-file/node_modules/strip-bom",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "locate-path",
        "version": "6.0.0",
        "type": "extra"
      },
      {
        "name": "lodash",
        "version": "4.17.21",
        "type": "extra"
      },
      {
        "name": "lodash.camelcase",
        "version": "4.3.0",
        "type": "extra"
      },
      {
        "name": "lodash.clonedeep",
        "version": "4.5.0",
        "type": "extra"
      },
      {
        "name": "lodash.includes",
        "version": "4.3.0",
        "type": "extra"
      },
      {
        "name": "lodash.isboolean",
        "version": "3.0.3",
        "type": "extra"
      },
      {
        "name": "lodash.isinteger",
        "version": "4.0.4",
        "type": "extra"
      },
      {
        "name": "lodash.isnumber",
        "version": "3.0.3",
        "type": "extra"
      },
      {
        "name": "lodash.isplainobject",
        "version": "4.0.6",
        "type": "extra"
      },
      {
        "name": "lodash.isstring",
        "version": "4.0.1",
        "type": "extra"
      },
      {
        "name": "lodash.merge",
        "version": "4.6.2",
        "type": "extra"
      },
      {
        "name": "lodash.once",
        "version": "4.1.1",
        "type": "extra"
      },
      {
        "name": "long",
        "version": "5.3.2",
        "type": "extra"
      },
      {
        "name": "lru-cache",
        "version": "5.1.1",
        "type": "extra"
      },
      {
        "name": "lru-memoizer",
        "version": "2.3.0",
        "type": "extra"
      },
      {
        "name": "lru-memoizer/node_modules/lru-cache",
        "version": "6.0.0",
        "type": "extra"
      },
      {
        "name": "lru-memoizer/node_modules/yallist",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "make-dir",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "make-dir/node_modules/semver",
        "version": "7.7.2",
        "type": "extra"
      },
      {
        "name": "makeerror",
        "version": "1.0.12",
        "type": "extra"
      },
      {
        "name": "math-intrinsics",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "media-typer",
        "version": "0.3.0",
        "type": "extra"
      },
      {
        "name": "memorystream",
        "version": "0.3.1",
        "type": "extra"
      },
      {
        "name": "merge-descriptors",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "merge-stream",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "methods",
        "version": "1.1.2",
        "type": "extra"
      },
      {
        "name": "micromatch",
        "version": "4.0.8",
        "type": "extra"
      },
      {
        "name": "mime",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "mime-db",
        "version": "1.52.0",
        "type": "extra"
      },
      {
        "name": "mime-types",
        "version": "2.1.35",
        "type": "extra"
      },
      {
        "name": "mimic-fn",
        "version": "2.1.0",
        "type": "extra"
      },
      {
        "name": "minimatch",
        "version": "3.1.2",
        "type": "extra"
      },
      {
        "name": "minimist",
        "version": "1.2.8",
        "type": "extra"
      },
      {
        "name": "minipass",
        "version": "7.1.2",
        "type": "extra"
      },
      {
        "name": "mkdirp",
        "version": "2.1.6",
        "type": "extra"
      },
      {
        "name": "ms",
        "version": "2.1.3",
        "type": "extra"
      },
      {
        "name": "multer",
        "version": "1.4.4-lts.1",
        "type": "extra"
      },
      {
        "name": "multer/node_modules/mkdirp",
        "version": "0.5.6",
        "type": "extra"
      },
      {
        "name": "mz",
        "version": "2.7.0",
        "type": "extra"
      },
      {
        "name": "natural-compare",
        "version": "1.4.0",
        "type": "extra"
      },
      {
        "name": "negotiator",
        "version": "0.6.3",
        "type": "extra"
      },
      {
        "name": "nice-try",
        "version": "1.0.5",
        "type": "extra"
      },
      {
        "name": "node-fetch",
        "version": "2.7.0",
        "type": "extra"
      },
      {
        "name": "node-forge",
        "version": "1.3.1",
        "type": "extra"
      },
      {
        "name": "node-int64",
        "version": "0.4.0",
        "type": "extra"
      },
      {
        "name": "node-releases",
        "version": "2.0.19",
        "type": "extra"
      },
      {
        "name": "nodemon",
        "version": "3.0.2",
        "type": "extra"
      },
      {
        "name": "nodemon/node_modules/has-flag",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "nodemon/node_modules/semver",
        "version": "7.7.2",
        "type": "extra"
      },
      {
        "name": "nodemon/node_modules/supports-color",
        "version": "5.5.0",
        "type": "extra"
      },
      {
        "name": "normalize-package-data",
        "version": "2.5.0",
        "type": "extra"
      },
      {
        "name": "normalize-package-data/node_modules/semver",
        "version": "5.7.2",
        "type": "extra"
      },
      {
        "name": "normalize-path",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/ansi-styles",
        "version": "3.2.1",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/chalk",
        "version": "2.4.2",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/color-convert",
        "version": "1.9.3",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/color-name",
        "version": "1.1.3",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/cross-spawn",
        "version": "6.0.6",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/escape-string-regexp",
        "version": "1.0.5",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/has-flag",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/path-key",
        "version": "2.0.1",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/semver",
        "version": "5.7.2",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/shebang-command",
        "version": "1.2.0",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/shebang-regex",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/supports-color",
        "version": "5.5.0",
        "type": "extra"
      },
      {
        "name": "npm-run-all/node_modules/which",
        "version": "1.3.1",
        "type": "extra"
      },
      {
        "name": "npm-run-path",
        "version": "4.0.1",
        "type": "extra"
      },
      {
        "name": "object-assign",
        "version": "4.1.1",
        "type": "extra"
      },
      {
        "name": "object-hash",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "object-inspect",
        "version": "1.13.4",
        "type": "extra"
      },
      {
        "name": "object-keys",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "object.assign",
        "version": "4.1.7",
        "type": "extra"
      },
      {
        "name": "on-finished",
        "version": "2.4.1",
        "type": "extra"
      },
      {
        "name": "once",
        "version": "1.4.0",
        "type": "extra"
      },
      {
        "name": "onetime",
        "version": "5.1.2",
        "type": "extra"
      },
      {
        "name": "optionator",
        "version": "0.9.4",
        "type": "extra"
      },
      {
        "name": "own-keys",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "p-limit",
        "version": "3.1.0",
        "type": "extra"
      },
      {
        "name": "p-locate",
        "version": "5.0.0",
        "type": "extra"
      },
      {
        "name": "p-try",
        "version": "2.2.0",
        "type": "extra"
      },
      {
        "name": "package-json-from-dist",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "parent-module",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "parse-json",
        "version": "5.2.0",
        "type": "extra"
      },
      {
        "name": "parse5",
        "version": "5.1.1",
        "type": "extra"
      },
      {
        "name": "parse5-htmlparser2-tree-adapter",
        "version": "6.0.1",
        "type": "extra"
      },
      {
        "name": "parse5-htmlparser2-tree-adapter/node_modules/parse5",
        "version": "6.0.1",
        "type": "extra"
      },
      {
        "name": "parseurl",
        "version": "1.3.3",
        "type": "extra"
      },
      {
        "name": "path-exists",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "path-is-absolute",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "path-key",
        "version": "3.1.1",
        "type": "extra"
      },
      {
        "name": "path-parse",
        "version": "1.0.7",
        "type": "extra"
      },
      {
        "name": "path-scurry",
        "version": "1.11.1",
        "type": "extra"
      },
      {
        "name": "path-scurry/node_modules/lru-cache",
        "version": "10.4.3",
        "type": "extra"
      },
      {
        "name": "path-to-regexp",
        "version": "0.1.7",
        "type": "extra"
      },
      {
        "name": "path-type",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "pg-cloudflare",
        "version": "1.2.7",
        "type": "extra"
      },
      {
        "name": "pg-connection-string",
        "version": "2.9.1",
        "type": "extra"
      },
      {
        "name": "pg-int8",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "pg-pool",
        "version": "3.10.1",
        "type": "extra"
      },
      {
        "name": "pg-protocol",
        "version": "1.10.3",
        "type": "extra"
      },
      {
        "name": "pg-types",
        "version": "2.2.0",
        "type": "extra"
      },
      {
        "name": "pgpass",
        "version": "1.0.5",
        "type": "extra"
      },
      {
        "name": "picocolors",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "picomatch",
        "version": "2.3.1",
        "type": "extra"
      },
      {
        "name": "pidtree",
        "version": "0.3.1",
        "type": "extra"
      },
      {
        "name": "pify",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "pirates",
        "version": "4.0.7",
        "type": "extra"
      },
      {
        "name": "pkg-dir",
        "version": "4.2.0",
        "type": "extra"
      },
      {
        "name": "pkg-dir/node_modules/find-up",
        "version": "4.1.0",
        "type": "extra"
      },
      {
        "name": "pkg-dir/node_modules/locate-path",
        "version": "5.0.0",
        "type": "extra"
      },
      {
        "name": "pkg-dir/node_modules/p-limit",
        "version": "2.3.0",
        "type": "extra"
      },
      {
        "name": "pkg-dir/node_modules/p-locate",
        "version": "4.1.0",
        "type": "extra"
      },
      {
        "name": "possible-typed-array-names",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "postgres-array",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "postgres-bytea",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "postgres-date",
        "version": "1.0.7",
        "type": "extra"
      },
      {
        "name": "postgres-interval",
        "version": "1.2.0",
        "type": "extra"
      },
      {
        "name": "prelude-ls",
        "version": "1.2.1",
        "type": "extra"
      },
      {
        "name": "pretty-format",
        "version": "29.7.0",
        "type": "extra"
      },
      {
        "name": "pretty-format/node_modules/ansi-styles",
        "version": "5.2.0",
        "type": "extra"
      },
      {
        "name": "process-nextick-args",
        "version": "2.0.1",
        "type": "extra"
      },
      {
        "name": "prompts",
        "version": "2.4.2",
        "type": "extra"
      },
      {
        "name": "proto3-json-serializer",
        "version": "2.0.2",
        "type": "extra"
      },
      {
        "name": "protobufjs",
        "version": "7.5.4",
        "type": "extra"
      },
      {
        "name": "proxy-addr",
        "version": "2.0.7",
        "type": "extra"
      },
      {
        "name": "proxy-from-env",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "pstree.remy",
        "version": "1.1.8",
        "type": "extra"
      },
      {
        "name": "punycode",
        "version": "2.3.1",
        "type": "extra"
      },
      {
        "name": "pure-rand",
        "version": "6.1.0",
        "type": "extra"
      },
      {
        "name": "qs",
        "version": "6.14.0",
        "type": "extra"
      },
      {
        "name": "queue-microtask",
        "version": "1.2.3",
        "type": "extra"
      },
      {
        "name": "range-parser",
        "version": "1.2.1",
        "type": "extra"
      },
      {
        "name": "raw-body",
        "version": "2.5.2",
        "type": "extra"
      },
      {
        "name": "react-is",
        "version": "18.3.1",
        "type": "extra"
      },
      {
        "name": "read-pkg",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "readable-stream",
        "version": "3.6.2",
        "type": "extra"
      },
      {
        "name": "readdirp",
        "version": "3.6.0",
        "type": "extra"
      },
      {
        "name": "reflect-metadata",
        "version": "0.2.2",
        "type": "extra"
      },
      {
        "name": "reflect.getprototypeof",
        "version": "1.0.10",
        "type": "extra"
      },
      {
        "name": "regexp.prototype.flags",
        "version": "1.5.4",
        "type": "extra"
      },
      {
        "name": "require-directory",
        "version": "2.1.1",
        "type": "extra"
      },
      {
        "name": "resolve",
        "version": "1.22.10",
        "type": "extra"
      },
      {
        "name": "resolve-cwd",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "resolve-cwd/node_modules/resolve-from",
        "version": "5.0.0",
        "type": "extra"
      },
      {
        "name": "resolve-from",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "resolve.exports",
        "version": "2.0.3",
        "type": "extra"
      },
      {
        "name": "retry",
        "version": "0.13.1",
        "type": "extra"
      },
      {
        "name": "retry-request",
        "version": "7.0.2",
        "type": "extra"
      },
      {
        "name": "reusify",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "rimraf",
        "version": "3.0.2",
        "type": "extra"
      },
      {
        "name": "run-parallel",
        "version": "1.2.0",
        "type": "extra"
      },
      {
        "name": "rxjs",
        "version": "7.8.2",
        "type": "extra"
      },
      {
        "name": "safe-array-concat",
        "version": "1.1.3",
        "type": "extra"
      },
      {
        "name": "safe-buffer",
        "version": "5.2.1",
        "type": "extra"
      },
      {
        "name": "safe-push-apply",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "safe-regex-test",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "safer-buffer",
        "version": "2.1.2",
        "type": "extra"
      },
      {
        "name": "semver",
        "version": "6.3.1",
        "type": "extra"
      },
      {
        "name": "send",
        "version": "0.18.0",
        "type": "extra"
      },
      {
        "name": "send/node_modules/debug",
        "version": "2.6.9",
        "type": "extra"
      },
      {
        "name": "send/node_modules/debug/node_modules/ms",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "send/node_modules/mime",
        "version": "1.6.0",
        "type": "extra"
      },
      {
        "name": "serve-static",
        "version": "1.15.0",
        "type": "extra"
      },
      {
        "name": "set-function-length",
        "version": "1.2.2",
        "type": "extra"
      },
      {
        "name": "set-function-name",
        "version": "2.0.2",
        "type": "extra"
      },
      {
        "name": "set-proto",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "setprototypeof",
        "version": "1.2.0",
        "type": "extra"
      },
      {
        "name": "sha.js",
        "version": "2.4.12",
        "type": "extra"
      },
      {
        "name": "shebang-command",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "shebang-regex",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "shell-quote",
        "version": "1.8.3",
        "type": "extra"
      },
      {
        "name": "side-channel",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "side-channel-list",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "side-channel-map",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "side-channel-weakmap",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "signal-exit",
        "version": "3.0.7",
        "type": "extra"
      },
      {
        "name": "simple-update-notifier",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "simple-update-notifier/node_modules/semver",
        "version": "7.7.2",
        "type": "extra"
      },
      {
        "name": "sisteransi",
        "version": "1.0.5",
        "type": "extra"
      },
      {
        "name": "slash",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "source-map",
        "version": "0.6.1",
        "type": "extra"
      },
      {
        "name": "source-map-support",
        "version": "0.5.13",
        "type": "extra"
      },
      {
        "name": "spawn-command",
        "version": "0.0.2",
        "type": "extra"
      },
      {
        "name": "spdx-correct",
        "version": "3.2.0",
        "type": "extra"
      },
      {
        "name": "spdx-exceptions",
        "version": "2.5.0",
        "type": "extra"
      },
      {
        "name": "spdx-expression-parse",
        "version": "3.0.1",
        "type": "extra"
      },
      {
        "name": "spdx-license-ids",
        "version": "3.0.22",
        "type": "extra"
      },
      {
        "name": "split2",
        "version": "4.2.0",
        "type": "extra"
      },
      {
        "name": "sprintf-js",
        "version": "1.0.3",
        "type": "extra"
      },
      {
        "name": "stack-utils",
        "version": "2.0.6",
        "type": "extra"
      },
      {
        "name": "stack-utils/node_modules/escape-string-regexp",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "statuses",
        "version": "2.0.1",
        "type": "extra"
      },
      {
        "name": "stop-iteration-iterator",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "stream-events",
        "version": "1.0.5",
        "type": "extra"
      },
      {
        "name": "stream-shift",
        "version": "1.0.3",
        "type": "extra"
      },
      {
        "name": "streamsearch",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "string_decoder",
        "version": "1.3.0",
        "type": "extra"
      },
      {
        "name": "string-length",
        "version": "4.0.2",
        "type": "extra"
      },
      {
        "name": "string-width",
        "version": "4.2.3",
        "type": "extra"
      },
      {
        "name": "string-width-cjs",
        "version": "4.2.3",
        "type": "extra"
      },
      {
        "name": "string.prototype.padend",
        "version": "3.1.6",
        "type": "extra"
      },
      {
        "name": "string.prototype.trim",
        "version": "1.2.10",
        "type": "extra"
      },
      {
        "name": "string.prototype.trimend",
        "version": "1.0.9",
        "type": "extra"
      },
      {
        "name": "string.prototype.trimstart",
        "version": "1.0.8",
        "type": "extra"
      },
      {
        "name": "strip-ansi",
        "version": "6.0.1",
        "type": "extra"
      },
      {
        "name": "strip-ansi-cjs",
        "version": "6.0.1",
        "type": "extra"
      },
      {
        "name": "strip-bom",
        "version": "4.0.0",
        "type": "extra"
      },
      {
        "name": "strip-final-newline",
        "version": "2.0.0",
        "type": "extra"
      },
      {
        "name": "strip-json-comments",
        "version": "3.1.1",
        "type": "extra"
      },
      {
        "name": "stripe",
        "version": "16.8.0",
        "type": "extra"
      },
      {
        "name": "strnum",
        "version": "1.1.2",
        "type": "extra"
      },
      {
        "name": "stubs",
        "version": "3.0.0",
        "type": "extra"
      },
      {
        "name": "supports-color",
        "version": "8.1.1",
        "type": "extra"
      },
      {
        "name": "supports-preserve-symlinks-flag",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "teeny-request",
        "version": "9.0.0",
        "type": "extra"
      },
      {
        "name": "teeny-request/node_modules/agent-base",
        "version": "6.0.2",
        "type": "extra"
      },
      {
        "name": "teeny-request/node_modules/https-proxy-agent",
        "version": "5.0.1",
        "type": "extra"
      },
      {
        "name": "teeny-request/node_modules/uuid",
        "version": "9.0.1",
        "type": "extra"
      },
      {
        "name": "test-exclude",
        "version": "6.0.0",
        "type": "extra"
      },
      {
        "name": "text-table",
        "version": "0.2.0",
        "type": "extra"
      },
      {
        "name": "thenify",
        "version": "3.3.1",
        "type": "extra"
      },
      {
        "name": "thenify-all",
        "version": "1.6.0",
        "type": "extra"
      },
      {
        "name": "tmpl",
        "version": "1.0.5",
        "type": "extra"
      },
      {
        "name": "to-buffer",
        "version": "1.2.1",
        "type": "extra"
      },
      {
        "name": "to-regex-range",
        "version": "5.0.1",
        "type": "extra"
      },
      {
        "name": "toidentifier",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "touch",
        "version": "3.1.1",
        "type": "extra"
      },
      {
        "name": "tr46",
        "version": "0.0.3",
        "type": "extra"
      },
      {
        "name": "tree-kill",
        "version": "1.2.2",
        "type": "extra"
      },
      {
        "name": "tslib",
        "version": "2.8.1",
        "type": "extra"
      },
      {
        "name": "type-check",
        "version": "0.4.0",
        "type": "extra"
      },
      {
        "name": "type-detect",
        "version": "4.0.8",
        "type": "extra"
      },
      {
        "name": "type-fest",
        "version": "0.20.2",
        "type": "extra"
      },
      {
        "name": "type-is",
        "version": "1.6.18",
        "type": "extra"
      },
      {
        "name": "typed-array-buffer",
        "version": "1.0.3",
        "type": "extra"
      },
      {
        "name": "typed-array-byte-length",
        "version": "1.0.3",
        "type": "extra"
      },
      {
        "name": "typed-array-byte-offset",
        "version": "1.0.4",
        "type": "extra"
      },
      {
        "name": "typed-array-length",
        "version": "1.0.7",
        "type": "extra"
      },
      {
        "name": "typedarray",
        "version": "0.0.6",
        "type": "extra"
      },
      {
        "name": "typeorm",
        "version": "0.3.20",
        "type": "extra"
      },
      {
        "name": "typeorm/node_modules/brace-expansion",
        "version": "2.0.2",
        "type": "extra"
      },
      {
        "name": "typeorm/node_modules/dotenv",
        "version": "16.6.1",
        "type": "extra"
      },
      {
        "name": "typeorm/node_modules/glob",
        "version": "10.4.5",
        "type": "extra"
      },
      {
        "name": "typeorm/node_modules/minimatch",
        "version": "9.0.5",
        "type": "extra"
      },
      {
        "name": "typeorm/node_modules/uuid",
        "version": "9.0.1",
        "type": "extra"
      },
      {
        "name": "uid",
        "version": "2.0.2",
        "type": "extra"
      },
      {
        "name": "unbox-primitive",
        "version": "1.1.0",
        "type": "extra"
      },
      {
        "name": "undefsafe",
        "version": "2.0.5",
        "type": "extra"
      },
      {
        "name": "undici-types",
        "version": "5.26.5",
        "type": "extra"
      },
      {
        "name": "unpipe",
        "version": "1.0.0",
        "type": "extra"
      },
      {
        "name": "update-browserslist-db",
        "version": "1.1.3",
        "type": "extra"
      },
      {
        "name": "uri-js",
        "version": "4.4.1",
        "type": "extra"
      },
      {
        "name": "util-deprecate",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "utils-merge",
        "version": "1.0.1",
        "type": "extra"
      },
      {
        "name": "v8-to-istanbul",
        "version": "9.3.0",
        "type": "extra"
      },
      {
        "name": "validate-npm-package-license",
        "version": "3.0.4",
        "type": "extra"
      },
      {
        "name": "validator",
        "version": "13.15.15",
        "type": "extra"
      },
      {
        "name": "vary",
        "version": "1.1.2",
        "type": "extra"
      },
      {
        "name": "walker",
        "version": "1.0.8",
        "type": "extra"
      },
      {
        "name": "webidl-conversions",
        "version": "3.0.1",
        "type": "extra"
      },
      {
        "name": "websocket-driver",
        "version": "0.7.4",
        "type": "extra"
      },
      {
        "name": "websocket-extensions",
        "version": "0.1.4",
        "type": "extra"
      },
      {
        "name": "whatwg-url",
        "version": "5.0.0",
        "type": "extra"
      },
      {
        "name": "which",
        "version": "2.0.2",
        "type": "extra"
      },
      {
        "name": "which-boxed-primitive",
        "version": "1.1.1",
        "type": "extra"
      },
      {
        "name": "which-builtin-type",
        "version": "1.2.1",
        "type": "extra"
      },
      {
        "name": "which-collection",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "which-typed-array",
        "version": "1.1.19",
        "type": "extra"
      },
      {
        "name": "word-wrap",
        "version": "1.2.5",
        "type": "extra"
      },
      {
        "name": "wrap-ansi",
        "version": "7.0.0",
        "type": "extra"
      },
      {
        "name": "wrap-ansi-cjs",
        "version": "7.0.0",
        "type": "extra"
      },
      {
        "name": "wrappy",
        "version": "1.0.2",
        "type": "extra"
      },
      {
        "name": "write-file-atomic",
        "version": "4.0.2",
        "type": "extra"
      },
      {
        "name": "xtend",
        "version": "4.0.2",
        "type": "extra"
      },
      {
        "name": "y18n",
        "version": "5.0.8",
        "type": "extra"
      },
      {
        "name": "yallist",
        "version": "3.1.1",
        "type": "extra"
      },
      {
        "name": "yargs",
        "version": "17.7.2",
        "type": "extra"
      },
      {
        "name": "yargs-parser",
        "version": "21.1.1",
        "type": "extra"
      },
      {
        "name": "yocto-queue",
        "version": "0.1.0",
        "type": "extra"
      },
      {
        "name": "zod",
        "version": "3.23.8",
        "type": "extra"
      }
    ],
    "mismatched": []
  },
  "workspaces": {
    "apps/hr-api": {
      "name": "@apps/hr-api",
      "dependencyCount": 20,
      "issues": []
    },
    "apps/hr-web": {
      "name": "@apps/hr-web",
      "dependencyCount": 1,
      "issues": []
    },
    "packages/auth": {
      "name": "@platform/auth",
      "dependencyCount": 2,
      "issues": []
    },
    "packages/db": {
      "name": "@platform/db",
      "dependencyCount": 2,
      "issues": []
    },
    "packages/integrations": {
      "name": "@hunters-run/integrations",
      "dependencyCount": 7,
      "issues": []
    },
    "packages/shared": {
      "name": "@platform/shared",
      "dependencyCount": 1,
      "issues": []
    }
  },
  "summary": {
    "totalDependencies": 11,
    "issues": 879,
    "hasLockfile": true,
    "lockfileType": "npm"
  }
}
```

### env-runtime.json
```json
{
  "timestamp": "2025-08-28T13:33:40.690Z",
  "environment": {
    "type": "win32",
    "container": false,
    "virtualized": false,
    "details": {
      "osType": "Windows_NT",
      "osRelease": "10.0.26100"
    }
  },
  "resources": {
    "cpu": {
      "cores": 4,
      "architecture": "x64"
    },
    "memory": {
      "total": 16912171008,
      "free": 7572488192,
      "totalGB": 15.75
    }
  },
  "node": {
    "version": "v22.18.0",
    "platform": "win32",
    "arch": "x64",
    "execPath": "C:\\Program Files\\nodejs\\node.exe",
    "cwd": "C:\\Users\\KA\\myprojects3\\hunters-run",
    "env": {
      "NODE_ENV": "undefined",
      "npm_config_user_config": "undefined",
      "npm_node_execpath": "C:\\Program Files\\nodejs\\node.exe"
    }
  },
  "hostname": "DESKTOP-BAMDQDC",
  "uptime": 401446.921
}
```

### net-matrix.json
```json
{
  "timestamp": "2025-08-28T13:33:41.120Z",
  "totalTargets": 5,
  "successful": 5,
  "failed": 0,
  "averageLatency": 193.8,
  "results": [
    {
      "name": "database",
      "type": "tcp",
      "description": "PostgreSQL database connection",
      "target": "aws-1-us-east-2.pooler.supabase.com",
      "port": 6543,
      "success": true,
      "latency": 80,
      "error": null,
      "timestamp": "2025-08-28T13:33:41.204Z"
    },
    {
      "name": "firebase-auth",
      "type": "http",
      "description": "Firebase Authentication API",
      "target": "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=test",
      "port": null,
      "success": true,
      "latency": 550,
      "error": null,
      "statusCode": 404,
      "timestamp": "2025-08-28T13:33:41.756Z"
    },
    {
      "name": "firebase-jwks",
      "type": "http",
      "description": "Firebase JWKS endpoint",
      "target": "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com",
      "port": null,
      "success": true,
      "latency": 126,
      "error": null,
      "statusCode": 200,
      "timestamp": "2025-08-28T13:33:41.882Z"
    },
    {
      "name": "google-dns",
      "type": "tcp",
      "description": "Google DNS (connectivity test)",
      "target": "8.8.8.8",
      "port": 53,
      "success": true,
      "latency": 42,
      "error": null,
      "timestamp": "2025-08-28T13:33:41.925Z"
    },
    {
      "name": "github-api",
      "type": "http",
      "description": "GitHub API (external connectivity)",
      "target": "https://api.github.com",
      "port": null,
      "success": true,
      "latency": 171,
      "error": null,
      "statusCode": 200,
      "timestamp": "2025-08-28T13:33:42.096Z"
    }
  ]
}
```

### test-smoke.json
```json
{
  "timestamp": "2025-08-28T13:33:43.216Z",
  "framework": "npm-script",
  "tests": [
    {
      "name": "npm-test",
      "passed": false,
      "duration": 6,
      "output": ""
    }
  ],
  "summary": {
    "total": 1,
    "passed": 0,
    "failed": 1,
    "duration": 6,
    "success": false
  },
  "details": {
    "npmScript": {
      "exitCode": 1,
      "stdout": "",
      "stderr": "spawn npm ENOENT",
      "success": false,
      "error": "spawn npm ENOENT"
    }
  }
}
```

## Diagnostic Artifacts (Markdown) — reports/artifacts
### config-sanity.md
```markdown
# Configuration Sanity Report
Generated: 2025-08-28T13:33:42.794Z

## Overall Status: OK

- **Total Variables Checked**: 15
- **Required Variables**: 2
- **Missing Required**: 0
- **Environment Variables Set**: 3

## Service: hr-api

**Status**: ✅ OK

### Required Configuration
- **DATABASE_URL**: ✅ PostgreSQL connection string
- **FIREBASE_PROJECT_ID**: ✅ Firebase project identifier

### Optional Configuration
- **DB_SSL_MODE**: ✅ Database SSL mode (strict/relaxed)
- **FIREBASE_SERVICE_ACCOUNT_JSON**: ⚪ Firebase service account JSON
- **FIREBASE_SERVICE_ACCOUNT_PATH**: ⚪ Path to Firebase service account file



## Service: hr-web

**Status**: ✅ OK

### Required Configuration
- **FIREBASE_PROJECT_ID**: ✅ Firebase project identifier

### Optional Configuration
- **NODE_ENV**: ⚪ Node environment (development/production)



## Environment Variables Overview

- **DATABASE_URL**: ✅ Set - PostgreSQL connection string
- **DB_SSL_MODE**: ✅ Set - Database SSL mode (strict/relaxed)
- **FIREBASE_PROJECT_ID**: ✅ Set - Firebase project identifier
- **FIREBASE_CLIENT_EMAIL**: ❌ Not Set - Firebase service account email
- **FIREBASE_PRIVATE_KEY**: ❌ Not Set - Firebase service account private key
- **FIREBASE_SERVICE_ACCOUNT_JSON**: ❌ Not Set - Firebase service account JSON
- **FIREBASE_SERVICE_ACCOUNT_PATH**: ❌ Not Set - Path to Firebase service account file
- **AWS_REGION**: ❌ Not Set - AWS region for S3
- **AWS_S3_BUCKET**: ❌ Not Set - S3 bucket name for file storage
- **AWS_ACCESS_KEY_ID**: ❌ Not Set - AWS access key
- **AWS_SECRET_ACCESS_KEY**: ❌ Not Set - AWS secret key
- **NODE_ENV**: ❌ Not Set - Node environment (development/production)
- **PORT**: ❌ Not Set - Server port number
- **DEV_AUTH_BYPASS**: ❌ Not Set - Development authentication bypass
- **TENANT_PHOTO_FLOW_ENABLED**: ❌ Not Set - Enable tenant photo upload flow

---
*Note: This report shows only the presence of configuration variables, not their actual values.*

```

## Package Configuration
```json
{
  "name": "hunters-run",
  "version": "0.1.0",
  "private": true,
  "workspaces": [
    "apps/*",
    "packages/*"
  ],
  "engines": {
    "node": ">=20.10.0"
  },
  "scripts": {
    "build": "npm -ws run build --if-present",
    "build:api": "npm -w @apps/hr-api run build",
    "test": "echo \"(add tests)\" && exit 0",
    "migrate": "node -e \"const{execSync}=require('child_process'); execSync('psql \"'+process.env.DATABASE_URL+'\" -f packages/db/migrations/020_platform_identity.sql', {stdio:'inherit'})\"",
    "dev:all": "concurrently \"npm run dev:api\" \"npm run dev:web\"",
    "dev:api": "npm -w @apps/hr-api run start:dev",
    "dev:web": "npm -w @apps/hr-web run dev",
    "selfcheck:workorders": "node scripts/selfcheck-workorders.mjs",
    "selfcheck:workorders:list": "node scripts/selfcheck-workorders-list.mjs",
    "selfcheck:rls": "node scripts/selfcheck-rls.mjs",
    "selfcheck:staging": "node scripts/selfcheck-staging.mjs",
    "selfcheck:local": "npm -w @apps/hr-api run selfcheck:local",
    "selfcheck:testplan": "node scripts/selfcheck-testplan.mjs",
    "status": "node scripts/project-status.mjs",
    "verify": "node scripts/project-verify.mjs",
    "report": "node scripts/project-report.mjs",
    "report:quick": "node scripts/project-report.mjs –quick",
    "launch": "node scripts/launcher.mjs",
    "launch:api": "node scripts/launcher.mjs --service=hr-api --env=dev",
    "launch:quick": "node scripts/launcher.mjs --service=hr-api --env=dev --quick",
    "health": "node scripts/health-check.mjs",
    "seed:demo-units": "node scripts/seed-demo-units.mjs",
    "probe:db": "node scripts/probe-db.mjs",
    "auth:inspect": "node scripts/auth/inspect.mjs",
    "auth:inspect:verify": "node scripts/auth/inspect.mjs –verify",
    "diagnostic:env": "node scripts/diagnostics/env-runtime.mjs",
    "diagnostic:net": "node scripts/diagnostics/net-matrix.mjs",
    "diagnostic:drift": "node scripts/diagnostics/dep-drift.mjs",
    "diagnostic:config": "node scripts/diagnostics/config-sanity.mjs",
    "diagnostic:smoke": "node scripts/diagnostics/test-smoke.mjs",
    "report:diagnostics:v2": "npm-run-all -s diagnostic:env diagnostic:net diagnostic:drift diagnostic:config diagnostic:smoke",
    "generate-upload": "node scripts/generate-upload.mjs",
    "seed:dev": "node scripts/seed-dev-identity.mjs",
    "test:identity": "node scripts/test-identity-system.mjs",
    "test:rls": "node scripts/test-rls-isolation.mjs",
    "test:identity:full": "node scripts/run-all-identity-tests.mjs",
    "test:identity:windows": "node scripts/run-all-identity-tests-windows.mjs",
    "verify:identity": "npm run test:identity:full",
    "verify:identity:manual": "node scripts/verify-identity-manual.mjs",
    "verify:manual": "node scripts/manual-identity-check.mjs",
    "verify:complete": "node scripts/complete-identity-proof.mjs",
    "debug:auth": "node scripts/debug-auth-pipeline.mjs",
    "debug:identity": "node scripts/debug-identity-service.mjs",
    "debug:guards": "node scripts/check-guard-conflicts.mjs",
    "debug:migration": "node scripts/verify-migration.mjs",
    "test:db": "node scripts/test-database-connectivity.mjs",
    "test:env": "node scripts/test-environment-loading.mjs",
    "setup:test:env": "powershell -ExecutionPolicy Bypass -File scripts/setup-test-env.ps1",
    "lint": "eslint .",
    "selfcheck:all": "node tools/scripts/run-all.mjs selfcheck",
    "snapshot:all": "node tools/scripts/run-all.mjs snapshot",
    "db:ping:hunters-run": "node tools/scripts/supa-db-ping.mjs apps/hunters-run/.env",
    "db:wait:hunters-run": "node tools/scripts/supa-db-wait.mjs apps/hunters-run/.env --timeout=30",
    "build:hunters-run": "npx tsc -p apps/hr-api/tsconfig.json --noEmit",
    "selfcheck:hunters-run:step1": "node tools/scripts/selfcheck-hr-step1.mjs",
    "prove": "node tools/scripts/prove.mjs"
  },
  "devDependencies": {
    "@types/uuid": "^10.0.0",
    "concurrently": "8.2.2",
    "dotenv": "^17.2.1",
    "eslint": "8.57.0",
    "eslint-plugin-boundaries": "^5.0.1",
    "jsonwebtoken": "^9.0.2",
    "npm-run-all": "^4.1.5",
    "prettier": "3.2.5",
    "typescript": "5.4.5"
  },
  "dependencies": {
    "pg": "8.12.0",
    "uuid": "^11.1.0"
  }
}

```

## Project Structure (first 50 files under src/ and scripts/)
```
apps\hr-api\src\test.controller.ts
apps\hr-api\src\routes\webhooks.controller.ts
apps\hr-api\src\routes\health.controller.ts
apps\hr-api\src\root.module.ts
apps\hr-api\src\properties.controller.ts
apps\hr-api\src\properties\properties.service.ts
apps\hr-api\src\modules\work-orders\work-orders.service.ts
apps\hr-api\src\modules\work-orders\work-orders.service.spec.ts
apps\hr-api\src\modules\work-orders\work-orders.module.ts
apps\hr-api\src\modules\work-orders\work-orders.controller.ts
apps\hr-api\src\modules\work-orders\work-orders.controller.spec.ts
apps\hr-api\src\modules\work-orders\services\state-machine.service.ts
apps\hr-api\src\modules\work-orders\entities\work-order.entity.ts
apps\hr-api\src\modules\work-orders\dto\update-work-order.dto.ts
apps\hr-api\src\modules\work-orders\dto\state-transition.dto.ts
apps\hr-api\src\modules\work-orders\dto\list-work-orders.dto.ts
apps\hr-api\src\modules\work-orders\dto\create-work-order.dto.ts
apps\hr-api\src\main.ts
apps\hr-api\src\identity\identity.service.ts
apps\hr-api\src\identity\identity.module.ts
apps\hr-api\src\health.controller.ts
apps\hr-api\src\db\pg.service.ts
apps\hr-api\src\common\request-context.middleware.ts
apps\hr-api\src\common\org.middleware.ts
apps\hr-api\src\common\database.service.ts
apps\hr-api\src\auth\token\token-adapter.ts
apps\hr-api\src\auth\guards\composite-authz.guard.ts
apps\hr-api\src\auth\decorators\require-permission.decorator.ts
apps\hr-api\src\auth\decorators\require-org.decorator.ts
apps\hr-api\src\auth\decorators\public.decorator.ts
apps\hr-api\src\auth\decorators\current-user.decorator.ts
apps\hr-api\src\auth\decorators\current-principal.decorator.ts
apps\hr-api\src\auth\auth.module.ts
apps\hr-api\src\auth\auth.controller.ts
apps\hr-api\src\audit\event.service.ts
apps\hr-api\src\app.module.ts
scripts\_utils.mjs
scripts\verify-units-constraint.mjs
scripts\verify-migration.mjs
scripts\verify-identity-manual.mjs
scripts\validate-setup.sh
scripts\test-rls-isolation.mjs
scripts\test-migration.mjs
scripts\test-identity-system.mjs
scripts\test-environment-loading.mjs
scripts\test-env-loader.mjs
scripts\test-database-connectivity.mjs
scripts\test-complete-auth-system.mjs
scripts\templates\k8s-probes.yaml
scripts\templates\docker-healthcheck.sh
```

### apps/hr-api/src/
```
app.module.ts
audit
auth
common
db
health.controller.ts
identity
main.ts
modules
properties
properties.controller.ts
root.module.ts
routes
test.controller.ts
```

### scripts/
```
api-isolation-test.mjs
auth
check-guard-conflicts.mjs
check-rls-security.mjs
complete-identity-proof.mjs
config
db-whoami.mjs
debug-auth-pipeline.mjs
debug-identity-service.mjs
debug-rls.mjs
diagnostics
diagnostics.mjs
fix-rls-policies.sql
generate-test-tokens.mjs
generate-upload.mjs
health-check.mjs
launcher.mjs
logger.mjs
manual-identity-check.mjs
migrate.js
probe-db.mjs
process-manager.mjs
project-report.mjs
project-status.mjs
project-verify.mjs
rls-final-validation.mjs
rls-validation-exact.mjs
run-all-identity-tests-windows.mjs
run-all-identity-tests.mjs
seed-demo-units.mjs
seed-dev-identity.mjs
selfcheck-demo-units.ps1
selfcheck-rls.mjs
selfcheck-staging.mjs
selfcheck-testplan.mjs
setup-test-env.ps1
templates
test-complete-auth-system.mjs
test-database-connectivity.mjs
test-env-loader.mjs
test-environment-loading.mjs
test-identity-system.mjs
test-migration.mjs
test-rls-isolation.mjs
validate-setup.sh
verify-identity-manual.mjs
verify-migration.mjs
verify-units-constraint.mjs
_utils.mjs
```

## Database Schema
```
Skipped (psql not found or DATABASE_URL not set)
```

## Environment Variables (Names Only)
```
```

## Available NPM Scripts
```json
{
  "build": "npm -ws run build --if-present",
  "build:api": "npm -w @apps/hr-api run build",
  "test": "echo \"(add tests)\" && exit 0",
  "migrate": "node -e \"const{execSync}=require('child_process'); execSync('psql \"'+process.env.DATABASE_URL+'\" -f packages/db/migrations/020_platform_identity.sql', {stdio:'inherit'})\"",
  "dev:all": "concurrently \"npm run dev:api\" \"npm run dev:web\"",
  "dev:api": "npm -w @apps/hr-api run start:dev",
  "dev:web": "npm -w @apps/hr-web run dev",
  "selfcheck:workorders": "node scripts/selfcheck-workorders.mjs",
  "selfcheck:workorders:list": "node scripts/selfcheck-workorders-list.mjs",
  "selfcheck:rls": "node scripts/selfcheck-rls.mjs",
  "selfcheck:staging": "node scripts/selfcheck-staging.mjs",
  "selfcheck:local": "npm -w @apps/hr-api run selfcheck:local",
  "selfcheck:testplan": "node scripts/selfcheck-testplan.mjs",
  "status": "node scripts/project-status.mjs",
  "verify": "node scripts/project-verify.mjs",
  "report": "node scripts/project-report.mjs",
  "report:quick": "node scripts/project-report.mjs –quick",
  "launch": "node scripts/launcher.mjs",
  "launch:api": "node scripts/launcher.mjs --service=hr-api --env=dev",
  "launch:quick": "node scripts/launcher.mjs --service=hr-api --env=dev --quick",
  "health": "node scripts/health-check.mjs",
  "seed:demo-units": "node scripts/seed-demo-units.mjs",
  "probe:db": "node scripts/probe-db.mjs",
  "auth:inspect": "node scripts/auth/inspect.mjs",
  "auth:inspect:verify": "node scripts/auth/inspect.mjs –verify",
  "diagnostic:env": "node scripts/diagnostics/env-runtime.mjs",
  "diagnostic:net": "node scripts/diagnostics/net-matrix.mjs",
  "diagnostic:drift": "node scripts/diagnostics/dep-drift.mjs",
  "diagnostic:config": "node scripts/diagnostics/config-sanity.mjs",
  "diagnostic:smoke": "node scripts/diagnostics/test-smoke.mjs",
  "report:diagnostics:v2": "npm-run-all -s diagnostic:env diagnostic:net diagnostic:drift diagnostic:config diagnostic:smoke",
  "generate-upload": "node scripts/generate-upload.mjs",
  "seed:dev": "node scripts/seed-dev-identity.mjs",
  "test:identity": "node scripts/test-identity-system.mjs",
  "test:rls": "node scripts/test-rls-isolation.mjs",
  "test:identity:full": "node scripts/run-all-identity-tests.mjs",
  "test:identity:windows": "node scripts/run-all-identity-tests-windows.mjs",
  "verify:identity": "npm run test:identity:full",
  "verify:identity:manual": "node scripts/verify-identity-manual.mjs",
  "verify:manual": "node scripts/manual-identity-check.mjs",
  "verify:complete": "node scripts/complete-identity-proof.mjs",
  "debug:auth": "node scripts/debug-auth-pipeline.mjs",
  "debug:identity": "node scripts/debug-identity-service.mjs",
  "debug:guards": "node scripts/check-guard-conflicts.mjs",
  "debug:migration": "node scripts/verify-migration.mjs",
  "test:db": "node scripts/test-database-connectivity.mjs",
  "test:env": "node scripts/test-environment-loading.mjs",
  "setup:test:env": "powershell -ExecutionPolicy Bypass -File scripts/setup-test-env.ps1",
  "lint": "eslint .",
  "selfcheck:all": "node tools/scripts/run-all.mjs selfcheck",
  "snapshot:all": "node tools/scripts/run-all.mjs snapshot",
  "db:ping:hunters-run": "node tools/scripts/supa-db-ping.mjs apps/hunters-run/.env",
  "db:wait:hunters-run": "node tools/scripts/supa-db-wait.mjs apps/hunters-run/.env --timeout=30",
  "build:hunters-run": "npx tsc -p apps/hr-api/tsconfig.json --noEmit",
  "selfcheck:hunters-run:step1": "node tools/scripts/selfcheck-hr-step1.mjs",
  "prove": "node tools/scripts/prove.mjs"
}
```
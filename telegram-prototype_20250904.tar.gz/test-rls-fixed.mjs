import pkg from 'pg';
const { Client } = pkg;

const client = new Client({ 
  connectionString: "postgresql://hr_app:hr_app_secure_2024@aws-1-us-east-2.pooler.supabase.com:6543/postgres",
  ssl: { rejectUnauthorized: false }
});

async function testRLSFixed() {
  try {
    await client.connect();
    console.log('🔐 TESTING RLS WITH NON-BYPASS ROLE');
    console.log('');
    
    // Verify we're using the correct role
    const roleCheck = await client.query('SELECT current_user, rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user');
    console.log('Current role:', roleCheck.rows[0]);
    
    // Recreate RLS policy with proper organization filtering
    console.log('\n=== RECREATING RLS POLICIES ===');
    await client.query('DROP POLICY IF EXISTS work_orders_org_rls ON hr.work_orders');
    
    await client.query(`
      CREATE POLICY work_orders_org_rls ON hr.work_orders
      FOR ALL
      USING (organization_id = (current_setting('app.current_organization', true))::uuid)
      WITH CHECK (organization_id = (current_setting('app.current_organization', true))::uuid)
    `);
    
    console.log('✅ Created RLS policy for work_orders');
    
    // Test RLS - should see nothing without org context
    console.log('\n=== TESTING RLS ISOLATION ===');
    console.log('1. Without org context (should see 0 rows):');
    const noContext = await client.query('SELECT COUNT(*) as count FROM hr.work_orders');
    console.log('   Count:', noContext.rows[0].count);
    
    // Test with Demo org context
    console.log('\n2. With Demo org context (should see only Demo org work orders):');
    await client.query(`SELECT set_config('app.current_organization', '00000000-0000-4000-8000-000000000001', false)`);
    const demoContext = await client.query('SELECT ticket_number, organization_id FROM hr.work_orders ORDER BY created_at');
    console.log(`   Visible work orders (${demoContext.rows.length}):`);
    demoContext.rows.forEach(wo => {
      const isCorrectOrg = wo.organization_id === '00000000-0000-4000-8000-000000000001';
      console.log(`   - ${wo.ticket_number} (${wo.organization_id}) ${isCorrectOrg ? '✅' : '❌ WRONG ORG'}`);
    });
    
    // Test with Test org B context  
    console.log('\n3. With Test Org B context (should see only Org B work orders):');
    await client.query(`SELECT set_config('app.current_organization', '11111111-1111-1111-1111-111111111111', false)`);
    const testOrgContext = await client.query('SELECT ticket_number, organization_id FROM hr.work_orders ORDER BY created_at');
    console.log(`   Visible work orders (${testOrgContext.rows.length}):`);
    testOrgContext.rows.forEach(wo => {
      const isCorrectOrg = wo.organization_id === '11111111-1111-1111-1111-111111111111';
      console.log(`   - ${wo.ticket_number} (${wo.organization_id}) ${isCorrectOrg ? '✅' : '❌ WRONG ORG'}`);
    });
    
    await client.end();
    
    if (noContext.rows[0].count === '0' && 
        demoContext.rows.every(wo => wo.organization_id === '00000000-0000-4000-8000-000000000001') &&
        testOrgContext.rows.every(wo => wo.organization_id === '11111111-1111-1111-1111-111111111111')) {
      console.log('\n🎉 SUCCESS: RLS IS NOW WORKING PROPERLY!');
      return true;
    } else {
      console.log('\n❌ FAILURE: RLS still not working correctly');
      return false;
    }
    
  } catch (err) {
    console.error('❌ Error:', err.message);
    return false;
  }
}

testRLSFixed();
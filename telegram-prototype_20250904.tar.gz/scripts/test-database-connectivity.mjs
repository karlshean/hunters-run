#!/usr/bin/env node
// Simple database connectivity test
import pkg from 'pg';
const { Client } = pkg;
import { testEnvLoader } from './test-env-loader.mjs';

async function testDatabaseConnectivity() {
  console.log('🔍 Testing Database Connectivity');
  console.log('================================');
  
  try {
    // Setup test environment and get database config
    testEnvLoader.setupTestEnvironment();
    const dbConfig = testEnvLoader.getDatabaseConfig();
    
    const client = new Client(dbConfig);
    
    console.log('Connecting to database...');
    await client.connect();
    console.log('✅ Database connection successful');
    
    // Test platform schema access
    console.log('\nTesting platform schema access...');
    
    const usersResult = await client.query('SELECT COUNT(*) as count FROM platform.users');
    console.log(`✅ Users table: ${usersResult.rows[0].count} records`);
    
    const orgsResult = await client.query('SELECT COUNT(*) as count FROM platform.organizations');
    console.log(`✅ Organizations table: ${orgsResult.rows[0].count} records`);
    
    const rolesResult = await client.query('SELECT COUNT(*) as count FROM platform.roles');
    console.log(`✅ Roles table: ${rolesResult.rows[0].count} records`);
    
    const membershipsResult = await client.query('SELECT COUNT(*) as count FROM platform.memberships');
    console.log(`✅ Memberships table: ${membershipsResult.rows[0].count} records`);
    
    const auditResult = await client.query('SELECT COUNT(*) as count FROM platform.audit_events');
    console.log(`✅ Audit events table: ${auditResult.rows[0].count} records`);
    
    // Test a simple query with organization context
    console.log('\nTesting organization context...');
    const orgId = '00000000-0000-4000-8000-000000000001';
    await client.query("SELECT set_config('app.current_organization', $1, false)", [orgId]);
    const contextResult = await client.query("SELECT current_setting('app.current_organization', true) as org_id");
    console.log(`✅ Organization context set to: ${contextResult.rows[0].org_id}`);
    
    await client.end();
    console.log('\n🎉 All database tests passed!');
    return true;
    
  } catch (error) {
    console.log(`❌ Test failed: ${error.message}`);
    return false;
  }
}

// Run the test
testDatabaseConnectivity()
  .then(success => process.exit(success ? 0 : 1))
  .catch(error => {
    console.error('Test runner failed:', error.message);
    process.exit(1);
  });
#!/usr/bin/env node
import pkg from 'pg';
const { Client } = pkg;
import { testEnvLoader } from './test-env-loader.mjs';

async function testRLSIsolation() {
  // Setup test environment first
  testEnvLoader.setupTestEnvironment();
  
  const client = new Client(testEnvLoader.getDatabaseConfig());
  
  await client.connect();
  
  try {
    console.log('=== RLS Isolation Test ===\n');
    
    const orgA = '00000000-0000-4000-8000-000000000001';
    const orgB = '00000000-0000-4000-8000-000000000002';
    
    // Ensure test orgs exist
    await client.query(`
      INSERT INTO platform.organizations (id, name) VALUES 
      ($1, 'Test Org A'), ($2, 'Test Org B')
      ON CONFLICT (id) DO NOTHING
    `, [orgA, orgB]);
    console.log('✅ Test organizations ensured');
    
    // Insert test properties with explicit organization_id (not org_id)
    await client.query(`
      INSERT INTO hr.properties (id, organization_id, name, address) VALUES 
      ('10000000-0000-4000-8000-000000000001', $1, 'Property A1', '123 Test St A'),
      ('20000000-0000-4000-8000-000000000002', $2, 'Property B1', '456 Test St B')
      ON CONFLICT (id) DO NOTHING
    `, [orgA, orgB]);
    console.log('✅ Test properties inserted');
    
    // Check total properties without context
    const totalProps = await client.query('SELECT COUNT(*) as count FROM hr.properties');
    console.log(`Total properties in database: ${totalProps.rows[0].count}`);
    
    // Set context to Org A
    await client.query("SELECT set_config('app.org_id', $1, false)", [orgA]);
    const propertiesA = await client.query('SELECT COUNT(*) as count FROM hr.properties');
    
    // Set context to Org B  
    await client.query("SELECT set_config('app.org_id', $1, false)", [orgB]);
    const propertiesB = await client.query('SELECT COUNT(*) as count FROM hr.properties');
    
    console.log(`\nOrg A context: ${propertiesA.rows[0].count} properties visible`);
    console.log(`Org B context: ${propertiesB.rows[0].count} properties visible`);
    
    // Check current user privileges
    const userInfo = await client.query(`
      SELECT 
        current_user,
        rolbypassrls
      FROM pg_roles 
      WHERE rolname = current_user
    `);
    
    const bypassRLS = userInfo.rows[0]?.rolbypassrls;
    console.log(`\nCurrent user: ${userInfo.rows[0]?.current_user}`);
    console.log(`Bypass RLS: ${bypassRLS}`);
    
    // Interpret results
    if (bypassRLS) {
      console.log('\n🔍 RLS Analysis:');
      console.log('   - Current user has BYPASSRLS privilege (admin user)');
      console.log('   - RLS policies exist but are bypassed for this user');
      console.log('   - In production, app users should NOT have BYPASSRLS');
      console.log('   - This is expected behavior for database admin users');
      
      // Test the RLS policy logic directly
      console.log('\n📋 Testing RLS Policy Logic:');
      
      // Set fake org context and test policy condition
      const fakeOrgId = '99999999-9999-9999-9999-999999999999';
      await client.query("SELECT set_config('app.org_id', $1, false)", [fakeOrgId]);
      
      const policyTest = await client.query(`
        SELECT 
          id,
          organization_id,
          current_setting('app.org_id', true) as context_value,
          organization_id = (current_setting('app.org_id', true))::uuid as policy_match
        FROM hr.properties
        LIMIT 2
      `);
      
      policyTest.rows.forEach((row, i) => {
        console.log(`   Property ${i+1}: org=${row.organization_id}, context=${row.context_value}, match=${row.policy_match}`);
      });
      
      if (policyTest.rows.some(row => !row.policy_match)) {
        console.log('   ✅ RLS policy logic is correct (would filter if not bypassed)');
      }
      
    } else {
      // Non-admin user - RLS should be enforcing
      if (parseInt(propertiesA.rows[0].count) !== parseInt(propertiesB.rows[0].count)) {
        console.log('\n✅ RLS isolation confirmed - organization boundaries enforced');
        console.log('   - Different org contexts show different data');
        console.log('   - Row Level Security is working correctly');
      } else {
        const countA = parseInt(propertiesA.rows[0].count);
        const countB = parseInt(propertiesB.rows[0].count);
        if (countA === 0 && countB === 0) {
          console.log('\n✅ RLS isolation confirmed - all data filtered by org context');
        } else if (countA > 0 && countB > 0 && countA === countB) {
          console.log('\n⚠️ Potential RLS issue - same count for different orgs');
        }
      }
    }
    
    // Test platform schema isolation (should always work regardless of RLS)
    console.log('\n🔒 Platform Schema Isolation Test:');
    const fakeOrgId = '99999999-9999-9999-9999-999999999999';
    await client.query("SELECT set_config('app.org_id', $1, false)", [fakeOrgId]);
    
    const platformUsers = await client.query('SELECT COUNT(*) as count FROM platform.users');
    const platformOrgs = await client.query('SELECT COUNT(*) as count FROM platform.organizations');
    
    console.log(`   Platform users visible: ${platformUsers.rows[0].count}`);
    console.log(`   Platform orgs visible: ${platformOrgs.rows[0].count}`);
    console.log('   ✅ Platform schema queries work regardless of org context');
    
  } finally {
    await client.end();
  }
}

testRLSIsolation().catch(console.error);
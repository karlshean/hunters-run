#!/usr/bin/env node
import pkg from 'pg';
const { Client } = pkg;
import { execSync } from 'child_process';
import { testEnvLoader } from './test-env-loader.mjs';

// Setup test environment first
testEnvLoader.setupTestEnvironment();

const baseUrl = 'http://localhost:3005'; // Use port 3005 where API is currently running
const demoOrgId = '00000000-0000-4000-8000-000000000001';

const results = {
  timestamp: new Date().toISOString(),
  tests: {},
  summary: { passed: 0, failed: 0, total: 0 }
};

async function runTest(name, testFn) {
  console.log(`Running: ${name}`);
  const start = Date.now();
  try {
    await testFn();
    results.tests[name] = { status: 'PASS', duration: Date.now() - start };
    results.summary.passed++;
    console.log(`✅ ${name}`);
  } catch (error) {
    results.tests[name] = { status: 'FAIL', duration: Date.now() - start, error: error.message };
    results.summary.failed++;
    console.log(`❌ ${name}: ${error.message}`);
  }
  results.summary.total++;
}

async function httpRequest(path, headers = {}) {
  const headerArgs = Object.entries(headers).map(([k,v]) => `-H "${k}: ${v}"`).join(' ');
  const cmd = `curl -s -i "${baseUrl}${path}" ${headerArgs}`;
  const output = execSync(cmd, { encoding: 'utf8' });
  const [headerBlock, body] = output.split('\r\n\r\n');
  const statusMatch = headerBlock.match(/HTTP\/1\.\d (\d+)/);
  const status = statusMatch ? parseInt(statusMatch[1]) : 0;
  return { status, body: body || '', headers: headerBlock };
}

// Test 1: Auto-provision → membership gate
await runTest('auto-provision-membership-gate', async () => {
  const uniqueSub = `test-user-${Date.now()}`;
  process.env.DEV_USER_SUB = uniqueSub;
  process.env.DEV_AUTH_BYPASS = 'true';
  
  // First call should create user but deny access (no membership)
  const firstCall = await httpRequest('/api/auth/echo', { 'x-org-id': demoOrgId });
  if (firstCall.status !== 403) {
    throw new Error(`Expected 403, got ${firstCall.status}`);
  }
  
  // Use a fresh client connection for each test
  const testClient = new Client(testEnvLoader.getDatabaseConfig());
  
  // Verify user was created
  await testClient.connect();
  const userCheck = await testClient.query(
    'SELECT id FROM platform.users WHERE external_provider = $1 AND external_sub = $2',
    ['dev', uniqueSub]
  );
  if (userCheck.rowCount !== 1) {
    throw new Error('User was not auto-provisioned');
  }
  const userId = userCheck.rows[0].id;
  
  // Add membership
  await testClient.query(
    'INSERT INTO platform.memberships (user_id, organization_id, role_name) VALUES ($1, $2, $3)',
    [userId, demoOrgId, 'hr_member']
  );
  
  // Second call should succeed
  const secondCall = await httpRequest('/api/auth/echo', { 'x-org-id': demoOrgId });
  if (secondCall.status !== 200) {
    throw new Error(`Expected 200 after membership, got ${secondCall.status}`);
  }
  
  // Verify permissions include hr_member permissions
  const response = JSON.parse(secondCall.body);
  const expectedPerms = ['hr.work_orders:create', 'hr.work_orders:read', 'hr.work_orders:update', 'hr.properties:read'];
  for (const perm of expectedPerms) {
    if (!response.permissions.includes(perm)) {
      throw new Error(`Missing expected permission: ${perm}`);
    }
  }
  
  // Verify audit events
  const auditCheck = await testClient.query(
    'SELECT event_type FROM platform.audit_events WHERE metadata->>\'userId\' = $1 ORDER BY created_at',
    [userId]
  );
  const events = auditCheck.rows.map(r => r.event_type);
  if (!events.includes('platform.user.provisioned')) {
    throw new Error('Missing platform.user.provisioned audit event');
  }
  
  await testClient.end();
});

// Test 2: Permission precedence (role vs user override)
await runTest('permission-precedence', async () => {
  const testClient = new Client(testEnvLoader.getDatabaseConfig());
  await testClient.connect();
  
  const userResult = await testClient.query(
    'SELECT id FROM platform.users WHERE external_provider = $1 AND external_sub = $2',
    ['dev', process.env.DEV_USER_SUB]
  );
  if (userResult.rowCount === 0) {
    throw new Error('Test user not found');
  }
  const userId = userResult.rows[0].id;
  
  // Set to hr_member role (no delete permission)
  await testClient.query(
    'UPDATE platform.memberships SET role_name = $1 WHERE user_id = $2 AND organization_id = $3',
    ['hr_member', userId, demoOrgId]
  );
  
  // Add user override for delete
  await testClient.query(
    'INSERT INTO platform.user_permissions (user_id, organization_id, permission) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING',
    [userId, demoOrgId, 'hr.work_orders:delete']
  );
  
  // Check permissions include delete (from override)
  const withOverride = await httpRequest('/api/auth/echo', { 'x-org-id': demoOrgId });
  const permsWithOverride = JSON.parse(withOverride.body).permissions;
  if (!permsWithOverride.includes('hr.work_orders:delete')) {
    throw new Error('User override permission not present');
  }
  
  // Remove override, change to viewer role
  await testClient.query('DELETE FROM platform.user_permissions WHERE user_id = $1', [userId]);
  await testClient.query(
    'UPDATE platform.memberships SET role_name = $1 WHERE user_id = $2',
    ['viewer', userId]
  );
  
  // Check only read permissions remain
  const asViewer = await httpRequest('/api/auth/echo', { 'x-org-id': demoOrgId });
  const viewerPerms = JSON.parse(asViewer.body).permissions;
  if (viewerPerms.includes('hr.work_orders:delete') || viewerPerms.includes('hr.work_orders:create')) {
    throw new Error('Viewer should not have write permissions');
  }
  if (!viewerPerms.includes('hr.work_orders:read')) {
    throw new Error('Viewer should have read permission');
  }
  
  await testClient.end();
});

// Test 3: Uniform error matrix
await runTest('uniform-error-matrix', async () => {
  // Missing x-org-id → 400
  const noOrg = await httpRequest('/api/auth/echo');
  if (noOrg.status !== 400) {
    throw new Error(`Expected 400 for missing org, got ${noOrg.status}`);
  }
  
  // Bad x-org-id format → 400
  const badOrg = await httpRequest('/api/auth/echo', { 'x-org-id': 'not-a-uuid' });
  if (badOrg.status !== 400) {
    throw new Error(`Expected 400 for bad org format, got ${badOrg.status}`);
  }
  
  // Temporarily disable dev bypass for token tests
  const originalBypass = process.env.DEV_AUTH_BYPASS;
  process.env.DEV_AUTH_BYPASS = 'false';
  
  // Missing token → 401
  const noToken = await httpRequest('/api/auth/echo', { 'x-org-id': demoOrgId });
  if (noToken.status !== 401) {
    throw new Error(`Expected 401 for missing token, got ${noToken.status}`);
  }
  
  // Bad token → 401
  const badToken = await httpRequest('/api/auth/echo', { 
    'x-org-id': demoOrgId,
    'authorization': 'Bearer invalid-token'
  });
  if (badToken.status !== 401) {
    throw new Error(`Expected 401 for bad token, got ${badToken.status}`);
  }
  
  // Restore dev bypass
  process.env.DEV_AUTH_BYPASS = originalBypass;
  
  // Valid user, no membership → 403
  const tempSub = `temp-${Date.now()}`;
  process.env.DEV_USER_SUB = tempSub;
  const noMembership = await httpRequest('/api/auth/echo', { 'x-org-id': demoOrgId });
  if (noMembership.status !== 403) {
    throw new Error(`Expected 403 for no membership, got ${noMembership.status}`);
  }
});

// Test 4: Race-safe provisioning
await runTest('race-safe-provisioning', async () => {
  const raceSub = `race-test-${Date.now()}`;
  process.env.DEV_USER_SUB = raceSub;
  
  // Spawn 10 parallel requests
  const promises = Array.from({ length: 10 }, () => 
    httpRequest('/api/auth/echo', { 'x-org-id': demoOrgId }).catch(() => ({ status: 403 }))
  );
  
  await Promise.all(promises);
  
  // Verify exactly one user record
  const testClient = new Client(testEnvLoader.getDatabaseConfig());
  await testClient.connect();
  const userCount = await testClient.query(
    'SELECT COUNT(*) as count FROM platform.users WHERE external_provider = $1 AND external_sub = $2',
    ['dev', raceSub]
  );
  if (parseInt(userCount.rows[0].count) !== 1) {
    throw new Error(`Expected 1 user record, got ${userCount.rows[0].count}`);
  }
  
  await testClient.end();
});

// Test 5: Activity telemetry
await runTest('activity-telemetry', async () => {
  const testClient = new Client(testEnvLoader.getDatabaseConfig());
  await testClient.connect();
  
  const userResult = await testClient.query(
    'SELECT id FROM platform.users WHERE external_provider = $1 AND external_sub = $2',
    ['dev', process.env.DEV_USER_SUB]
  );
  
  if (userResult.rowCount === 0) {
    throw new Error('Test user not found');
  }
  
  const userId = userResult.rows[0].id;
  
  // Get current last_seen_at
  const before = await testClient.query(
    'SELECT last_seen_at FROM platform.users WHERE id = $1',
    [userId]
  );
  const beforeTime = before.rows[0]?.last_seen_at;
  
  // Make authenticated request
  await httpRequest('/api/auth/echo', { 'x-org-id': demoOrgId });
  
  // Check last_seen_at updated
  const after = await testClient.query(
    'SELECT last_seen_at FROM platform.users WHERE id = $1',
    [userId]
  );
  const afterTime = after.rows[0]?.last_seen_at;
  
  if (!afterTime || (beforeTime && new Date(afterTime) <= new Date(beforeTime))) {
    throw new Error('last_seen_at was not updated');
  }
  
  await testClient.end();
});

// Generate comprehensive report
console.log('\n=== Identity System Test Results ===');
console.log(`Passed: ${results.summary.passed}/${results.summary.total}`);
console.log(`Failed: ${results.summary.failed}/${results.summary.total}`);

// Add system snapshot
const snapshotClient = new Client(testEnvLoader.getDatabaseConfig());
await snapshotClient.connect();
results.systemSnapshot = {
  userCount: parseInt((await snapshotClient.query('SELECT COUNT(*) as count FROM platform.users')).rows[0].count),
  membershipCount: parseInt((await snapshotClient.query('SELECT COUNT(*) as count FROM platform.memberships')).rows[0].count),
  auditEventCount: parseInt((await snapshotClient.query('SELECT COUNT(*) as count FROM platform.audit_events')).rows[0].count),
  recentAuditEvents: (await snapshotClient.query(
    'SELECT event_type, created_at FROM platform.audit_events ORDER BY created_at DESC LIMIT 5'
  )).rows
};
await snapshotClient.end();

// Write results
import fs from 'fs';
fs.mkdirSync('reports', { recursive: true });
const reportFile = `reports/identity-verify-${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
fs.writeFileSync(reportFile, JSON.stringify(results, null, 2));
console.log(`\n📄 Report written: ${reportFile}`);

process.exit(results.summary.failed > 0 ? 1 : 0);
#!/usr/bin/env node
/**
 * Test Environment Loader
 * Loads environment variables from .env file and sets up test-specific variables
 */
import fs from 'fs';
import path from 'path';

export class TestEnvLoader {
  constructor() {
    this.envLoaded = false;
    this.requiredVars = ['DATABASE_URL', 'FIREBASE_PROJECT_ID'];
    this.testVars = {
      DEV_AUTH_BYPASS: 'true',
      DEV_USER_SUB: 'test-user-' + Date.now(),
      DB_SSL_MODE: 'relaxed'
    };
  }

  /**
   * Load environment variables from .env file
   */
  loadEnvFile() {
    const envPaths = ['.env', '.env.local', '.env.development'];
    let envContent = '';
    
    for (const envPath of envPaths) {
      if (fs.existsSync(envPath)) {
        envContent = fs.readFileSync(envPath, 'utf8');
        console.log(`📄 Loading environment from: ${envPath}`);
        break;
      }
    }

    if (!envContent) {
      console.log('⚠️  No .env file found, using system environment variables');
      return;
    }

    // Parse .env file
    envContent.split('\n').forEach(line => {
      line = line.trim();
      
      // Skip empty lines and comments
      if (!line || line.startsWith('#')) return;
      
      const [key, ...valueParts] = line.split('=');
      if (key && valueParts.length > 0) {
        const value = valueParts.join('=').trim().replace(/^["'](.*)["']$/, '$1');
        
        // Only set if not already in environment
        if (!process.env[key.trim()]) {
          process.env[key.trim()] = value;
        }
      }
    });

    this.envLoaded = true;
  }

  /**
   * Set up test-specific environment variables
   */
  setupTestEnvironment() {
    this.loadEnvFile();

    // Set test-specific variables
    Object.entries(this.testVars).forEach(([key, value]) => {
      process.env[key] = value;
    });

    // Validate required variables
    const missing = this.requiredVars.filter(varName => !process.env[varName]);
    
    if (missing.length > 0) {
      console.error('❌ Missing required environment variables:', missing.join(', '));
      console.error('   Make sure .env file contains DATABASE_URL and FIREBASE_PROJECT_ID');
      throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
    }

    console.log('✅ Test environment configured successfully');
    this.logEnvironmentStatus();
    
    return {
      DATABASE_URL: process.env.DATABASE_URL,
      FIREBASE_PROJECT_ID: process.env.FIREBASE_PROJECT_ID,
      DEV_AUTH_BYPASS: process.env.DEV_AUTH_BYPASS,
      DEV_USER_SUB: process.env.DEV_USER_SUB,
      DB_SSL_MODE: process.env.DB_SSL_MODE
    };
  }

  /**
   * Log current environment status for debugging
   */
  logEnvironmentStatus() {
    console.log('\n🔧 Environment Status:');
    console.log(`   DATABASE_URL: ${this.maskUrl(process.env.DATABASE_URL)}`);
    console.log(`   FIREBASE_PROJECT_ID: ${process.env.FIREBASE_PROJECT_ID || 'NOT SET'}`);
    console.log(`   DEV_AUTH_BYPASS: ${process.env.DEV_AUTH_BYPASS}`);
    console.log(`   DEV_USER_SUB: ${process.env.DEV_USER_SUB}`);
    console.log(`   DB_SSL_MODE: ${process.env.DB_SSL_MODE}`);
    console.log('');
  }

  /**
   * Mask sensitive parts of database URL for logging
   */
  maskUrl(url) {
    if (!url) return 'NOT SET';
    try {
      const parsed = new URL(url);
      const masked = `${parsed.protocol}//${parsed.username}:***@${parsed.host}${parsed.pathname}`;
      return masked;
    } catch {
      return url.substring(0, 50) + '...';
    }
  }

  /**
   * Get database connection configuration for test scripts
   */
  getDatabaseConfig() {
    if (!process.env.DATABASE_URL) {
      throw new Error('DATABASE_URL not available');
    }

    // Handle SSL based on DB_SSL_MODE and connection string
    let sslConfig = false;
    
    if (process.env.DATABASE_URL.includes('sslmode=require')) {
      sslConfig = { rejectUnauthorized: false }; // Allow self-signed certs
    } else if (process.env.DB_SSL_MODE === 'strict') {
      sslConfig = { rejectUnauthorized: true };
    } else if (process.env.DB_SSL_MODE === 'relaxed') {
      sslConfig = { rejectUnauthorized: false };
    }

    return {
      connectionString: process.env.DATABASE_URL,
      ssl: sslConfig
    };
  }

  /**
   * Create a fresh test user ID for each test run
   */
  createTestUserId() {
    const testUserId = `test-user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    process.env.DEV_USER_SUB = testUserId;
    return testUserId;
  }
}

// Export singleton instance
export const testEnvLoader = new TestEnvLoader();

// For CommonJS compatibility
export default testEnvLoader;
#!/usr/bin/env node
/**
 * Test environment loading and configuration
 */
import fs from 'fs';
import { testEnvLoader } from './test-env-loader.mjs';

console.log('🧪 Testing Environment Loading and Configuration');
console.log('='.repeat(50));

try {
  // Test 1: Environment loading
  console.log('\n1. Testing environment loading...');
  const envConfig = testEnvLoader.setupTestEnvironment();
  console.log('✅ Environment loaded successfully');
  
  // Test 2: Required variables validation
  console.log('\n2. Validating required variables...');
  const requiredVars = ['DATABASE_URL', 'FIREBASE_PROJECT_ID', 'DEV_AUTH_BYPASS', 'DEV_USER_SUB', 'DB_SSL_MODE'];
  let allPresent = true;
  
  for (const varName of requiredVars) {
    if (process.env[varName]) {
      console.log(`   ✅ ${varName}: ${varName === 'DATABASE_URL' ? testEnvLoader.maskUrl(process.env[varName]) : process.env[varName]}`);
    } else {
      console.log(`   ❌ ${varName}: NOT SET`);
      allPresent = false;
    }
  }
  
  if (!allPresent) {
    throw new Error('Some required environment variables are missing');
  }
  
  // Test 3: Database configuration
  console.log('\n3. Testing database configuration...');
  const dbConfig = testEnvLoader.getDatabaseConfig();
  console.log('✅ Database configuration created');
  console.log(`   Connection string: ${testEnvLoader.maskUrl(dbConfig.connectionString)}`);
  console.log(`   SSL: ${dbConfig.ssl}`);
  
  // Test 4: Test user ID generation
  console.log('\n4. Testing test user ID generation...');
  const originalUserId = process.env.DEV_USER_SUB;
  const newUserId = testEnvLoader.createTestUserId();
  console.log(`✅ Original user ID: ${originalUserId}`);
  console.log(`✅ New user ID: ${newUserId}`);
  
  if (newUserId !== originalUserId) {
    console.log('✅ User ID generation working correctly');
  } else {
    console.log('❌ User ID did not change');
  }
  
  // Test 5: Environment file detection
  console.log('\n5. Testing environment file detection...');
  const envExists = fs.existsSync('.env');
  console.log(`✅ .env file exists: ${envExists}`);
  
  if (envExists) {
    const envContent = fs.readFileSync('.env', 'utf8');
    const hasDbUrl = envContent.includes('DATABASE_URL=');
    const hasFirebaseId = envContent.includes('FIREBASE_PROJECT_ID=');
    console.log(`✅ .env contains DATABASE_URL: ${hasDbUrl}`);
    console.log(`✅ .env contains FIREBASE_PROJECT_ID: ${hasFirebaseId}`);
  }
  
  console.log('\n🎉 All environment loading tests passed!');
  console.log('\n📋 Summary:');
  console.log('   ✅ Environment variables loaded from .env file');
  console.log('   ✅ All required variables present');
  console.log('   ✅ Database configuration working');
  console.log('   ✅ Test user ID generation working');
  console.log('   ✅ Environment file detection working');
  
  console.log('\n✨ The environment loader is working correctly!');
  console.log('   - Test scripts can now load environment variables automatically');
  console.log('   - No need for manual PowerShell variable setting');
  console.log('   - Database connections configured properly');
  
  process.exit(0);
  
} catch (error) {
  console.log(`\n❌ Environment loading test failed: ${error.message}`);
  console.log('\nDebugging info:');
  console.log('   - Check if .env file exists');
  console.log('   - Verify DATABASE_URL is set in .env');
  console.log('   - Ensure .env file is properly formatted');
  process.exit(1);
}
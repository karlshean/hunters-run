// Test script to verify the migration works
import { readFileSync } from 'fs';
import { DatabaseService } from '../apps/hr-api/src/common/database.service.js';

// Read the migration file
const migrationSQL = readFileSync('packages/db/migrations/017_units_demo_org_upsert.sql', 'utf8');

const db = new DatabaseService();

async function testMigration() {
  console.log('🧪 Testing migration 017_units_demo_org_upsert.sql');
  
  try {
    // Run the migration (should be idempotent)
    console.log('📝 Applying migration...');
    await db.query(migrationSQL);
    console.log('✅ Migration applied successfully');
    
    // Check constraint exists
    console.log('🔍 Checking constraint existence...');
    const constraintCheck = await db.query(`
      SELECT c.conname, c.contype
      FROM pg_constraint c
      JOIN pg_class t ON t.oid = c.conrelid
      JOIN pg_namespace n ON n.oid = t.relnamespace
      WHERE n.nspname = 'hr'
        AND t.relname = 'units'
        AND c.conname = 'uq_units_org_label'
    `);
    
    if (constraintCheck.rows.length > 0) {
      console.log('✅ Constraint uq_units_org_label exists');
    } else {
      console.log('❌ Constraint uq_units_org_label not found');
    }
    
    // Check demo units exist
    console.log('🏢 Checking demo units...');
    const demoOrg = '00000000-0000-4000-8000-000000000001';
    const unitsCheck = await db.query(`
      SELECT unit_label 
      FROM hr.units 
      WHERE organization_id = $1 
      ORDER BY unit_label
    `, [demoOrg]);
    
    const labels = unitsCheck.rows.map(r => r.unit_label);
    console.log('📋 Found units:', labels);
    
    const required = ['Unit 101', 'Unit 202'];
    const missing = required.filter(req => !labels.includes(req));
    
    if (missing.length === 0) {
      console.log('✅ All required demo units present');
    } else {
      console.log('❌ Missing required units:', missing);
    }
    
    // Test constraint works (try to insert duplicate)
    console.log('🔒 Testing constraint enforcement...');
    try {
      await db.query(`
        INSERT INTO hr.units (organization_id, unit_label) 
        VALUES ($1, 'Unit 101')
      `, [demoOrg]);
      console.log('❌ Constraint failed - duplicate was allowed');
    } catch (error) {
      if (error.code === '23505') { // unique_violation
        console.log('✅ Constraint working - duplicate rejected');
      } else {
        console.log('⚠️  Unexpected error:', error.message);
      }
    }
    
    // Test migration is idempotent
    console.log('🔄 Testing migration idempotency...');
    await db.query(migrationSQL);
    console.log('✅ Migration is idempotent');
    
  } catch (error) {
    console.error('❌ Migration test failed:', error);
  } finally {
    await db.onModuleDestroy();
  }
}

testMigration();
#!/usr/bin/env node
import fs from 'fs';
import path from 'path';
import http from 'http';
import https from 'https';
import { URL } from 'url';
import { spawn } from 'child_process';
import os from 'os';

/**
 * Cross-platform spawn utility that handles Windows command extensions
 */
function crossPlatformSpawn(command, args, options = {}) {
  const isWindows = os.platform() === 'win32';
  
  if (isWindows) {
    // On Windows, we need to use cmd.exe for most commands
    if (command === 'npm' || command === 'pnpm') {
      // npm/pnpm need .cmd extension on Windows
      command = `${command}.cmd`;
    }
  }
  
  return spawn(command, args, {
    stdio: ['ignore', 'pipe', 'pipe'],
    shell: isWindows && (command.includes('.cmd')),
    ...options
  });
}

function httpGet(url, timeout = 3000) {
  return new Promise((resolve) => {
    try {
      const u = new URL(url);
      const lib = u.protocol === 'https:' ? https : http;
      const req = lib.get({
        hostname: u.hostname,
        port: u.port || (u.protocol === 'https:' ? 443 : 80),
        path: u.pathname + (u.search || ''),
        timeout: timeout,
        headers: {
          'User-Agent': 'hunters-run-smoke-test/1.0'
        }
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => resolve({ 
          status: res.statusCode, 
          body: data,
          success: res.statusCode >= 200 && res.statusCode < 400
        }));
      });

      req.on('error', (err) => resolve({ 
        status: 0, 
        body: '', 
        success: false,
        error: err.message
      }));

      req.on('timeout', () => {
        req.destroy();
        resolve({ 
          status: 0, 
          body: '', 
          success: false,
          error: 'Request timeout'
        });
      });
    } catch (err) {
      resolve({ 
        status: 0, 
        body: '', 
        success: false,
        error: err.message
      });
    }
  });
}

function detectTestFramework() {
  const packageJsonPath = 'package.json';
  if (!fs.existsSync(packageJsonPath)) {
    return null;
  }

  try {
    const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
    const allDeps = {
      ...packageJson.dependencies,
      ...packageJson.devDependencies
    };

    // Check for common test frameworks
    if (allDeps.jest) return 'jest';
    if (allDeps.vitest) return 'vitest';
    if (allDeps.mocha) return 'mocha';
    if (allDeps.tap) return 'tap';
    if (allDeps['@playwright/test']) return 'playwright';

    // Check npm scripts for test commands
    const scripts = packageJson.scripts || {};
    if (scripts.test && scripts.test !== 'echo "Error: no test specified" && exit 1') {
      return 'npm-script';
    }

    return null;
  } catch (error) {
    return null;
  }
}

function runCommand(command, args, options = {}) {
  return new Promise((resolve) => {
    const child = crossPlatformSpawn(command, args, {
      timeout: options.timeout || 30000,
      ...options
    });

    let stdout = '';
    let stderr = '';

    child.stdout?.on('data', (data) => stdout += data.toString());
    child.stderr?.on('data', (data) => stderr += data.toString());

    child.on('close', (code) => {
      resolve({
        exitCode: code,
        stdout,
        stderr,
        success: code === 0
      });
    });

    child.on('error', (error) => {
      resolve({
        exitCode: 1,
        stdout,
        stderr: error.message,
        success: false,
        error: error.message
      });
    });
  });
}

async function createBasicSmokeTest() {
  const smokeTestDir = 'tests/smoke';
  const smokeTestPath = path.join(smokeTestDir, 'health.smoke.js');

  // Ensure directory exists
  if (!fs.existsSync(smokeTestDir)) {
    fs.mkdirSync(smokeTestDir, { recursive: true });
  }

  // Create a basic smoke test if it doesn't exist
  if (!fs.existsSync(smokeTestPath)) {
    const smokeTestContent = `// Basic smoke test for hunters-run
const http = require('http');

async function testHealthEndpoint() {
  return new Promise((resolve) => {
    const req = http.get('http://localhost:3000/api/health', (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          const success = res.statusCode === 200 && parsed.ok === true;
          resolve({ success, status: res.statusCode, body: data });
        } catch (err) {
          resolve({ success: false, error: 'Invalid JSON response', status: res.statusCode, body: data });
        }
      });
    });

    req.on('error', (err) => {
      resolve({ success: false, error: err.message });
    });

    req.setTimeout(5000, () => {
      req.destroy();
      resolve({ success: false, error: 'Request timeout' });
    });
  });
}

async function runSmokeTest() {
  console.log('Running smoke test...');
  
  const healthTest = await testHealthEndpoint();
  
  if (healthTest.success) {
    console.log('✅ Health endpoint test passed');
    process.exit(0);
  } else {
    console.log('❌ Health endpoint test failed:', healthTest.error || 'Unknown error');
    process.exit(1);
  }
}

if (require.main === module) {
  runSmokeTest().catch(console.error);
}

module.exports = { testHealthEndpoint };
`;

    fs.writeFileSync(smokeTestPath, smokeTestContent);
    console.log(`Created basic smoke test: ${smokeTestPath}`);
  }

  return smokeTestPath;
}

async function runSmokeTests() {
  const startTime = Date.now();
  const timestamp = new Date().toISOString();
  
  const result = {
    timestamp,
    framework: null,
    tests: [],
    summary: {
      total: 0,
      passed: 0,
      failed: 0,
      duration: 0
    },
    details: {}
  };

  // Detect test framework
  const framework = detectTestFramework();
  result.framework = framework;

  try {
    if (framework === 'jest') {
      // Run Jest tests
      const jestResult = await runCommand('npm', ['test'], { timeout: 60000 });
      result.details.jest = jestResult;
      result.summary.total = 1;
      result.summary.passed = jestResult.success ? 1 : 0;
      result.summary.failed = jestResult.success ? 0 : 1;
      result.tests.push({
        name: 'jest-suite',
        passed: jestResult.success,
        duration: Date.now() - startTime,
        output: jestResult.stdout.substring(0, 500)
      });
    } else if (framework === 'npm-script') {
      // Run npm test script
      const testResult = await runCommand('npm', ['test'], { timeout: 60000 });
      result.details.npmScript = testResult;
      result.summary.total = 1;
      result.summary.passed = testResult.success ? 1 : 0;
      result.summary.failed = testResult.success ? 0 : 1;
      result.tests.push({
        name: 'npm-test',
        passed: testResult.success,
        duration: Date.now() - startTime,
        output: testResult.stdout.substring(0, 500)
      });
    } else {
      // Fallback: create and run basic Node smoke test
      const smokeTestPath = await createBasicSmokeTest();
      const nodeResult = await runCommand('node', [smokeTestPath], { timeout: 30000 });
      result.details.nodeFallback = nodeResult;
      result.framework = 'node-fallback';
      result.summary.total = 1;
      result.summary.passed = nodeResult.success ? 1 : 0;
      result.summary.failed = nodeResult.success ? 0 : 1;
      result.tests.push({
        name: 'health-smoke-test',
        passed: nodeResult.success,
        duration: Date.now() - startTime,
        output: nodeResult.stdout.substring(0, 500)
      });
    }
  } catch (error) {
    // Fallback to HTTP test if all else fails
    console.log('Test framework execution failed, falling back to direct HTTP test...');
    
    const healthResult = await httpGet('http://localhost:3000/api/health');
    const testPassed = healthResult.success && healthResult.body.includes('"ok":true');
    
    result.details.httpFallback = healthResult;
    result.framework = 'http-fallback';
    result.summary.total = 1;
    result.summary.passed = testPassed ? 1 : 0;
    result.summary.failed = testPassed ? 0 : 1;
    result.tests.push({
      name: 'direct-health-check',
      passed: testPassed,
      duration: Date.now() - startTime,
      output: healthResult.body ? healthResult.body.substring(0, 200) : healthResult.error || 'No response'
    });
  }

  result.summary.duration = Date.now() - startTime;
  result.summary.success = result.summary.failed === 0;

  return result;
}

async function main() {
  try {
    const smokeResult = await runSmokeTests();

    // Ensure reports directory exists
    const reportsDir = 'reports/artifacts';
    if (!fs.existsSync(reportsDir)) {
      fs.mkdirSync(reportsDir, { recursive: true });
    }

    const outputPath = path.join(reportsDir, 'test-smoke.json');
    fs.writeFileSync(outputPath, JSON.stringify(smokeResult, null, 2));

    console.log(`Smoke test results written to: ${outputPath}`);
    console.log(`Test summary: ${smokeResult.summary.passed}/${smokeResult.summary.total} passed (${smokeResult.summary.duration}ms)`);

    if (!smokeResult.summary.success) {
      console.log('Some smoke tests failed - check the detailed results');
    }

    return smokeResult;
  } catch (error) {
    console.error('Smoke test execution failed:', error);
    process.exit(1);
  }
}

// Run main if this file is executed directly
if (process.argv[1] && import.meta.url.includes(path.basename(process.argv[1]))) {
  main().catch(console.error);
}